import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../../services/auth_service.dart';
import 'tech_register_screen.dart';
import '../customer/customer_home.dart';
import '../tech/tech_home.dart';
import '../../models/models.dart';

/// دخول برقم الموبايل + OTP — مشترك للعميل والفني، والدور بيتحدد من قاعدة البيانات
class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final phone = TextEditingController();
  String? _verificationId;
  bool loading = false;

  Future<void> _sendOtp() async {
    if (phone.text.trim().length != 11) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('اكتب رقم موبايل صحيح (11 رقم)')));
      return;
    }
    setState(() => loading = true);
    await AuthService.sendOtp(
      phone.text.trim(),
      onCodeSent: (id) { setState(() { _verificationId = id; loading = false; }); _otpSheet(); },
      onError: (e) { setState(() => loading = false); ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e))); },
    );
  }

  void _otpSheet() {
    final code = TextEditingController();
    showModalBottomSheet(context: context, isScrollControlled: true, builder: (_) => Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom, left: 16, right: 16, top: 20),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        const Text('أدخل كود التحقق', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        TextField(controller: code, keyboardType: TextInputType.number, maxLength: 6,
            textAlign: TextAlign.center, decoration: const InputDecoration(counterText: '')),
        const SizedBox(height: 12),
        ElevatedButton(onPressed: () async {
          Navigator.pop(context);
          await _verify(code.text.trim());
        }, child: const Text('تحقق ودخول')),
        const SizedBox(height: 20),
      ]),
    ));
  }

  Future<void> _verify(String code) async {
    setState(() => loading = true);
    try {
      final cred = await AuthService.verifyOtp(_verificationId!, code);
      final role = await AuthService.roleOf(cred.user!.uid);
      if (!mounted) return;
      if (role == 'tech') {
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => TechHome(uid: cred.user!.uid)));
      } else if (role == 'customer') {
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => CustomerHome(uid: cred.user!.uid)));
      } else {
        // مستخدم جديد — يختار: عميل أو فني
        _chooseRole(cred.user!);
      }
    } on FirebaseAuthException catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message ?? 'كود غير صحيح')));
    } finally { if (mounted) setState(() => loading = false); }
  }

  void _chooseRole(User u) {
    showDialog(context: context, barrierDismissible: false, builder: (_) => AlertDialog(
      title: const Text('أهلاً بيك في الياسمين'),
      content: const Text('سجّل كـ:'),
      actions: [
        TextButton(onPressed: () async {
          await AuthService.registerCustomer(AppUser(uid: u.uid, name: u.phoneNumber, phone: u.phoneNumber, role: 'customer'));
          if (!mounted) return;
          Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => CustomerHome(uid: u.uid)));
        }, child: const Text('🚗 عميل')),
        TextButton(onPressed: () {
          Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => TechRegisterScreen(uid: u.uid)));
        }, child: const Text('🔧 فني / صنايعي')),
      ],
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(body: SafeArea(child: Padding(padding: const EdgeInsets.all(20), child: Column(
      crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      const Spacer(),
      Center(child: Container(width: 90, height: 90, decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.secondary, borderRadius: BorderRadius.circular(26)),
        child: Center(child: Text('ي', style: TextStyle(fontSize: 44, fontWeight: FontWeight.bold, color: Theme.of(context).colorScheme.primary))))),
      const SizedBox(height: 16),
      const Center(child: Text('الياسمين لإصلاح أعطال السيارات', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold))),
      const Center(child: Text('في الطرق والصحراء — فنيك يوصلك في مكانك', style: TextStyle(color: Colors.grey))),
      const Spacer(),
      TextField(controller: phone, keyboardType: TextInputType.phone, maxLength: 11,
        decoration: const InputDecoration(labelText: 'رقم الموبايل (11 رقم)', prefixText: '+20 ')),
      const SizedBox(height: 12),
      ElevatedButton(onPressed: loading ? null : _sendOtp,
        child: loading ? const CircularProgressIndicator(color: Colors.white) : const Text('إرسال كود التحقق')),
      const SizedBox(height: 8),
      const Text('بالدخول أنت توافق على شروط الاستخدام وسياسة الخصوصية',
        textAlign: TextAlign.center, style: TextStyle(fontSize: 11, color: Colors.grey)),
    ]))));
  }
}
