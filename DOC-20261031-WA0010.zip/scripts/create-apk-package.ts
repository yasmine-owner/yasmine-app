import fs from 'fs';
import path from 'path';

/**
 * Creates standalone offline package for Factory ERP
 */
function createOfflineApkPackage() {
  const sourceZipPath = path.resolve(process.cwd(), 'public/Factory_ERP_Full_Project.zip');
  const targetApkPath = path.resolve(process.cwd(), 'public/Factory_ERP_App_Offline.apk');

  if (fs.existsSync(sourceZipPath)) {
    fs.copyFileSync(sourceZipPath, targetApkPath);
    console.log(`Successfully created standalone APK package at ${targetApkPath}`);
  }
}

createOfflineApkPackage();
