import fs from 'fs';
import path from 'path';
import JSZip from 'jszip';
import * as XLSX from 'xlsx';
import {
  INITIAL_ACCOUNTS,
  INITIAL_JOURNAL_ENTRIES,
  INITIAL_PARTNERS,
  INITIAL_MACHINES,
  INITIAL_INVENTORY,
  INITIAL_CUTTING_TOOLS,
  INITIAL_WAREHOUSES,
  INITIAL_THEME,
} from '../src/data/initialData';

async function buildZip() {
  const zip = new JSZip();

  // 1. Documentation
  const docFolder = zip.folder('Documentation');
  docFolder?.file(
    'دليل_التشغيل_والتثبيت_الشامل_للمصنع_الطبي.md',
    `# دليل تشغيل وتثبيت برنامج ERP لإدارة مصنع المستلزمات الطبية والماكينات
الإصدار: 3.0.0 Enterprise Clean State
المصنع: مصنع الأشغال الميكانيكية وتصنيع الشرائح والمسامير والمستلزمات الطبية

## 1. ملخص الحالة المالية الافتتاحية للمصنع
- **إجمالي مساهمات الشركاء ورؤوس الأموال:** 2,400,000 جنيه مصري بالضبط موزعة كالتالي:
  * الشريك الأول: 800,000 جنيه مصري
  * الشريك الثاني: 800,000 جنيه مصري
  * الشريك الثالث: 400,000 جنيه مصري
  * الشريك الرابع: 200,000 جنيه مصري (مودعة ومثبتة بحساب الشريك الثالث)
  * الشريك الخامس: 200,000 جنيه مصري (مودعة ومثبتة بحساب الشريك الثالث)
- **الأصول الثابتة (الماكينات ومعدات التصنيع الطبي):** 2,150,000 جنيه مصري
  * مركز تشغيل وتفريز CNC عمودي VMC-850 للشرائح والمستلزمات الطبية: 1,100,000 جنيه مصري
  * مخرطة CNC عالية الدقة للمسامير والمثبتات الطبية CK6140: 700,000 جنيه مصري
  * مكبس هيدروليكي صناعي 100 طن وتجهيزات المعايرة: 230,000 جنيه مصري
  * كمبروسر هواء حلزوني ومجفف هواء طبي معقم: 120,000 جنيه مصري
- **المخزن الفعلي (بضاعة أول المدة):** 250,000 جنيه مصري بالضبط
  * شرائح عظام طبية تيتانيوم وفولاذ جراحي (البند الأساسي من نصيب الشركاء): 250 قطعة × 1,000 جنيه = 250,000 جنيه مصري
- **الحركات والعمليات السابقة:** صفر تام (لا توجد مبيعات سابقة، لا ديون، لا مصروفات، لا نقدية مكررة).
- **القيد الافتتاحي:** قيد وحيد متوازن يثبت الأصول (2,400,000 جنيه مصري) في مقابل حقوق الملكية (2,400,000 جنيه مصري).
- **رمز المالك السري (Owner PIN):** 7890 (للوصول إلى لوحة المالك المستقلة وإدارة الصلاحيات والنسخ الاحتياطي).

## 2. خطوات التثبيت والتشغيل على مختلف الأجهزة

### أولاً: التشغيل الفوري على الهاتف المحمول (Android و iPhone)
1. افتح رابط البرنامج المباشر في متصفح هاتفك (Chrome للأندرويد، أو Safari للآيفون).
2. في متصفح Google Chrome: اضغط على الثلاث نقاط بالأعلى واختر "تثبيت التطبيق" (Install app) أو "إضافة إلى الشاشة الرئيسية" (Add to Home screen).
3. في متصفح Safari على iPhone: اضغط على زر المشاركة (Share) ثم اختر "Add to Home Screen" (إضافة إلى الشاشة الرئيسية).
4. يفتح التطبيق مباشرة في وضع الشاشة الكاملة (Full-screen App) بدون أي أشرطة للمتصفح، ويدعم اللمس والشاشات المتجاوبة بالكامل.

### ثانياً: التثبيت على الكمبيوتر واللابتوب (Windows و Mac)
1. افتح رابط البرنامج في متصفح Google Chrome أو Microsoft Edge.
2. ستظهر أيقونة تثبيت صغيرة (شاشة مع سهم للأسفل) في شريط العنوان بالأعلى، اضغط عليها ثم اختر "تثبيت".
3. يظهر اختصار رسمي للبرنامج على سطح المكتب وفي قائمة Start ويعمل كنافذة مستقلة احترافية تماماً.

### ثالثاً: التشغيل من السورس كود محلياً (Offline Local Development)
1. فك ضغط مجلد Source_Code الموجود في هذا الملف.
2. افتح الطرفية (CMD أو Terminal) في مجلد المشروع.
3. اكتب:
   \`npm install\`
4. ثم شغّل السيرفر:
   \`npm run dev\`
5. افتح المتصفح على: \`http://localhost:3000\`
`
  );

  // 2. Excel Templates
  const excelFolder = zip.folder('Excel_Templates');
  const wb = XLSX.utils.book_new();

  // Unified Journal Entries Sheet
  const journalRows: any[] = [];
  INITIAL_JOURNAL_ENTRIES.forEach((e) => {
    e.lines.forEach((l, idx) => {
      journalRows.push({
        'رقم القيد': e.entryNumber,
        'التاريخ': e.date,
        'البيان': e.description,
        'سطر #': idx + 1,
        'كود الحساب': l.accountCode,
        'اسم الحساب': l.accountName,
        'مدين (منه) - جنيه مصري': l.debit,
        'دائن (له) - جنيه مصري': l.credit,
        'ملاحظة': l.note || '',
        'الحالة': 'مرحل للأستاذ العام',
      });
    });
  });
  XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(journalRows), 'القيود اليومية المركزية');

  // Accounts Chart
  const accRows = INITIAL_ACCOUNTS.map((a) => ({
    'كود الحساب': a.code,
    'اسم الحساب': a.name,
    'النوع': a.type,
    'الرصيد الافتتاحي (جنيه مصري)': a.balance,
    'الوصف': a.description || '',
  }));
  XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(accRows), 'دليل الحسابات والأرصدة');

  // Partners & 2.4M Capital
  const partRows = INITIAL_PARTNERS.map((p) => ({
    'اسم الشريك': p.name,
    'المساهمة المعتمدة (جنيه مصري)': p.initialContribution,
    'الرصيد الجاري الحالي (جنيه مصري)': p.currentBalance,
    'مكان إيداع المبلغ': p.hasSubAccountInOtherPartner ? `بحساب ${p.hasSubAccountInOtherPartner}` : 'حساب مباشر',
    'ملاحظات': p.notes,
  }));
  XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(partRows), 'مساهمات الشركاء 2.4 مليون');

  // Machines Registry
  const machRows = INITIAL_MACHINES.map((m) => ({
    'كود الماكينة': m.code,
    'اسم الماكينة': m.name,
    'النوع والموديل': `${m.brand} - ${m.model}`,
    'تاريخ الشراء': m.purchaseDate,
    'تكلفة الشراء (جنيه مصري)': m.purchaseCost,
    'صافي القيمة الدفترية (جنيه مصري)': m.currentBookValue,
    'العمر الإنتاجي (سنوات)': m.usefulLifeYears,
    'تكلفة التشغيل للساعة (جنيه مصري)': m.hourlyOperatingCost,
    'الموقع': m.location,
  }));
  XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(machRows), 'الماكينات ومعدات التصنيع');

  // Medical Inventory
  const invRows = INITIAL_INVENTORY.map((item) => ({
    'كود الصنف': item.code,
    'اسم الصنف': item.name,
    'الرصيد المخزني الحالي': item.currentStock,
    'الوحدة': item.unit,
    'متوسط التكلفة المرجح (جنيه مصري)': item.movingAverageCost,
    'إجمالي القيمة المخزنية (جنيه مصري)': item.currentStock * item.movingAverageCost,
  }));
  XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(invRows), 'المخزون الطبي وبضاعة الشركاء');

  const excelBuffer = XLSX.write(wb, { bookType: 'xlsx', type: 'buffer' });
  excelFolder?.file('Factory_ERP_Official_Accounts_2026.xlsx', excelBuffer);

  // 3. Database
  const dbFolder = zip.folder('Database');
  dbFolder?.file(
    'clean_factory_seed.json',
    JSON.stringify(
      {
        totalCapital: 2400000,
        machineryTotal: 2150000,
        inventoryTotal: 250000,
        accounts: INITIAL_ACCOUNTS,
        journalEntries: INITIAL_JOURNAL_ENTRIES,
        partners: INITIAL_PARTNERS,
        machines: INITIAL_MACHINES,
        inventory: INITIAL_INVENTORY,
        cuttingTools: INITIAL_CUTTING_TOOLS,
        warehouses: INITIAL_WAREHOUSES,
        theme: INITIAL_THEME,
      },
      null,
      2
    )
  );

  dbFolder?.file(
    'schema.sql',
    `-- Clean Factory Database Schema (PostgreSQL / MySQL)
CREATE TABLE accounts (
  id VARCHAR(64) PRIMARY KEY,
  code VARCHAR(16) NOT NULL UNIQUE,
  name VARCHAR(255) NOT NULL,
  type VARCHAR(32) NOT NULL,
  parent_code VARCHAR(16),
  balance NUMERIC(15,2) DEFAULT 0.00,
  description TEXT
);

CREATE TABLE partners (
  id VARCHAR(64) PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  initial_contribution NUMERIC(15,2) NOT NULL,
  current_balance NUMERIC(15,2) NOT NULL,
  has_sub_account_in VARCHAR(255),
  notes TEXT
);

CREATE TABLE machines (
  id VARCHAR(64) PRIMARY KEY,
  code VARCHAR(32) NOT NULL UNIQUE,
  name VARCHAR(255) NOT NULL,
  purchase_cost NUMERIC(15,2) NOT NULL,
  current_book_value NUMERIC(15,2) NOT NULL,
  hourly_operating_cost NUMERIC(10,2) NOT NULL,
  status VARCHAR(32) DEFAULT 'running'
);

CREATE TABLE inventory (
  id VARCHAR(64) PRIMARY KEY,
  code VARCHAR(64) NOT NULL UNIQUE,
  name VARCHAR(255) NOT NULL,
  current_stock NUMERIC(12,2) DEFAULT 0.00,
  moving_average_cost NUMERIC(12,2) DEFAULT 0.00,
  unit VARCHAR(32) NOT NULL
);
`
  );

  // 4. Source Code
  const srcFolder = zip.folder('Source_Code');
  
  function addFolderRecursively(localDir: string, zipTarget: JSZip) {
    const entries = fs.readdirSync(localDir, { withFileTypes: true });
    for (const ent of entries) {
      if (ent.name === 'node_modules' || ent.name === 'dist' || ent.name === '.git' || ent.name === '.aistudio') {
        continue;
      }
      const fullPath = path.join(localDir, ent.name);
      if (ent.isDirectory()) {
        const sub = zipTarget.folder(ent.name);
        if (sub) addFolderRecursively(fullPath, sub);
      } else {
        const content = fs.readFileSync(fullPath);
        zipTarget.file(ent.name, content);
      }
    }
  }

  const rootAppDir = process.cwd();
  addFolderRecursively(rootAppDir, srcFolder!);

  // Generate buffer and write to /public/Factory_ERP_Full_Project.zip
  const zipBuffer = await zip.generateAsync({
    type: 'nodebuffer',
    compression: 'DEFLATE',
    compressionOptions: { level: 6 },
  });

  const outPath = path.resolve(process.cwd(), 'public/Factory_ERP_Full_Project.zip');
  fs.writeFileSync(outPath, zipBuffer);
  console.log(`Successfully generated clean ZIP package at ${outPath} (${zipBuffer.length} bytes)`);
}

buildZip().catch((err) => {
  console.error(err);
  process.exit(1);
});
