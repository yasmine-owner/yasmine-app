/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  Bell,
  Download,
  FileSpreadsheet,
  KeyRound,
  Lock,
  LogOut,
  Palette,
  Search,
  Shield,
  ShieldAlert,
  ShieldCheck,
  Sparkles,
  UserCheck,
  Users,
} from 'lucide-react';
import { useERP } from '../../context/ERPContext';
import { exportCompleteFactoryExcel } from '../../utils/excelExport';

interface TopHeaderProps {
  activeModule: string;
  setActiveModule: (mod: string) => void;
  onOpenMobileMenu?: () => void;
}

export const TopHeader: React.FC<TopHeaderProps> = ({ activeModule, setActiveModule, onOpenMobileMenu }) => {
  const {
    currentUser,
    users,
    switchUser,
    isOwnerSecretUnlocked,
    unlockOwnerSecret,
    lockOwnerSecret,
    journalEntries,
    accounts,
    partners,
    machines,
    cuttingTools,
    inventory,
    productionOrders,
    scrapLogs,
    theme,
  } = useERP();

  const [showRoleModal, setShowRoleModal] = useState(false);
  const [showSecretPinModal, setShowSecretPinModal] = useState(false);
  const [pinInput, setPinInput] = useState('');
  const [pinError, setPinError] = useState('');

  // Notification Center State
  const [showNotificationsPopover, setShowNotificationsPopover] = useState(false);
  const [readNotificationIds, setReadNotificationIds] = useState<string[]>([]);
  const [activeNotifFilter, setActiveNotifFilter] = useState<'all' | 'stock' | 'maintenance' | 'production'>('all');

  // PWA 1-Click Install Prompt State
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [isInstalled, setIsInstalled] = useState(false);

  React.useEffect(() => {
    const handler = (e: any) => {
      e.preventDefault();
      setDeferredPrompt(e);
    };
    window.addEventListener('beforeinstallprompt', handler);
    window.addEventListener('appinstalled', () => {
      setIsInstalled(true);
      setDeferredPrompt(null);
    });
    return () => {
      window.removeEventListener('beforeinstallprompt', handler);
    };
  }, []);

  const handleTriggerInstall = () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      deferredPrompt.userChoice.then((choiceResult: any) => {
        if (choiceResult.outcome === 'accepted') {
          setIsInstalled(true);
        }
        setDeferredPrompt(null);
      });
    } else {
      alert(
        'لتثبيت التطبيق بنقرة واحدة أوفلاين على هاتفك:\n\n1. افتح الرابط في متصفح Google Chrome على الأندرويد.\n2. اضغط على زر الخيارات (⋮) أعلى الشاشة.\n3. اختر "تثبيت التطبيق" (Install App) أو "إضافة إلى الشاشة الرئيسية".\n4. سينزل البرنامج كـ تطبيق أندرويد مستقل أوفلاين!'
      );
    }
  };

  // Compute dynamic live system notifications
  const generatedNotifications = React.useMemo(() => {
    const list: Array<{
      id: string;
      type: 'stock' | 'maintenance' | 'production';
      severity: 'high' | 'medium' | 'info';
      title: string;
      message: string;
      time: string;
      targetModule: string;
    }> = [];

    // 1. Low Inventory Alerts
    inventory.forEach((item) => {
      if (item.currentStock <= item.minAlertStock) {
        const isOut = item.currentStock === 0;
        list.push({
          id: `stock_${item.id}`,
          type: 'stock',
          severity: isOut ? 'high' : 'medium',
          title: isOut ? 'نفاد مخزون بالكامل!' : 'تنبيه وصول للحد الأدنى للمخزون',
          message: `الصنف (${item.name}) الكود [${item.code}] بـ ${item.category} - الرصيد الحالي (${item.currentStock} ${item.unit}) بلغ الحد الأدنى المحدد بـ (${item.minAlertStock} ${item.unit}).`,
          time: 'الآن',
          targetModule: 'inventory',
        });
      }
    });

    // 2. Machine Maintenance & Downtime Alerts
    machines.forEach((mac) => {
      if (mac.status === 'maintenance') {
        list.push({
          id: `mac_maint_${mac.id}`,
          type: 'maintenance',
          severity: 'high',
          title: 'ماكينة في وضع الصيانة الدوري',
          message: `الماكينة (${mac.name}) الكود [${mac.code}] قيد الصيانة حالياً. إجمالي ساعات الأعطال المسجلة: ${mac.totalBreakdownHours} ساعة.`,
          time: 'منذ ساعة',
          targetModule: 'machines',
        });
      } else if (mac.status === 'breakdown') {
        list.push({
          id: `mac_break_${mac.id}`,
          type: 'maintenance',
          severity: 'high',
          title: 'تنبيه توقف طارئ بسبب عطل!',
          message: `الماكينة (${mac.name}) الكود [${mac.code}] متوقفة بسبب عطل مفاجئ وتتطلب تدخلاً فورياً من فريق الصيانة.`,
          time: 'عاجل',
          targetModule: 'machines',
        });
      }
    });

    // 3. Cutting Tools Lifespan Alerts
    cuttingTools.forEach((tool) => {
      const remainingHours = tool.expectedLifespanHours - tool.actualRunHours;
      if (remainingHours <= 15 || tool.status !== 'active') {
        list.push({
          id: `tool_${tool.id}`,
          type: 'maintenance',
          severity: remainingHours <= 5 ? 'high' : 'medium',
          title: 'اقتراب نهاية العمر الافتراضي لأداة قطع',
          message: `أداة القطع (${tool.name}) الكود [${tool.code}] - ساعات التشغيل الفعلية (${tool.actualRunHours} ساعة) المتبقي (${Math.max(0, remainingHours)} ساعة) حتى التغيير.`,
          time: 'الآن',
          targetModule: 'cutting_tools',
        });
      }
    });

    // 4. Production Orders Alerts
    productionOrders.forEach((ord) => {
      if (ord.status === 'planned') {
        list.push({
          id: `prod_${ord.id}`,
          type: 'production',
          severity: 'info',
          title: 'أمر إنتاج بانتظار الاعتماد للبدء',
          message: `أمر الإنتاج رقم [${ord.orderNumber}] للمنتج (${ord.productName}) بـ كمية مطلوبة (${ord.requiredQuantity} قطعة) مخطط البدء فيه.`,
          time: 'منذ ساعتين',
          targetModule: 'manufacturing',
        });
      }
    });

    return list;
  }, [inventory, machines, cuttingTools, productionOrders]);

  const unreadNotifications = generatedNotifications.filter((n) => !readNotificationIds.includes(n.id));
  const unreadCount = unreadNotifications.length;

  const filteredNotifications = generatedNotifications.filter((n) => {
    if (activeNotifFilter === 'all') return true;
    return n.type === activeNotifFilter;
  });

  const handleMarkAllRead = () => {
    setReadNotificationIds(generatedNotifications.map((n) => n.id));
  };

  const handleToggleRead = (id: string) => {
    if (readNotificationIds.includes(id)) {
      setReadNotificationIds(readNotificationIds.filter((i) => i !== id));
    } else {
      setReadNotificationIds([...readNotificationIds, id]);
    }
  };

  const handleExportAll = () => {
    exportCompleteFactoryExcel({
      journalEntries,
      accounts,
      partners,
      machines,
      cuttingTools,
      inventory,
      productionOrders,
      scrapLogs,
    });
  };

  const handlePinSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setPinError('');
    const success = unlockOwnerSecret(pinInput);
    if (success) {
      setShowSecretPinModal(false);
      setPinInput('');
      setActiveModule('owner_secret');
    } else {
      setPinError('رمز الحماية غير صحيح! محاولة غير مصرح بها.');
    }
  };

  const getRoleBadge = (role: string) => {
    switch (role) {
      case 'owner':
        return { label: 'المالك الرئيسي (Owner)', bg: 'bg-amber-500/20 text-amber-300 border-amber-500/40' };
      case 'manager':
        return { label: 'مدير عام المصنع (GM)', bg: 'bg-blue-500/20 text-blue-300 border-blue-500/40' };
      case 'accountant':
        return { label: 'رئيس الحسابات (Accountant)', bg: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40' };
      case 'warehouse':
        return { label: 'أمين المخازن (Storekeeper)', bg: 'bg-purple-500/20 text-purple-300 border-purple-500/40' };
      case 'production':
        return { label: 'مشرف الإنتاج (Production)', bg: 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40' };
      default:
        return { label: 'مشاهد فقط (View-Only)', bg: 'bg-slate-700 text-slate-300 border-slate-600' };
    }
  };

  const badge = getRoleBadge(currentUser.role);

  return (
    <header className="sticky top-0 z-30 flex items-center justify-between px-3 sm:px-6 py-2.5 sm:py-3.5 bg-slate-900/90 backdrop-blur-md border-b border-slate-800 text-white shadow-md">
      {/* Mobile Hamburger + Title / Search */}
      <div className="flex items-center gap-2 sm:gap-4">
        {onOpenMobileMenu && (
          <button
            onClick={onOpenMobileMenu}
            className="lg:hidden p-2 rounded-xl bg-slate-800 text-slate-200 hover:text-white border border-slate-700 transition cursor-pointer"
            title="فتح القائمة الرئيسية"
          >
            <span className="text-base font-bold">☰</span>
          </button>
        )}

        <div className="relative hidden md:block w-72">
          <Search className="w-4 h-4 absolute right-3 top-3 text-slate-400" />
          <input
            type="text"
            placeholder="بحث في الحسابات، الماكينات، أوامر الإنتاج..."
            className="w-full pl-3 pr-9 py-1.5 text-xs bg-slate-950/70 border border-slate-700 rounded-xl text-slate-200 placeholder-slate-500 focus:outline-none focus:border-blue-500 transition-all"
          />
        </div>

        <div className="flex items-center gap-1.5 text-xs">
          <span className="px-2 py-0.5 rounded-md bg-blue-950/70 text-blue-400 font-mono border border-blue-800/40 font-semibold text-[10px] sm:text-xs">
            ERP v2.5
          </span>
          <span className="text-slate-400 hidden xl:inline">
            مزامنة حية • قاعدة البيانات نشطة
          </span>
        </div>
      </div>

      {/* Actions & Role Switcher */}
      <div className="flex items-center gap-2 sm:gap-3">
        {/* In-App Notifications Bell Icon Button */}
        <div className="relative">
          <button
            onClick={() => setShowNotificationsPopover(!showNotificationsPopover)}
            title="الإشعارات والتنبيهات الحية للمصنع"
            className={`relative p-2 rounded-xl border transition-all cursor-pointer ${
              showNotificationsPopover
                ? 'bg-blue-600 text-white border-blue-400 shadow-lg shadow-blue-600/30'
                : 'bg-slate-800/90 text-slate-300 border-slate-700 hover:border-slate-500 hover:text-white'
            }`}
          >
            <Bell className="w-4 h-4 sm:w-5 sm:h-5" />
            {unreadCount > 0 && (
              <span className="absolute -top-1.5 -right-1.5 flex items-center justify-center min-w-5 h-5 px-1 bg-rose-500 text-white font-bold text-[10px] rounded-full ring-2 ring-slate-900 animate-pulse">
                {unreadCount}
              </span>
            )}
          </button>

          {/* Notifications Dropdown Drawer / Popover */}
          {showNotificationsPopover && (
            <div className="absolute left-0 sm:right-0 sm:left-auto mt-2 w-80 sm:w-96 max-w-[90vw] bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl z-50 overflow-hidden animate-in fade-in slide-in-from-top-2">
              <div className="p-3.5 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="p-1.5 bg-blue-500/20 text-blue-400 rounded-lg">
                    <Bell className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="text-xs sm:text-sm font-bold text-white">إشعارات وتنبيهات المصنع</h3>
                    <p className="text-[10px] text-slate-400">مراقبة المخزون، الأعطال والصيانة الدوري</p>
                  </div>
                </div>
                {unreadCount > 0 && (
                  <button
                    onClick={handleMarkAllRead}
                    className="text-[11px] text-blue-400 hover:text-blue-300 underline font-medium cursor-pointer"
                  >
                    تحديد الكل كمقروء
                  </button>
                )}
              </div>

              {/* Filter Tabs */}
              <div className="flex border-b border-slate-800 bg-slate-900/80 p-1.5 gap-1 text-[11px]">
                <button
                  onClick={() => setActiveNotifFilter('all')}
                  className={`flex-1 py-1 px-2 rounded-lg font-medium transition cursor-pointer ${
                    activeNotifFilter === 'all'
                      ? 'bg-blue-600 text-white font-bold'
                      : 'text-slate-400 hover:bg-slate-800 hover:text-slate-200'
                  }`}
                >
                  الكل ({generatedNotifications.length})
                </button>
                <button
                  onClick={() => setActiveNotifFilter('stock')}
                  className={`flex-1 py-1 px-2 rounded-lg font-medium transition cursor-pointer ${
                    activeNotifFilter === 'stock'
                      ? 'bg-amber-600 text-white font-bold'
                      : 'text-slate-400 hover:bg-slate-800 hover:text-slate-200'
                  }`}
                >
                  المخزون
                </button>
                <button
                  onClick={() => setActiveNotifFilter('maintenance')}
                  className={`flex-1 py-1 px-2 rounded-lg font-medium transition cursor-pointer ${
                    activeNotifFilter === 'maintenance'
                      ? 'bg-rose-600 text-white font-bold'
                      : 'text-slate-400 hover:bg-slate-800 hover:text-slate-200'
                  }`}
                >
                  الصيانة
                </button>
              </div>

              {/* Notifications List */}
              <div className="max-h-80 overflow-y-auto divide-y divide-slate-800/60 p-1">
                {filteredNotifications.length === 0 ? (
                  <div className="py-8 text-center text-slate-500">
                    <Bell className="w-8 h-8 mx-auto mb-2 opacity-30" />
                    <p className="text-xs">لا توجد تنبيهات حالية لهذا الفلتر</p>
                  </div>
                ) : (
                  filteredNotifications.map((notif) => {
                    const isRead = readNotificationIds.includes(notif.id);

                    return (
                      <div
                        key={notif.id}
                        className={`p-3 rounded-xl transition flex flex-col gap-1.5 my-1 ${
                          isRead
                            ? 'bg-slate-900/40 opacity-75'
                            : notif.severity === 'high'
                            ? 'bg-rose-950/30 border border-rose-900/40'
                            : 'bg-amber-950/20 border border-amber-900/30'
                        }`}
                      >
                        <div className="flex items-start justify-between gap-2">
                          <div className="flex items-center gap-2">
                            <span
                              className={`w-2 h-2 rounded-full shrink-0 ${
                                isRead
                                  ? 'bg-slate-600'
                                  : notif.severity === 'high'
                                  ? 'bg-rose-500 animate-pulse'
                                  : 'bg-amber-400'
                              }`}
                            ></span>
                            <h4
                              className={`text-xs font-bold ${
                                notif.severity === 'high' ? 'text-rose-300' : 'text-amber-300'
                              }`}
                            >
                              {notif.title}
                            </h4>
                          </div>
                          <span className="text-[10px] text-slate-500 font-mono">{notif.time}</span>
                        </div>

                        <p className="text-[11px] text-slate-300 leading-relaxed pr-4">
                          {notif.message}
                        </p>

                        <div className="flex items-center justify-between pt-1 mt-1 border-t border-slate-800/40 text-[10px]">
                          <button
                            onClick={() => {
                              setActiveModule(notif.targetModule);
                              setShowNotificationsPopover(false);
                            }}
                            className="text-blue-400 hover:text-blue-300 font-bold flex items-center gap-1 cursor-pointer"
                          >
                            <span>الانتقال للشاشة المحددة</span>
                            <span>←</span>
                          </button>
                          <button
                            onClick={() => handleToggleRead(notif.id)}
                            className="text-slate-500 hover:text-slate-300 cursor-pointer"
                          >
                            {isRead ? 'تعليم كغير مقروء' : 'تم الاطلاع'}
                          </button>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>

              <div className="p-2 bg-slate-950 border-t border-slate-800 text-center text-[10px] text-slate-500">
                يتم تحديث التنبيهات تلقائياً بناءً على حركة المخازن والماكينات
              </div>
            </div>
          )}
        </div>

        {/* 1-Click App Installation Button */}
        <button
          onClick={handleTriggerInstall}
          title="تثبيت البرنامج فوراً كـ تطبيق أندرويد أوفلاين بدون إنترنت"
          className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold rounded-xl bg-blue-600 hover:bg-blue-500 text-white border border-blue-400/60 transition shadow-lg cursor-pointer"
        >
          <Sparkles className="w-3.5 h-3.5 text-amber-300 animate-spin" />
          <span className="hidden xs:inline">تثبيت التطبيق 📲</span>
        </button>

        {/* Quick Excel Export button */}
        <button
          onClick={handleExportAll}
          title="تصدير كافة بيانات المصنع والحسابات إلى ملف إكسل XLSX متكامل"
          className="flex items-center gap-2 px-3 py-1.5 text-xs font-medium rounded-xl bg-emerald-950/60 text-emerald-400 border border-emerald-800/60 hover:bg-emerald-900/60 transition shadow-sm cursor-pointer"
        >
          <FileSpreadsheet className="w-4 h-4 text-emerald-400" />
          <span className="hidden sm:inline">تصدير إكسل XLSX</span>
        </button>

        {/* Secret Owner Control Button */}
        {currentUser.role === 'owner' ? (
          <button
            onClick={() => {
              if (isOwnerSecretUnlocked) {
                setActiveModule('owner_secret');
              } else {
                setShowSecretPinModal(true);
              }
            }}
            className={`flex items-center gap-2 px-3.5 py-1.5 text-xs font-bold rounded-xl border transition cursor-pointer shadow-lg ${
              isOwnerSecretUnlocked
                ? 'bg-amber-500/20 text-amber-300 border-amber-500/60 ring-2 ring-amber-500/30'
                : 'bg-slate-800 text-slate-300 border-amber-500/30 hover:border-amber-400'
            }`}
          >
            <Shield className="w-4 h-4 text-amber-400 animate-pulse" />
            <span>لوحة المالك السرية</span>
            {isOwnerSecretUnlocked ? (
              <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
            ) : (
              <Lock className="w-3.5 h-3.5 text-amber-400" />
            )}
          </button>
        ) : (
          <button
            onClick={() =>
              alert('هذه لوحة سرية ومستقلة خاصة بالمالك فقط ومحمية بالكامل ولا تظهر لأي مستخدم آخر!')
            }
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-xl bg-slate-800/40 text-slate-500 border border-slate-800 cursor-not-allowed opacity-60"
            title="لوحة المالك سرية ومحظورة"
          >
            <Lock className="w-3.5 h-3.5" />
            <span className="hidden md:inline">محمية</span>
          </button>
        )}

        {/* Role Switcher Pill */}
        <button
          onClick={() => setShowRoleModal(true)}
          className="flex items-center gap-2 px-3 py-1.5 text-xs font-semibold rounded-xl bg-slate-800 border border-slate-700 hover:border-slate-500 transition cursor-pointer"
          title="تبديل صلاحية المستخدم لاختبار الشاشات والصلاحيات"
        >
          <Users className="w-4 h-4 text-blue-400" />
          <span className="hidden sm:inline">{currentUser.name.split(' ')[0]}</span>
          <span className={`px-2 py-0.5 rounded-full text-[10px] border ${badge.bg}`}>
            {badge.label.split(' ')[0]}
          </span>
        </button>
      </div>

      {/* Role Switcher Modal */}
      {showRoleModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-md w-full p-6 text-white shadow-2xl animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between pb-4 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-blue-400" />
                <h3 className="text-base font-bold">محاكي الأدوار والصلاحيات (RBAC)</h3>
              </div>
              <button
                onClick={() => setShowRoleModal(false)}
                className="text-slate-400 hover:text-white text-lg p-1"
              >
                ✕
              </button>
            </div>

            <p className="text-xs text-slate-400 my-4 leading-relaxed">
              اختر دوراً لتجربة النظام وصلاحياته الدقيقة. لاحظ كيف يتم إخفاء الأزرار أو حظر لوحة
              التحكم والعمليات وفقاً لصلاحيات كل دور:
            </p>

            <div className="space-y-2">
              {users.map((u) => {
                const b = getRoleBadge(u.role);
                const isSelected = u.id === currentUser.id;
                return (
                  <div
                    key={u.id}
                    onClick={() => {
                      switchUser(u.id);
                      setShowRoleModal(false);
                    }}
                    className={`p-3 rounded-xl border flex items-center justify-between cursor-pointer transition ${
                      isSelected
                        ? 'bg-blue-950/60 border-blue-500/80 shadow-md'
                        : 'bg-slate-950/50 border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-semibold">{u.name}</span>
                        <span className={`text-[10px] px-2 py-0.5 rounded-full border ${b.bg}`}>
                          {b.label}
                        </span>
                      </div>
                      <p className="text-xs text-slate-400 mt-1">اسم المستخدم: {u.username}</p>
                    </div>
                    {isSelected && <UserCheck className="w-5 h-5 text-blue-400" />}
                  </div>
                );
              })}
            </div>

            <div className="mt-6 pt-4 border-t border-slate-800 flex justify-end">
              <button
                onClick={() => setShowRoleModal(false)}
                className="px-4 py-2 text-xs font-semibold rounded-xl bg-slate-800 text-slate-200 hover:bg-slate-700 transition"
              >
                إغلاق
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Secret Owner PIN Verification Modal */}
      {showSecretPinModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4">
          <div className="bg-slate-900 border-2 border-amber-500/70 rounded-2xl max-w-sm w-full p-6 text-white shadow-2xl">
            <div className="flex flex-col items-center text-center">
              <div className="p-3 bg-amber-500/20 rounded-full border border-amber-500/40 mb-3 text-amber-400">
                <Lock className="w-8 h-8" />
              </div>
              <h3 className="text-lg font-bold text-amber-300">لوحة تحكم المالك السرية</h3>
              <p className="text-xs text-slate-400 mt-1">
                منطقة محمية بالكامل للمالك الرئيسي وحده. أدخل الرمز السري الفولاذي:
              </p>
              <span className="mt-2 text-[11px] text-slate-400 bg-slate-950/60 px-2.5 py-1 rounded-md border border-slate-800">
                منطقة سرية • التحقق المزدوج للسيادة الفردية للمالك
              </span>
            </div>

            <form onSubmit={handlePinSubmit} className="mt-5 space-y-4">
              <div>
                <input
                  type="password"
                  maxLength={6}
                  value={pinInput}
                  onChange={(e) => setPinInput(e.target.value)}
                  placeholder="أدخل رمز المالك (PIN)"
                  autoFocus
                  className="w-full text-center tracking-widest text-xl py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-amber-400 focus:outline-none focus:border-amber-400 font-mono"
                />
                {pinError && <p className="text-xs text-rose-400 mt-2 text-center">{pinError}</p>}
              </div>

              <div className="flex gap-2">
                <button
                  type="submit"
                  className="flex-1 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-sm transition shadow-lg cursor-pointer"
                >
                  فتح لوحة المالك
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setShowSecretPinModal(false);
                    setPinInput('');
                    setPinError('');
                  }}
                  className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-sm font-semibold transition"
                >
                  إلغاء
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </header>
  );
};
