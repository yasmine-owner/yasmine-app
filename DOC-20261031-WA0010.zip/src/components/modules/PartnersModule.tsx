/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  AlertCircle,
  Boxes,
  Building2,
  CheckCircle2,
  Coins,
  Cpu,
  Download,
  FileCheck,
  FileSpreadsheet,
  Info,
  Lock,
  Plus,
  Shield,
  UserCheck,
  Users2,
} from 'lucide-react';
import { useERP } from '../../context/ERPContext';
import * as XLSX from 'xlsx';

export const PartnersModule: React.FC = () => {
  const { partners, machines, inventory } = useERP();

  const totalContributions = partners.reduce((sum, p) => sum + p.initialContribution, 0);
  const totalMachineCost = machines.reduce((sum, m) => sum + m.purchaseCost, 0);
  const totalStockValue = inventory.reduce((sum, i) => sum + i.currentStock * i.movingAverageCost, 0);

  const exportPartnersToExcel = () => {
    const data = partners.map((p) => ({
      'اسم الشريك': p.name,
      'المساهمة المعتمدة (بالجنيه المصري)': p.initialContribution,
      'الرصيد الجاري الحالي (بالجنيه المصري)': p.currentBalance,
      'طريقة الإيداع': p.hasSubAccountInOtherPartner ? `بحساب ${p.hasSubAccountInOtherPartner}` : 'حساب مباشر',
      'الملاحظات القانونية': p.notes,
    }));
    const ws = XLSX.utils.json_to_sheet(data);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'مساهمات الشركاء');
    XLSX.writeFile(wb, 'Partners_Contributions_Report.xlsx');
  };

  return (
    <div className="space-y-6">
      {/* Top Banner explaining the 2,400,000 EGP investment and 250k medical stock */}
      <div className="p-6 rounded-3xl bg-gradient-to-l from-indigo-950/70 via-slate-900 to-slate-900 border border-indigo-800/40 shadow-xl">
        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="p-2 rounded-xl bg-indigo-600/20 text-indigo-400 border border-indigo-500/30">
                <Users2 className="w-6 h-6" />
              </span>
              <h2 className="text-xl font-bold text-white">
                ملف الشركاء والمساهمات الرأسمالية (2,400,000 جنيه مصري)
              </h2>
            </div>
            <p className="text-xs text-slate-300 max-w-3xl leading-relaxed">
              إجمالي مساهمات الشركاء الخمسة المعتمدة هو <strong>2,400,000 جنيه مصري</strong> (الشريك
              الأول: 800,000 جنيه مصري، الشريك الثاني: 800,000 جنيه مصري، الشريك الثالث: 400,000 جنيه
              مصري، الشريك الرابع: 200,000 جنيه مصري، الشريك الخامس: 200,000 جنيه مصري مودعة بحساب
              الشريك الثالث). تم توزيع كامل المبلغ بالتطابق التام على أصول الماكينات الطبية الدقيقة (2,150,000
              جنيه مصري) وبضاعة أول المدة بالمخزن للشرائح والمسامير الطبية (250,000 جنيه مصري) دون أي نقدية مكررة.
            </p>
          </div>

          <button
            onClick={exportPartnersToExcel}
            className="flex items-center gap-2 px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold transition cursor-pointer"
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-400" />
            <span>تصدير بيان الشركاء إكسل</span>
          </button>
        </div>

        {/* Audit Verification Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mt-6 pt-5 border-t border-slate-800">
          <div className="p-4 rounded-xl bg-slate-950/70 border border-slate-800">
            <span className="text-xs text-slate-400">إجمالي مساهمات الشركاء الخمسة</span>
            <p className="text-2xl font-bold text-indigo-400 font-mono mt-1">
              {totalContributions.toLocaleString()} جنيه مصري
            </p>
            <p className="text-[11px] text-slate-500 mt-1">تمويل معتمد بنسبة 100% للأصول والمخزون</p>
          </div>

          <div className="p-4 rounded-xl bg-slate-950/70 border border-slate-800">
            <span className="text-xs text-slate-400">تكلفة ماكينات ومعدات التصنيع الطبي</span>
            <p className="text-2xl font-bold text-emerald-400 font-mono mt-1">
              {totalMachineCost.toLocaleString()} جنيه مصري
            </p>
            <p className="text-[11px] text-emerald-400/80 mt-1 flex items-center gap-1">
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>ماكينات CNC ومكابس وكمبروسر معقم</span>
            </p>
          </div>

          <div className="p-4 rounded-xl bg-slate-950/70 border border-slate-800">
            <span className="text-xs text-slate-400">بضاعة أول المدة بالمخزن (شرائح ومسامير)</span>
            <p className="text-2xl font-bold text-cyan-400 font-mono mt-1">
              {totalStockValue.toLocaleString()} جنيه مصري
            </p>
            <p className="text-[11px] text-cyan-400 mt-1">
              شرائح ومسامير ومستلزمات طبية من نصيب الشركاء
            </p>
          </div>
        </div>
      </div>

      {/* Partners List Table */}
      <div className="rounded-2xl border border-slate-800 bg-slate-900 overflow-hidden shadow-xl">
        <div className="p-4 border-b border-slate-800 flex items-center justify-between">
          <h3 className="font-bold text-sm text-white flex items-center gap-2">
            <Coins className="w-4 h-4 text-amber-400" />
            <span>كشف حسابات ومساهمات الشركاء الخمسة</span>
          </h3>
          <span className="text-xs text-slate-400">
            * لا يتم توزيع أرباح أو افتراض نسب ملكية دون اعتماد رسمي
          </span>
        </div>

        <table className="w-full text-right text-xs">
          <thead className="bg-slate-950 text-slate-400 font-semibold border-b border-slate-800">
            <tr>
              <th className="p-3.5">اسم الشريك</th>
              <th className="p-3.5">المساهمة المعتمدة</th>
              <th className="p-3.5">مسار ومكان إيداع الأموال</th>
              <th className="p-3.5">الرصيد الجاري الحالي</th>
              <th className="p-3.5">الملاحظات القانونية والتدقيقية</th>
              <th className="p-3.5 text-center">أوجه الصرف</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800">
            {partners.map((partner) => (
              <tr key={partner.id} className="hover:bg-slate-800/40 transition">
                <td className="p-3.5 font-bold text-white flex items-center gap-2">
                  <UserCheck className="w-4 h-4 text-blue-400" />
                  <span>{partner.name}</span>
                </td>
                <td className="p-3.5 font-mono font-bold text-indigo-400 text-sm">
                  {partner.initialContribution.toLocaleString()} جنيه مصري
                </td>
                <td className="p-3.5">
                  {partner.hasSubAccountInOtherPartner ? (
                    <span className="px-2.5 py-1 rounded-full text-[11px] font-semibold bg-amber-950/60 text-amber-300 border border-amber-800/60">
                      مودع بحساب {partner.hasSubAccountInOtherPartner}
                    </span>
                  ) : (
                    <span className="px-2.5 py-1 rounded-full text-[11px] font-semibold bg-blue-950/60 text-blue-300 border border-blue-800/60">
                      إيداع مباشر
                    </span>
                  )}
                </td>
                <td className="p-3.5 font-mono font-bold text-white">
                  {partner.currentBalance.toLocaleString()} جنيه مصري
                </td>
                <td className="p-3.5 text-slate-300 max-w-sm">{partner.notes}</td>
                <td className="p-3.5 text-center">
                  <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-emerald-950/80 text-emerald-400 border border-emerald-800/50">
                    أصول ماكينات + بضاعة شرائح ومسامير
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Linked Assets and Stock Summary */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Machinery Assets */}
        <div className="rounded-2xl border border-slate-800 bg-slate-900 p-5 space-y-3 shadow-xl">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2.5">
            <div className="flex items-center gap-2">
              <Cpu className="w-5 h-5 text-emerald-400" />
              <h4 className="font-bold text-sm text-white">
                ماكينات التصنيع الطبي (2,150,000 جنيه مصري)
              </h4>
            </div>
            <span className="text-xs text-emerald-400 font-mono font-bold">أصول ثابتة</span>
          </div>

          <div className="space-y-2 text-xs">
            {machines.map((m) => (
              <div key={m.id} className="p-3 rounded-xl bg-slate-950 border border-slate-850 flex justify-between items-center">
                <div>
                  <span className="font-bold text-white block">{m.name}</span>
                  <span className="text-[10px] text-slate-400">{m.brand} • {m.location}</span>
                </div>
                <span className="font-mono font-bold text-emerald-400">
                  {m.purchaseCost.toLocaleString()} جنيه مصري
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Medical Stock Inventory (250,000 EGP) */}
        <div className="rounded-2xl border border-slate-800 bg-slate-900 p-5 space-y-3 shadow-xl">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2.5">
            <div className="flex items-center gap-2">
              <Boxes className="w-5 h-5 text-cyan-400" />
              <h4 className="font-bold text-sm text-white">
                بضاعة المخزن الطبية (250,000 جنيه مصري)
              </h4>
            </div>
            <span className="text-xs text-cyan-400 font-mono font-bold">بضاعة أول المدة</span>
          </div>

          <div className="space-y-2 text-xs">
            {inventory.map((item) => (
              <div key={item.id} className="p-3 rounded-xl bg-slate-950 border border-slate-850 flex justify-between items-center">
                <div>
                  <span className="font-bold text-white block">{item.name}</span>
                  <span className="text-[10px] text-slate-400 font-mono">
                    الرصيد: {item.currentStock} {item.unit}
                  </span>
                </div>
                <span className="font-mono font-bold text-cyan-400">
                  {(item.currentStock * item.movingAverageCost).toLocaleString()} جنيه مصري
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
