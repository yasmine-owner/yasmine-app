/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  Building2,
  Calendar,
  CheckCircle2,
  Cpu,
  FileSpreadsheet,
  Plus,
  TrendingDown,
} from 'lucide-react';
import { useERP } from '../../context/ERPContext';
import * as XLSX from 'xlsx';

export const FixedAssetsModule: React.FC = () => {
  const { machines, addJournalEntry } = useERP();

  const totalOriginalCost = machines.reduce((s, m) => s + m.purchaseCost, 0);
  const totalBookValue = machines.reduce((s, m) => s + m.currentBookValue, 0);
  const totalAccumulatedDepreciation = totalOriginalCost - totalBookValue;

  const handleGenerateDepreciationEntry = () => {
    // Generate monthly depreciation entry across machines
    const monthlyDepreciation = 18500;
    addJournalEntry({
      date: new Date().toISOString().slice(0, 10),
      description: 'إثبات قسط الإهلاك الشهري للماكينات ومعدات التشغيل الصناعية',
      referenceType: 'depreciation',
      lines: [
        {
          accountId: 'acc-56',
          accountCode: '5600',
          accountName: 'إهلاك الماكينات والمعدات الصناعية',
          debit: monthlyDepreciation,
          credit: 0,
          note: 'مصروف إهلاك شهري',
        },
        {
          accountId: 'acc-12',
          accountCode: '1200',
          accountName: 'الأصول الثابتة (الماكينات والمعدات)',
          debit: 0,
          credit: monthlyDepreciation,
          note: 'تخفيض القيمة الدفترية للأصول',
        },
      ],
    });
    alert('تم تسجيل وترحيل قيد الإهلاك بنجاح إلى كافة القوائم المالية والأستاذ العام!');
  };

  const exportAssetsToExcel = () => {
    const data = machines.map((m) => ({
      'كود الأصل': m.code,
      'اسم الأصل': m.name,
      'تاريخ الشراء': m.purchaseDate,
      'تكلفة الشراء الأصلية (جنيه مصري)': m.purchaseCost,
      'مجمع الإهلاك المحتسب (جنيه مصري)': m.purchaseCost - m.currentBookValue,
      'صافي القيمة الدفترية (جنيه مصري)': m.currentBookValue,
      'العمر الإنتاجي (سنوات)': m.usefulLifeYears,
      'معدل الإهلاك السنوي (%)': `${m.depreciationRateYearly}%`,
      'طريقة الإهلاك': 'القسط الثابت (Straight-Line)',
    }));
    const ws = XLSX.utils.json_to_sheet(data);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'سجل الأصول والإهلاك');
    XLSX.writeFile(wb, 'Fixed_Assets_Depreciation.xlsx');
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="p-6 rounded-3xl bg-gradient-to-l from-slate-900 via-slate-900 to-indigo-950/40 border border-slate-800 shadow-xl flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <span className="p-2 rounded-xl bg-indigo-600/20 text-indigo-400 border border-indigo-500/30">
              <Building2 className="w-6 h-6" />
            </span>
            <h2 className="text-xl font-bold text-white">
              سجل الأصول الثابتة ومجمع الإهلاك والقيمة الدفترية
            </h2>
          </div>
          <p className="text-xs text-slate-300 max-w-2xl leading-relaxed">
            وفقاً للبند 19: حصر شامل لكافة ماكينات ومعدات المصنع (بما فيها أصول مساهمات الـ 2.4 مليون
            جنيه)، واحتساب الإهلاك الدوري والقيمة الدفترية الصافية، والترحيل التلقائي لقيود
            الإهلاك.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleGenerateDepreciationEntry}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-lg transition cursor-pointer"
          >
            <TrendingDown className="w-4 h-4" />
            <span>ترحيل قيد إهلاك شهري</span>
          </button>
          <button
            onClick={exportAssetsToExcel}
            className="flex items-center gap-2 px-3.5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold transition cursor-pointer"
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-400" />
            <span>تصدير إكسل</span>
          </button>
        </div>
      </div>

      {/* Asset Aggregates */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800">
          <span className="text-xs text-slate-400 font-semibold">إجمالي التكلفة التاريخية للشراء</span>
          <p className="text-2xl font-bold text-white font-mono mt-1">
            {totalOriginalCost.toLocaleString()} ج
          </p>
          <span className="text-[11px] text-slate-500">تمويل الشركاء المعتمد 2.4M ج</span>
        </div>

        <div className="p-5 rounded-2xl bg-rose-950/40 border border-rose-800/50">
          <span className="text-xs text-rose-400 font-semibold">مجمع الإهلاك المتراكم</span>
          <p className="text-2xl font-bold text-rose-400 font-mono mt-1">
            {totalAccumulatedDepreciation.toLocaleString()} ج
          </p>
          <span className="text-[11px] text-slate-400">إهلاك تدريجي معتمد سنوياً</span>
        </div>

        <div className="p-5 rounded-2xl bg-emerald-950/40 border border-emerald-800/50">
          <span className="text-xs text-emerald-400 font-semibold">صافي القيمة الدفترية الحالية</span>
          <p className="text-2xl font-bold text-emerald-400 font-mono mt-1">
            {totalBookValue.toLocaleString()} جنيه مصري
          </p>
          <span className="text-[11px] text-emerald-400/80">المقيدة في قائمة المركز المالي</span>
        </div>
      </div>

      {/* Assets Table */}
      <div className="rounded-2xl border border-slate-800 bg-slate-900 overflow-hidden shadow-xl">
        <table className="w-full text-right text-xs">
          <thead className="bg-slate-950 text-slate-400 font-semibold border-b border-slate-800">
            <tr>
              <th className="p-3.5">كود الأصل</th>
              <th className="p-3.5">اسم الماكينة / الأصل</th>
              <th className="p-3.5">تاريخ الشراء</th>
              <th className="p-3.5">تكلفة الشراء (جنيه مصري)</th>
              <th className="p-3.5">مجمع الإهلاك (جنيه مصري)</th>
              <th className="p-3.5">صافي القيمة الدفترية (جنيه مصري)</th>
              <th className="p-3.5">العمر الإنتاجي</th>
              <th className="p-3.5">طريقة الإهلاك</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800">
            {machines.map((m) => (
              <tr key={m.id} className="hover:bg-slate-800/40 transition">
                <td className="p-3.5 font-mono font-bold text-indigo-400">{m.code}</td>
                <td className="p-3.5 font-bold text-white">{m.name}</td>
                <td className="p-3.5 text-slate-300">{m.purchaseDate}</td>
                <td className="p-3.5 font-mono font-bold text-white">
                  {m.purchaseCost.toLocaleString()} جنيه مصري
                </td>
                <td className="p-3.5 font-mono text-rose-400 font-bold">
                  {(m.purchaseCost - m.currentBookValue).toLocaleString()} جنيه مصري
                </td>
                <td className="p-3.5 font-mono text-emerald-400 font-bold">
                  {m.currentBookValue.toLocaleString()} جنيه مصري
                </td>
                <td className="p-3.5 text-slate-300 font-mono">{m.usefulLifeYears} سنوات</td>
                <td className="p-3.5 text-slate-400">القسط الثابت ({m.depreciationRateYearly}%)</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};
