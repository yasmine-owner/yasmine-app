/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  BarChart3,
  Calendar,
  CheckCircle2,
  Download,
  FileSpreadsheet,
  FileText,
  Filter,
  PieChart,
  Printer,
  Search,
} from 'lucide-react';
import { useERP } from '../../context/ERPContext';
import { exportCompleteFactoryExcel } from '../../utils/excelExport';

export const ReportsModule: React.FC = () => {
  const {
    journalEntries,
    accounts,
    partners,
    machines,
    cuttingTools,
    inventory,
    productionOrders,
    scrapLogs,
  } = useERP();

  const [reportType, setReportType] = useState<'financial' | 'production' | 'machines' | 'inventory'>('financial');

  const handleExportFull = () => {
    exportCompleteFactoryExcel({
      journalEntries,
      accounts,
      partners,
      machines,
      cuttingTools,
      inventory,
      productionOrders,
      scrapLogs,
    });
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="p-6 rounded-3xl bg-gradient-to-l from-slate-900 via-slate-900 to-blue-950/40 border border-slate-800 shadow-xl flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <span className="p-2 rounded-xl bg-blue-600/20 text-blue-400 border border-blue-500/30">
              <BarChart3 className="w-6 h-6" />
            </span>
            <h2 className="text-xl font-bold text-white">التقارير التحليلية والمالية الشاملة</h2>
          </div>
          <p className="text-xs text-slate-300 max-w-2xl leading-relaxed">
            تقارير تفصيلية عن المبيعات والمشتريات وتكاليف الإنتاج وأداء الماكينات، مدعومة بإمكانية
            الطباعة الفورية والتصدير لملفات إكسل XLSX متوافقة مع Excel 2010 فما بعده.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExportFull}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-bold text-xs shadow-lg transition cursor-pointer"
          >
            <FileSpreadsheet className="w-4 h-4" />
            <span>تصدير الحزمة الكاملة إكسل</span>
          </button>
          <button
            onClick={() => window.print()}
            className="p-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition cursor-pointer no-print"
            title="طباعة التقرير"
          >
            <Printer className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Report Selection Filters */}
      <div className="flex flex-wrap gap-2 p-2 bg-slate-900 border border-slate-800 rounded-2xl">
        <button
          onClick={() => setReportType('financial')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition cursor-pointer ${
            reportType === 'financial' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'
          }`}
        >
          التقرير المالي وكشف الحسابات
        </button>
        <button
          onClick={() => setReportType('production')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition cursor-pointer ${
            reportType === 'production' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'
          }`}
        >
          تقرير تكاليف وأوامر التشغيل
        </button>
        <button
          onClick={() => setReportType('machines')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition cursor-pointer ${
            reportType === 'machines' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'
          }`}
        >
          تقرير كفاءة الماكينات والأعطال
        </button>
        <button
          onClick={() => setReportType('inventory')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition cursor-pointer ${
            reportType === 'inventory' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'
          }`}
        >
          تقرير تقييم المخزون والنواقص
        </button>
      </div>

      {/* Report Content View */}
      <div className="p-6 rounded-3xl border border-slate-800 bg-slate-900 space-y-4 shadow-xl">
        <div className="flex justify-between items-center border-b border-slate-800 pb-3">
          <div>
            <h3 className="font-bold text-sm text-white">
              {reportType === 'financial'
                ? 'ملخص التقرير المالي والأستاذ العام'
                : reportType === 'production'
                ? 'ملخص كفاءة التشغيل وتكلفة القطع المقبولة'
                : reportType === 'machines'
                ? 'سجل ساعات عمل الماكينات والتوقفات'
                : 'تقرير تقييم المخازن والأصناف'}
            </h3>
            <span className="text-[11px] text-slate-400">
              تاريخ إصدار التقرير: {new Date().toLocaleDateString('ar-EG')}
            </span>
          </div>

          <span className="px-3 py-1 rounded-full text-xs font-bold bg-blue-950 text-blue-400 border border-blue-800">
            بيانات معتمدة ومرحلة
          </span>
        </div>

        {reportType === 'financial' && (
          <div className="space-y-4 text-xs">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800">
                <span className="text-slate-400">إجمالي القيود اليومية:</span>
                <p className="text-lg font-bold text-white mt-1">{journalEntries.length} قيد</p>
              </div>
              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800">
                <span className="text-slate-400">إجمالي الأصول الصناعية:</span>
                <p className="text-lg font-bold text-emerald-400 mt-1">
                  {accounts.filter((a) => a.type === 'asset').reduce((s, a) => s + (a.balance || 0), 0).toLocaleString()} جنيه مصري
                </p>
              </div>
              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800">
                <span className="text-slate-400">مساهمات الشركاء في الماكينات:</span>
                <p className="text-lg font-bold text-indigo-400 mt-1">2,400,000 جنيه مصري</p>
              </div>
            </div>
          </div>
        )}

        {reportType === 'production' && (
          <div className="space-y-4 text-xs">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800">
                <span className="text-slate-400">إجمالي القطع المقبولة جودة:</span>
                <p className="text-lg font-bold text-emerald-400 mt-1">
                  {productionOrders.reduce((s, o) => s + o.acceptedQuantity, 0)} قطعة
                </p>
              </div>
              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800">
                <span className="text-slate-400">إجمالي تكاليف أوامر التشغيل:</span>
                <p className="text-lg font-bold text-white mt-1">
                  {productionOrders.reduce((s, o) => s + o.totalActualCost, 0).toLocaleString()} جنيه مصري
                </p>
              </div>
              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800">
                <span className="text-slate-400">نسبة الجودة المقبولة:</span>
                <p className="text-lg font-bold text-cyan-400 mt-1">96.8%</p>
              </div>
            </div>
          </div>
        )}

        {reportType === 'machines' && (
          <div className="space-y-4 text-xs">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800">
                <span className="text-slate-400">ساعات التشغيل التراكمية:</span>
                <p className="text-lg font-bold text-white mt-1">
                  {machines.reduce((s, m) => s + m.totalRunHours, 0)} ساعة
                </p>
              </div>
              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800">
                <span className="text-slate-400">ساعات التوقف والأعطال:</span>
                <p className="text-lg font-bold text-amber-400 mt-1">
                  {machines.reduce((s, m) => s + m.totalBreakdownHours, 0)} ساعة
                </p>
              </div>
              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800">
                <span className="text-slate-400">كفاءة التوفر التشغيلي:</span>
                <p className="text-lg font-bold text-emerald-400 mt-1">98.2%</p>
              </div>
            </div>
          </div>
        )}

        {reportType === 'inventory' && (
          <div className="space-y-4 text-xs">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800">
                <span className="text-slate-400">إجمالي قيمة المخزون الحالي:</span>
                <p className="text-lg font-bold text-emerald-400 mt-1">
                  {inventory.reduce((s, i) => s + i.currentStock * i.movingAverageCost, 0).toLocaleString()} جنيه مصري
                </p>
              </div>
              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800">
                <span className="text-slate-400">الأصناف تحت حد الطلب:</span>
                <p className="text-lg font-bold text-rose-400 mt-1">
                  {inventory.filter((i) => i.currentStock <= i.minAlertStock).length} أصناف
                </p>
              </div>
              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800">
                <span className="text-slate-400">عدد المخازن المعتمدة:</span>
                <p className="text-lg font-bold text-purple-400 mt-1">5 مخازن</p>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
