/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  AlertCircle,
  CheckCircle2,
  ChevronDown,
  ChevronUp,
  Clock,
  Cpu,
  Factory,
  FileSpreadsheet,
  Layers,
  Plus,
  Printer,
  Search,
  Wrench,
  XCircle,
} from 'lucide-react';
import { useERP } from '../../context/ERPContext';
import * as XLSX from 'xlsx';

export const ManufacturingModule: React.FC = () => {
  const {
    productionOrders,
    boms,
    machines,
    addProductionOrder,
    updateProductionOrder,
  } = useERP();

  const [activeTab, setActiveTab] = useState<'orders' | 'boms'>('orders');
  const [searchTerm, setSearchTerm] = useState('');
  const [showAddOrderModal, setShowAddOrderModal] = useState(false);
  const [selectedOrder, setSelectedOrder] = useState<any | null>(null);

  // Form State
  const [orderProductName, setOrderProductName] = useState('');
  const [orderQty, setOrderQty] = useState(100);
  const [assignedMachine, setAssignedMachine] = useState(machines[0]?.id || '');
  const [assignedOperator, setAssignedOperator] = useState('فني التشغيل CNC');
  const [matCost, setMatCost] = useState(25000);
  const [laborCost, setLaborCost] = useState(4500);
  const [machCost, setMachCost] = useState(9500);
  const [toolCost, setToolCost] = useState(1800);

  const handleCreateOrder = (e: React.FormEvent) => {
    e.preventDefault();
    const totalCost = Number(matCost) + Number(laborCost) + Number(machCost) + Number(toolCost);

    addProductionOrder({
      productName: orderProductName || 'قطعة ميكانيكية مخصصة',
      requiredQuantity: Number(orderQty),
      assignedMachineId: assignedMachine,
      assignedOperator,
      actualMaterialCost: Number(matCost),
      actualDirectLaborCost: Number(laborCost),
      actualMachineOperatingCost: Number(machCost),
      actualToolingCost: Number(toolCost),
      totalActualCost: totalCost,
      costPerAcceptedUnit: 0,
      startDate: new Date().toISOString().slice(0, 10),
      expectedEndDate: new Date(Date.now() + 7 * 86400000).toISOString().slice(0, 10),
    });

    setShowAddOrderModal(false);
    setOrderProductName('');
  };

  const handleUpdateStatus = (id: string, accepted: number, rejected: number, reworked: number) => {
    const totalProduced = accepted + rejected + reworked;
    updateProductionOrder(id, {
      producedQuantity: totalProduced,
      acceptedQuantity: accepted,
      rejectedQuantity: rejected,
      reworkedQuantity: reworked,
      status: 'completed',
    });
  };

  const exportOrdersToExcel = () => {
    const rows = productionOrders.map((o) => ({
      'رقم أمر التشغيل': o.orderNumber,
      'المنتج': o.productName,
      'الكمية المطلوبة': o.requiredQuantity,
      'الكمية المنتجة': o.producedQuantity,
      'المقبول جودة': o.acceptedQuantity,
      'المرفوض': o.rejectedQuantity,
      'المعاد تشغيله': o.reworkedQuantity,
      'تكلفة الخامات (جنيه مصري)': o.actualMaterialCost,
      'تكلفة العمالة (جنيه مصري)': o.actualDirectLaborCost,
      'تكلفة الماكينات (جنيه مصري)': o.actualMachineOperatingCost,
      'تكلفة العدد (جنيه مصري)': o.actualToolingCost,
      'إجمالي التكلفة (جنيه مصري)': o.totalActualCost,
      'تكلفة القطعة المقبولة (جنيه مصري)': o.costPerAcceptedUnit,
      'الحالة': o.status,
    }));
    const ws = XLSX.utils.json_to_sheet(rows);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'أوامر الإنتاج والتصنيع');
    XLSX.writeFile(wb, 'Production_Orders_Costing.xlsx');
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="p-6 rounded-3xl bg-gradient-to-l from-cyan-950/70 via-slate-900 to-slate-900 border border-cyan-800/40 shadow-xl">
        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="p-2 rounded-xl bg-cyan-600/20 text-cyan-400 border border-cyan-500/30">
                <Factory className="w-6 h-6" />
              </span>
              <h2 className="text-xl font-bold text-white">
                إدارة التصنيع وأوامر الإنتاج وتكاليف التشغيل (Shop Floor & BOM)
              </h2>
            </div>
            <p className="text-xs text-slate-300 max-w-3xl leading-relaxed">
              متابعة أوامر التشغيل الصناعية من لحظة الإطلاق حتى دخول المخزن، مع رصد دقيق للمنتج
              المقبول والمرفوض والهالك، واحتساب التكلفة الفعلية لكل قطعة مقبولة تشمل الخامات، العمالة،
              ساعات عمل الماكينات، واستهلاك أدوات القطع.
            </p>
          </div>

          <div className="flex items-center gap-2.5">
            <button
              onClick={() => setShowAddOrderModal(true)}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-bold text-xs shadow-lg shadow-cyan-600/20 transition cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>إطلاق أمر إنتاج جديد</span>
            </button>
            <button
              onClick={exportOrdersToExcel}
              className="flex items-center gap-2 px-3.5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold transition"
            >
              <FileSpreadsheet className="w-4 h-4 text-emerald-400" />
              <span>تصدير إكسل</span>
            </button>
          </div>
        </div>

        {/* Quick summary stats */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-6 pt-5 border-t border-slate-800">
          <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800">
            <span className="text-[11px] text-slate-400">إجمالي أوامر الإنتاج</span>
            <p className="text-lg font-bold text-white mt-0.5">{productionOrders.length} أمر</p>
          </div>
          <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800">
            <span className="text-[11px] text-slate-400">أوامر منجزة بالكامل</span>
            <p className="text-lg font-bold text-emerald-400 mt-0.5">
              {productionOrders.filter((o) => o.status === 'completed').length} منجز
            </p>
          </div>
          <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800">
            <span className="text-[11px] text-slate-400">أوامر قيد التشغيل</span>
            <p className="text-lg font-bold text-cyan-400 mt-0.5">
              {productionOrders.filter((o) => o.status === 'in_progress').length} على الماكينات
            </p>
          </div>
          <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800">
            <span className="text-[11px] text-slate-400">متوسط كفاءة الجودة</span>
            <p className="text-lg font-bold text-emerald-400 mt-0.5">96.8% جودة مقبولة</p>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-2 p-1.5 bg-slate-900 border border-slate-800 rounded-2xl w-fit">
        <button
          onClick={() => setActiveTab('orders')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition cursor-pointer ${
            activeTab === 'orders' ? 'bg-cyan-600 text-slate-950' : 'text-slate-400 hover:text-white'
          }`}
        >
          أوامر الإنتاج والتكاليف الفعلية
        </button>
        <button
          onClick={() => setActiveTab('boms')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition cursor-pointer ${
            activeTab === 'boms' ? 'bg-cyan-600 text-slate-950' : 'text-slate-400 hover:text-white'
          }`}
        >
          قوائم المواد ومراحل التشغيل (BOM)
        </button>
      </div>

      {activeTab === 'orders' && (
        <div className="space-y-4">
          <div className="rounded-2xl border border-slate-800 bg-slate-900 overflow-hidden shadow-xl">
            <table className="w-full text-right text-xs">
              <thead className="bg-slate-950 text-slate-400 font-semibold border-b border-slate-800">
                <tr>
                  <th className="p-3.5">رقم أمر التشغيل</th>
                  <th className="p-3.5">اسم المشغولة / المنتج</th>
                  <th className="p-3.5">الكمية المطلوبة</th>
                  <th className="p-3.5">المقبول جودة</th>
                  <th className="p-3.5">المرفوض / معاد</th>
                  <th className="p-3.5">إجمالي التكلفة (جنيه مصري)</th>
                  <th className="p-3.5">تكلفة القطعة المقبولة (جنيه مصري)</th>
                  <th className="p-3.5">الحالة</th>
                  <th className="p-3.5 text-center">الإجراءات</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800">
                {productionOrders.map((order) => {
                  const machine = machines.find((m) => m.id === order.assignedMachineId);

                  return (
                    <tr key={order.id} className="hover:bg-slate-800/40 transition">
                      <td className="p-3.5 font-mono font-bold text-cyan-400">{order.orderNumber}</td>
                      <td className="p-3.5 font-semibold text-white">
                        <div>{order.productName}</div>
                        <span className="text-[10px] text-slate-400">
                          الماكينة: {machine?.name.split('(')[0] || 'CNC'}
                        </span>
                      </td>
                      <td className="p-3.5 font-mono font-bold text-slate-200">
                        {order.requiredQuantity} قطعة
                      </td>
                      <td className="p-3.5 font-mono font-bold text-emerald-400">
                        {order.acceptedQuantity} قطعة
                      </td>
                      <td className="p-3.5 font-mono text-rose-400 font-semibold">
                        {order.rejectedQuantity} مرفوض ({order.reworkedQuantity} معاد)
                      </td>
                      <td className="p-3.5 font-mono font-bold text-white">
                        {order.totalActualCost.toLocaleString()} جنيه مصري
                      </td>
                      <td className="p-3.5 font-mono font-bold text-cyan-300">
                        {order.costPerAcceptedUnit > 0
                          ? `${order.costPerAcceptedUnit.toLocaleString()} جنيه مصري لكل قطعة`
                          : 'تحت الحساب'}
                      </td>
                      <td className="p-3.5">
                        <span
                          className={`px-2.5 py-1 rounded-full text-[10px] font-bold border ${
                            order.status === 'completed'
                              ? 'bg-emerald-950 text-emerald-400 border-emerald-800'
                              : 'bg-cyan-950 text-cyan-400 border-cyan-800'
                          }`}
                        >
                          {order.status === 'completed' ? 'منجز وتام' : 'قيد التشغيل'}
                        </span>
                      </td>
                      <td className="p-3.5 text-center">
                        {order.status !== 'completed' && (
                          <button
                            onClick={() =>
                              handleUpdateStatus(
                                order.id,
                                Math.floor(order.requiredQuantity * 0.95),
                                Math.floor(order.requiredQuantity * 0.03),
                                Math.floor(order.requiredQuantity * 0.02)
                              )
                            }
                            className="px-2.5 py-1 rounded-lg bg-emerald-950 text-emerald-400 border border-emerald-800 text-[11px] font-bold hover:bg-emerald-900 cursor-pointer"
                          >
                            إنهاء واعتماد الجودة
                          </button>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {activeTab === 'boms' && (
        <div className="space-y-4">
          {boms.map((bom) => (
            <div key={bom.id} className="p-6 rounded-2xl border border-slate-800 bg-slate-900 space-y-4">
              <div className="flex justify-between items-center border-b border-slate-800 pb-3">
                <div>
                  <h4 className="font-bold text-base text-white">{bom.productName}</h4>
                  <p className="text-xs text-slate-400">
                    كود المنتج: {bom.productCode} • الإصدار: {bom.version}
                  </p>
                </div>
                <div className="text-left">
                  <span className="text-xs text-slate-400">التكلفة التقديرية للقطعة:</span>
                  <p className="font-mono text-lg font-bold text-emerald-400">
                    {bom.totalEstimatedCost} ج
                  </p>
                </div>
              </div>

              {/* BOM Materials */}
              <div>
                <h5 className="text-xs font-bold text-slate-300 mb-2">1. الخامات ومستلزمات الإنتاج:</h5>
                <div className="space-y-1 text-xs">
                  {bom.rawMaterials.map((mat, i) => (
                    <div key={i} className="flex justify-between p-2 rounded-lg bg-slate-950 border border-slate-800">
                      <span className="text-slate-200">
                        {mat.itemName} ({mat.quantity} {mat.unit})
                      </span>
                      <span className="font-mono text-slate-300">
                        {mat.quantity * mat.unitCost} ج (هالك متوقع: {mat.expectedScrapRate * 100}%)
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Operations */}
              <div>
                <h5 className="text-xs font-bold text-slate-300 mb-2">2. مراحل التشغيل والماكينات:</h5>
                <div className="space-y-1 text-xs">
                  {bom.operations.map((op, i) => (
                    <div key={i} className="flex justify-between p-2 rounded-lg bg-slate-950 border border-slate-800">
                      <span className="text-slate-200">
                        {op.operationName} - {op.machineName} ({op.cycleTimeMinutes} دقيقة)
                      </span>
                      <span className="font-mono text-cyan-400">
                        معدل تشغيل: {op.hourlyRate} جنيه مصري لكل ساعة
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* New Order Modal */}
      {showAddOrderModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-3xl max-w-lg w-full p-6 text-white shadow-2xl">
            <h3 className="text-base font-bold text-white mb-4">إصدار أمر إنتاج وتشغيل جديد</h3>
            <form onSubmit={handleCreateOrder} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-400 font-semibold mb-1">اسم المشغولة / المنتج</label>
                <input
                  type="text"
                  value={orderProductName}
                  onChange={(e) => setOrderProductName(e.target.value)}
                  placeholder="مثال: شافت صلب 80 مم أو جلبة نحاسية..."
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-cyan-500"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-400 font-semibold mb-1">الكمية المطلوبة</label>
                  <input
                    type="number"
                    min="1"
                    value={orderQty}
                    onChange={(e) => setOrderQty(parseInt(e.target.value) || 1)}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white font-mono focus:outline-none focus:border-cyan-500"
                    required
                  />
                </div>
                <div>
                  <label className="block text-slate-400 font-semibold mb-1">الماكينة المخصصة</label>
                  <select
                    value={assignedMachine}
                    onChange={(e) => setAssignedMachine(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-cyan-500"
                  >
                    {machines.map((m) => (
                      <option key={m.id} value={m.id}>
                        {m.name.split('(')[0]}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-400 font-semibold mb-1">تكلفة الخامات (جنيه مصري)</label>
                  <input
                    type="number"
                    value={matCost}
                    onChange={(e) => setMatCost(parseFloat(e.target.value) || 0)}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white font-mono focus:outline-none focus:border-cyan-500"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 font-semibold mb-1">تكلفة أجور العمالة (جنيه مصري)</label>
                  <input
                    type="number"
                    value={laborCost}
                    onChange={(e) => setLaborCost(parseFloat(e.target.value) || 0)}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white font-mono focus:outline-none focus:border-cyan-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-400 font-semibold mb-1">تكلفة تشغيل الماكينة (جنيه مصري)</label>
                  <input
                    type="number"
                    value={machCost}
                    onChange={(e) => setMachCost(parseFloat(e.target.value) || 0)}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white font-mono focus:outline-none focus:border-cyan-500"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 font-semibold mb-1">استهلاك أدوات القطع (جنيه مصري)</label>
                  <input
                    type="number"
                    value={toolCost}
                    onChange={(e) => setToolCost(parseFloat(e.target.value) || 0)}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white font-mono focus:outline-none focus:border-cyan-500"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowAddOrderModal(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 font-semibold"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-bold transition shadow-lg"
                >
                  إصدار أمر التشغيل
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
