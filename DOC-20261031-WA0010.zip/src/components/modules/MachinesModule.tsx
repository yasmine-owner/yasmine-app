/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  Activity,
  AlertTriangle,
  CheckCircle2,
  Clock,
  Cpu,
  FileSpreadsheet,
  Gauge,
  Plus,
  Power,
  Wrench,
  Zap,
} from 'lucide-react';
import { useERP } from '../../context/ERPContext';
import * as XLSX from 'xlsx';

export const MachinesModule: React.FC = () => {
  const { machines, updateMachineStatus, addMachine } = useERP();
  const [showAddModal, setShowAddModal] = useState(false);

  // Form
  const [code, setCode] = useState('');
  const [name, setName] = useState('');
  const [brand, setBrand] = useState('');
  const [model, setModel] = useState('');
  const [cost, setCost] = useState(500000);
  const [hourlyCost, setHourlyCost] = useState(150);
  const [power, setPower] = useState(15);

  const handleAddMachine = (e: React.FormEvent) => {
    e.preventDefault();
    addMachine({
      code: code || `M-${machines.length + 1}`,
      name: name || 'ماكينة صناعية',
      type: 'ماكينة تشغيل ميكانيكي',
      brand,
      model,
      purchaseDate: new Date().toISOString().slice(0, 10),
      purchaseCost: Number(cost),
      currentBookValue: Number(cost),
      usefulLifeYears: 10,
      depreciationRateYearly: 10,
      status: 'running',
      location: 'عنبر التشغيل',
      totalRunHours: 0,
      totalBreakdownHours: 0,
      hourlyOperatingCost: Number(hourlyCost),
      powerConsumptionKw: Number(power),
    });
    setShowAddModal(false);
  };

  const exportMachinesToExcel = () => {
    const data = machines.map((m) => ({
      'كود الماكينة': m.code,
      'الاسم': m.name,
      'الموديل': `${m.brand} - ${m.model}`,
      'تكلفة الشراء (جنيه مصري)': m.purchaseCost,
      'القيمة الدفترية (جنيه مصري)': m.currentBookValue,
      'ساعات التشغيل': m.totalRunHours,
      'ساعات الأعطال': m.totalBreakdownHours,
      'معدل تكلفة الساعة (جنيه مصري)': m.hourlyOperatingCost,
      'استهلاك الكهرباء (كيلوواط)': m.powerConsumptionKw,
      'الحالة': m.status,
    }));
    const ws = XLSX.utils.json_to_sheet(data);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'سجل الماكينات والمعدات');
    XLSX.writeFile(wb, 'Factory_Machines_Registry.xlsx');
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="p-6 rounded-3xl bg-gradient-to-l from-slate-900 via-slate-900 to-blue-950/40 border border-slate-800 shadow-xl flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <span className="p-2 rounded-xl bg-blue-600/20 text-blue-400 border border-blue-500/30">
              <Cpu className="w-6 h-6" />
            </span>
            <h2 className="text-xl font-bold text-white">
              سجل الماكينات والمعدات الصناعية والصيانة
            </h2>
          </div>
          <p className="text-xs text-slate-300 max-w-2xl leading-relaxed">
            متابعة الحالة التشغيلية لخطوط الإنتاج وماكينات CNC، ساعات العمل الفعلية، ساعات الأعطال،
            وتكلفة التشغيل لكل ساعة تشمل الكهرباء والصيانة الدورية.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowAddModal(true)}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs shadow-lg transition cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>إضافة ماكينة جديدة</span>
          </button>
          <button
            onClick={exportMachinesToExcel}
            className="flex items-center gap-2 px-3.5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold transition"
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-400" />
            <span>تصدير إكسل</span>
          </button>
        </div>
      </div>

      {/* Machinery Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {machines.map((m) => {
          const isRunning = m.status === 'running';

          return (
            <div
              key={m.id}
              className="p-6 rounded-3xl border border-slate-800 bg-slate-900 space-y-4 shadow-xl hover:border-slate-700 transition"
            >
              <div className="flex items-start justify-between">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="font-mono text-xs text-blue-400 font-bold bg-blue-950 px-2 py-0.5 rounded border border-blue-800">
                      {m.code}
                    </span>
                    <h3 className="font-bold text-base text-white">{m.name}</h3>
                  </div>
                  <p className="text-xs text-slate-400">
                    {m.brand} • {m.model} • {m.location}
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <select
                    value={m.status}
                    onChange={(e) => updateMachineStatus(m.id, e.target.value as any)}
                    className={`px-3 py-1 rounded-xl text-xs font-bold border focus:outline-none cursor-pointer ${
                      isRunning
                        ? 'bg-emerald-950 text-emerald-400 border-emerald-800'
                        : m.status === 'maintenance'
                        ? 'bg-amber-950 text-amber-400 border-amber-800'
                        : 'bg-rose-950 text-rose-400 border-rose-800'
                    }`}
                  >
                    <option value="running">🟢 تعمل بالإنتاج</option>
                    <option value="idle">🟡 جاهزة ومتوقفة</option>
                    <option value="maintenance">🟠 صيانة دورية</option>
                    <option value="breakdown">🔴 عطل مفاجئ</option>
                  </select>
                </div>
              </div>

              {/* Stats */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-3 border-t border-slate-800 text-xs">
                <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-850">
                  <span className="text-[10px] text-slate-400 flex items-center gap-1">
                    <Clock className="w-3 h-3 text-blue-400" />
                    <span>ساعات العمل</span>
                  </span>
                  <p className="font-mono font-bold text-white mt-1">{m.totalRunHours} ساعة</p>
                </div>
                <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-850">
                  <span className="text-[10px] text-slate-400 flex items-center gap-1">
                    <AlertTriangle className="w-3 h-3 text-amber-400" />
                    <span>ساعات الأعطال</span>
                  </span>
                  <p className="font-mono font-bold text-amber-400 mt-1">{m.totalBreakdownHours} ساعة</p>
                </div>
                <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-850">
                  <span className="text-[10px] text-slate-400 flex items-center gap-1">
                    <Gauge className="w-3 h-3 text-emerald-400" />
                    <span>تكلفة الساعة</span>
                  </span>
                  <p className="font-mono font-bold text-emerald-400 mt-1">
                    {m.hourlyOperatingCost} جنيه مصري / ساعة
                  </p>
                </div>
                <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-850">
                  <span className="text-[10px] text-slate-400 flex items-center gap-1">
                    <Zap className="w-3 h-3 text-cyan-400" />
                    <span>استهلاك القدرة</span>
                  </span>
                  <p className="font-mono font-bold text-cyan-400 mt-1">
                    {m.powerConsumptionKw} كيلوواط
                  </p>
                </div>
              </div>

              <div className="flex justify-between items-center text-xs pt-2 border-t border-slate-800 text-slate-400">
                <span>
                  تاريخ الشراء: <strong className="text-slate-200">{m.purchaseDate}</strong>
                </span>
                <span>
                  القيمة الدفترية الحالية:{' '}
                  <strong className="text-emerald-400 font-mono">
                    {m.currentBookValue.toLocaleString()} جنيه مصري
                  </strong>
                </span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Add Machine Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-3xl max-w-md w-full p-6 text-white shadow-2xl">
            <h3 className="text-base font-bold text-white mb-4">إضافة ماكينة أو معدة جديدة</h3>
            <form onSubmit={handleAddMachine} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-400 font-semibold mb-1">اسم الماكينة</label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="مثال: مخرطة CNC أو فريزة عمودية..."
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-blue-500"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-400 font-semibold mb-1">الشركة المصنعة</label>
                  <input
                    type="text"
                    value={brand}
                    onChange={(e) => setBrand(e.target.value)}
                    placeholder="مثال: DMTG, Haas, Fanuc"
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 font-semibold mb-1">الموديل والكود</label>
                  <input
                    type="text"
                    value={model}
                    onChange={(e) => setModel(e.target.value)}
                    placeholder="VMC-1000"
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-blue-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-slate-400 font-semibold mb-1">تكلفة الشراء (جنيه مصري)</label>
                  <input
                    type="number"
                    value={cost}
                    onChange={(e) => setCost(parseFloat(e.target.value) || 0)}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white font-mono focus:outline-none focus:border-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 font-semibold mb-1">تكلفة الساعة (جنيه مصري)</label>
                  <input
                    type="number"
                    value={hourlyCost}
                    onChange={(e) => setHourlyCost(parseFloat(e.target.value) || 0)}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white font-mono focus:outline-none focus:border-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 font-semibold mb-1">القدرة (كيلوواط)</label>
                  <input
                    type="number"
                    value={power}
                    onChange={(e) => setPower(parseFloat(e.target.value) || 0)}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white font-mono focus:outline-none focus:border-blue-500"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 font-semibold"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold transition shadow-lg"
                >
                  حفظ الماكينة
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
