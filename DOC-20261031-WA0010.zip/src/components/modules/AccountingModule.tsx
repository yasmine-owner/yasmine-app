/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  ArrowDownLeft,
  ArrowUpRight,
  BarChart,
  BookOpen,
  Building,
  CheckCircle2,
  DollarSign,
  FileSpreadsheet,
  Filter,
  PieChart,
  Printer,
  Receipt,
  Search,
  TrendingDown,
  TrendingUp,
} from 'lucide-react';
import { useERP } from '../../context/ERPContext';
import * as XLSX from 'xlsx';

export const AccountingModule: React.FC = () => {
  const { accounts, journalEntries } = useERP();
  const [activeTab, setActiveTab] = useState<'chart' | 'ledger' | 'trial' | 'pnl' | 'balance_sheet'>('chart');
  const [selectedAccountId, setSelectedAccountId] = useState<string>(accounts[0]?.id || '');
  const [accountSearch, setAccountSearch] = useState('');

  // Calculations for Financial Statements
  const revenues = accounts.filter((a) => a.type === 'revenue');
  const expenses = accounts.filter((a) => a.type === 'expense');
  const assets = accounts.filter((a) => a.type === 'asset');
  const liabilities = accounts.filter((a) => a.type === 'liability');
  const equity = accounts.filter((a) => a.type === 'equity');

  const totalRevenues = revenues.reduce((s, a) => s + (a.balance || 0), 0);
  const totalExpenses = expenses.reduce((s, a) => s + (a.balance || 0), 0);
  const netProfit = totalRevenues - totalExpenses;

  const totalAssets = assets.reduce((s, a) => s + (a.balance || 0), 0);
  const totalLiabilities = liabilities.reduce((s, a) => s + (a.balance || 0), 0);
  const totalEquity = equity.reduce((s, a) => s + (a.balance || 0), 0);

  // General Ledger lines for selected account
  const selectedAccount = accounts.find((a) => a.id === selectedAccountId);
  const ledgerLines: {
    date: string;
    entryNumber: string;
    description: string;
    debit: number;
    credit: number;
    runningBalance: number;
  }[] = [];

  let currentRunBal = 0;
  // sort entries chronologically
  const sortedEntries = [...journalEntries].sort((a, b) => (a.date > b.date ? 1 : -1));
  sortedEntries.forEach((entry) => {
    entry.lines.forEach((line) => {
      if (line.accountId === selectedAccountId || line.accountCode === selectedAccount?.code) {
        if (selectedAccount?.type === 'asset' || selectedAccount?.type === 'expense') {
          currentRunBal += (line.debit || 0) - (line.credit || 0);
        } else {
          currentRunBal += (line.credit || 0) - (line.debit || 0);
        }
        ledgerLines.push({
          date: entry.date,
          entryNumber: entry.entryNumber,
          description: entry.description,
          debit: line.debit,
          credit: line.credit,
          runningBalance: currentRunBal,
        });
      }
    });
  });

  // Trial Balance Totals
  const trialDebitTotal = accounts
    .filter((a) => a.type === 'asset' || a.type === 'expense')
    .reduce((s, a) => s + Math.max(0, a.balance || 0), 0);
  const trialCreditTotal = accounts
    .filter((a) => a.type === 'liability' || a.type === 'equity' || a.type === 'revenue')
    .reduce((s, a) => s + Math.max(0, a.balance || 0), 0);

  const exportTabToExcel = () => {
    const wb = XLSX.utils.book_new();
    if (activeTab === 'chart') {
      const data = accounts.map((a) => ({
        'الكود': a.code,
        'اسم الحساب': a.name,
        'النوع': a.type,
        'الرصيد': a.balance,
      }));
      const ws = XLSX.utils.json_to_sheet(data);
      XLSX.utils.book_append_sheet(wb, ws, 'دليل الحسابات');
    } else if (activeTab === 'trial') {
      const data = accounts.map((a) => ({
        'الكود': a.code,
        'اسم الحساب': a.name,
        'مدين': a.type === 'asset' || a.type === 'expense' ? a.balance : 0,
        'دائن': a.type !== 'asset' && a.type !== 'expense' ? a.balance : 0,
      }));
      const ws = XLSX.utils.json_to_sheet(data);
      XLSX.utils.book_append_sheet(wb, ws, 'ميزان المراجعة');
    }
    XLSX.writeFile(wb, `Financial_Statement_${activeTab}.xlsx`);
  };

  return (
    <div className="space-y-6">
      {/* Navigation Tabs */}
      <div className="flex flex-wrap items-center justify-between gap-3 p-2 bg-slate-900 border border-slate-800 rounded-2xl">
        <div className="flex flex-wrap items-center gap-1.5">
          <button
            onClick={() => setActiveTab('chart')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition cursor-pointer ${
              activeTab === 'chart'
                ? 'bg-blue-600 text-white shadow-md'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            دليل الحسابات الهرمي
          </button>
          <button
            onClick={() => setActiveTab('ledger')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition cursor-pointer ${
              activeTab === 'ledger'
                ? 'bg-blue-600 text-white shadow-md'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            دفتر الأستاذ العام (Ledger)
          </button>
          <button
            onClick={() => setActiveTab('trial')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition cursor-pointer ${
              activeTab === 'trial'
                ? 'bg-blue-600 text-white shadow-md'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            ميزان المراجعة
          </button>
          <button
            onClick={() => setActiveTab('pnl')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition cursor-pointer ${
              activeTab === 'pnl'
                ? 'bg-blue-600 text-white shadow-md'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            قائمة الدخل والأرباح والخسائر
          </button>
          <button
            onClick={() => setActiveTab('balance_sheet')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition cursor-pointer ${
              activeTab === 'balance_sheet'
                ? 'bg-blue-600 text-white shadow-md'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            قائمة المركز المالي (الميزانية)
          </button>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={exportTabToExcel}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium border border-slate-700 transition"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-400" />
            <span>تصدير إكسل</span>
          </button>
          <button
            onClick={() => window.print()}
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 transition no-print"
          >
            <Printer className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* 1. Chart of Accounts Tab */}
      {activeTab === 'chart' && (
        <div className="space-y-4">
          <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-between">
            <div className="relative w-80">
              <Search className="w-4 h-4 absolute right-3 top-3 text-slate-400" />
              <input
                type="text"
                value={accountSearch}
                onChange={(e) => setAccountSearch(e.target.value)}
                placeholder="بحث في دليل الحسابات..."
                className="w-full pl-3 pr-9 py-2 text-xs bg-slate-950 border border-slate-700 rounded-xl text-slate-200 focus:outline-none focus:border-blue-500"
              />
            </div>
            <p className="text-xs text-slate-400">
              تأخذ الحسابات أرصدتها وترحيلاتها مباشرة من القيود اليومية في الصفحة المركزية.
            </p>
          </div>

          <div className="rounded-2xl border border-slate-800 bg-slate-900 overflow-hidden shadow-xl">
            <table className="w-full text-right text-xs">
              <thead className="bg-slate-950 text-slate-400 border-b border-slate-800 font-semibold">
                <tr>
                  <th className="p-3.5">كود الحساب</th>
                  <th className="p-3.5">اسم الحساب في الدليل</th>
                  <th className="p-3.5">التصنيف المحاسبي</th>
                  <th className="p-3.5">الرصيد المرحل الحالي (جنيه مصري)</th>
                  <th className="p-3.5">البيان والوصف</th>
                  <th className="p-3.5 text-center">كشف الحساب</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800">
                {accounts
                  .filter(
                    (a) =>
                      a.name.toLowerCase().includes(accountSearch.toLowerCase()) ||
                      a.code.includes(accountSearch)
                  )
                  .map((acc) => (
                    <tr key={acc.id} className="hover:bg-slate-800/40 transition">
                      <td className="p-3.5 font-mono font-bold text-blue-400">{acc.code}</td>
                      <td className="p-3.5 font-semibold text-white">
                        <span className={acc.parentCode ? 'mr-4 text-slate-300' : 'text-blue-200'}>
                          {acc.parentCode ? '↳ ' : '• '}
                          {acc.name}
                        </span>
                      </td>
                      <td className="p-3.5">
                        <span
                          className={`px-2 py-0.5 rounded-full text-[10px] font-medium border ${
                            acc.type === 'asset'
                              ? 'bg-blue-950/60 text-blue-400 border-blue-800/50'
                              : acc.type === 'liability'
                              ? 'bg-amber-950/60 text-amber-400 border-amber-800/50'
                              : acc.type === 'equity'
                              ? 'bg-purple-950/60 text-purple-400 border-purple-800/50'
                              : acc.type === 'revenue'
                              ? 'bg-emerald-950/60 text-emerald-400 border-emerald-800/50'
                              : 'bg-rose-950/60 text-rose-400 border-rose-800/50'
                          }`}
                        >
                          {acc.type === 'asset'
                            ? 'أصل'
                            : acc.type === 'liability'
                            ? 'التزام'
                            : acc.type === 'equity'
                            ? 'حقوق ملكية'
                            : acc.type === 'revenue'
                            ? 'إيراد'
                            : 'تكلفة ومصروف'}
                        </span>
                      </td>
                      <td className="p-3.5 font-mono font-bold text-slate-100">
                        {acc.balance.toLocaleString()} جنيه مصري
                      </td>
                      <td className="p-3.5 text-slate-400 text-[11px]">{acc.description || '-'}</td>
                      <td className="p-3.5 text-center">
                        <button
                          onClick={() => {
                            setSelectedAccountId(acc.id);
                            setActiveTab('ledger');
                          }}
                          className="px-2.5 py-1 rounded-lg bg-blue-950 text-blue-400 border border-blue-800 hover:bg-blue-900 text-[11px] font-semibold cursor-pointer"
                        >
                          عرض الأستاذ
                        </button>
                      </td>
                    </tr>
                  ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 2. General Ledger Tab */}
      {activeTab === 'ledger' && (
        <div className="space-y-4">
          <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-3 w-full sm:w-auto">
              <label className="text-xs font-bold text-slate-400 whitespace-nowrap">
                اختر الحساب لعرض كشف الحركة:
              </label>
              <select
                value={selectedAccountId}
                onChange={(e) => setSelectedAccountId(e.target.value)}
                className="px-3 py-2 text-xs bg-slate-950 border border-slate-700 rounded-xl text-white font-semibold focus:outline-none focus:border-blue-500"
              >
                {accounts.map((a) => (
                  <option key={a.id} value={a.id}>
                    [{a.code}] {a.name} ({a.balance.toLocaleString()} جنيه مصري)
                  </option>
                ))}
              </select>
            </div>

            {selectedAccount && (
              <div className="flex items-center gap-4 text-xs">
                <span className="text-slate-400">
                  الرصيد الختامي المرحل:{' '}
                  <strong className="text-emerald-400 font-mono text-sm">
                    {selectedAccount.balance.toLocaleString()} جنيه مصري
                  </strong>
                </span>
              </div>
            )}
          </div>

          <div className="rounded-2xl border border-slate-800 bg-slate-900 overflow-hidden shadow-xl">
            <table className="w-full text-right text-xs">
              <thead className="bg-slate-950 text-slate-400 border-b border-slate-800 font-semibold">
                <tr>
                  <th className="p-3.5">التاريخ</th>
                  <th className="p-3.5">رقم القيد المركزي</th>
                  <th className="p-3.5">بيان وشرح المعاملة</th>
                  <th className="p-3.5">مدين (منه) - جنيه مصري</th>
                  <th className="p-3.5">دائن (له) - جنيه مصري</th>
                  <th className="p-3.5">الرصيد التراكمي (جنيه مصري)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800">
                {ledgerLines.length > 0 ? (
                  ledgerLines.map((row, idx) => (
                    <tr key={idx} className="hover:bg-slate-800/40">
                      <td className="p-3.5 text-slate-300">{row.date}</td>
                      <td className="p-3.5 font-mono font-bold text-blue-400">
                        {row.entryNumber}
                      </td>
                      <td className="p-3.5 font-medium text-white">{row.description}</td>
                      <td className="p-3.5 font-mono text-emerald-400 font-bold">
                        {row.debit > 0 ? `${row.debit.toLocaleString()} جنيه مصري` : '-'}
                      </td>
                      <td className="p-3.5 font-mono text-cyan-400 font-bold">
                        {row.credit > 0 ? `${row.credit.toLocaleString()} جنيه مصري` : '-'}
                      </td>
                      <td className="p-3.5 font-mono text-white font-bold">
                        {row.runningBalance.toLocaleString()} جنيه مصري
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={6} className="p-8 text-center text-slate-500">
                      لا توجد حركات مسجلة لهذا الحساب حتى الآن. سيتم الترحيل التلقائي عند إدراج
                      أي قيد يومية في الصفحة الموحدة.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 3. Trial Balance Tab */}
      {activeTab === 'trial' && (
        <div className="space-y-4">
          <div className="p-4 rounded-2xl bg-blue-950/40 border border-blue-800/40 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <CheckCircle2 className="w-5 h-5 text-emerald-400" />
              <div>
                <h4 className="font-bold text-sm text-white">ميزان المراجعة بالأرصدة</h4>
                <p className="text-xs text-slate-300">
                  مولد لحظياً من إجمالي قيود اليومية المركزية.
                </p>
              </div>
            </div>
            <div className="flex items-center gap-4 text-xs">
              <span className="text-slate-300">
                إجمالي المدين: <strong className="text-emerald-400 font-mono">{trialDebitTotal.toLocaleString()} جنيه مصري</strong>
              </span>
              <span className="text-slate-300">
                إجمالي الدائن: <strong className="text-cyan-400 font-mono">{trialCreditTotal.toLocaleString()} جنيه مصري</strong>
              </span>
            </div>
          </div>

          <div className="rounded-2xl border border-slate-800 bg-slate-900 overflow-hidden shadow-xl">
            <table className="w-full text-right text-xs">
              <thead className="bg-slate-950 text-slate-400 border-b border-slate-800 font-semibold">
                <tr>
                  <th className="p-3.5">الكود</th>
                  <th className="p-3.5">اسم الحساب</th>
                  <th className="p-3.5">طبيعة الحساب</th>
                  <th className="p-3.5">أرصدة مدينة (منه) - جنيه</th>
                  <th className="p-3.5">أرصدة دائنة (له) - جنيه</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800">
                {accounts.map((a) => {
                  const isDebit = a.type === 'asset' || a.type === 'expense';
                  return (
                    <tr key={a.id} className="hover:bg-slate-800/40">
                      <td className="p-3.5 font-mono font-bold text-blue-400">{a.code}</td>
                      <td className="p-3.5 font-medium text-white">{a.name}</td>
                      <td className="p-3.5 text-slate-400">
                        {isDebit ? 'مدين بطبيعته' : 'دائن بطبيعته'}
                      </td>
                      <td className="p-3.5 font-mono text-emerald-400 font-bold">
                        {isDebit && a.balance > 0 ? `${a.balance.toLocaleString()} جنيه مصري` : '-'}
                      </td>
                      <td className="p-3.5 font-mono text-cyan-400 font-bold">
                        {!isDebit && a.balance > 0 ? `${a.balance.toLocaleString()} جنيه مصري` : '-'}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 4. Income Statement (P&L) Tab */}
      {activeTab === 'pnl' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="p-5 rounded-2xl bg-emerald-950/40 border border-emerald-800/50">
              <span className="text-xs text-emerald-400 font-semibold">إجمالي الإيرادات والمبيعات</span>
              <h3 className="text-2xl font-bold text-white mt-1">
                {totalRevenues.toLocaleString()} جنيه مصري
              </h3>
            </div>
            <div className="p-5 rounded-2xl bg-rose-950/40 border border-rose-800/50">
              <span className="text-xs text-rose-400 font-semibold">إجمالي التكاليف والمصروفات</span>
              <h3 className="text-2xl font-bold text-white mt-1">
                {totalExpenses.toLocaleString()} جنيه مصري
              </h3>
            </div>
            <div className="p-5 rounded-2xl bg-blue-950/40 border border-blue-800/50">
              <span className="text-xs text-blue-400 font-semibold">صافي الربح المحقق</span>
              <h3 className="text-2xl font-bold text-emerald-400 mt-1">
                {netProfit.toLocaleString()} جنيه مصري
              </h3>
            </div>
          </div>

          <div className="rounded-2xl border border-slate-800 bg-slate-900 p-6 space-y-6">
            <h4 className="text-sm font-bold text-white border-b border-slate-800 pb-3">
              تفاصيل قائمة الدخل الصناعي (Income Statement)
            </h4>

            {/* Revenues */}
            <div>
              <h5 className="text-xs font-bold text-emerald-400 uppercase tracking-wider mb-2">
                1. الإيرادات التشغيلية والمبيعات
              </h5>
              <div className="space-y-2">
                {revenues.map((r) => (
                  <div key={r.id} className="flex justify-between items-center text-xs p-2 rounded-lg bg-slate-950/60 border border-slate-800">
                    <span className="text-slate-200">[{r.code}] {r.name}</span>
                    <span className="font-mono font-bold text-emerald-400">{r.balance.toLocaleString()} جنيه مصري</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Expenses */}
            <div>
              <h5 className="text-xs font-bold text-rose-400 uppercase tracking-wider mb-2">
                2. تكاليف الإنتاج والمصروفات الصناعية
              </h5>
              <div className="space-y-2">
                {expenses.map((e) => (
                  <div key={e.id} className="flex justify-between items-center text-xs p-2 rounded-lg bg-slate-950/60 border border-slate-800">
                    <span className="text-slate-200">[{e.code}] {e.name}</span>
                    <span className="font-mono font-bold text-rose-400">{e.balance.toLocaleString()} جنيه مصري</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 5. Balance Sheet Tab */}
      {activeTab === 'balance_sheet' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Assets */}
            <div className="rounded-2xl border border-slate-800 bg-slate-900 p-6 space-y-4">
              <div className="flex justify-between items-center border-b border-slate-800 pb-3">
                <h4 className="text-sm font-bold text-blue-400">الأصول (Assets)</h4>
                <span className="font-mono text-base font-bold text-white">{totalAssets.toLocaleString()} جنيه مصري</span>
              </div>
              <div className="space-y-2 text-xs">
                {assets.map((a) => (
                  <div key={a.id} className="flex justify-between items-center p-2 rounded-lg bg-slate-950/60 border border-slate-800">
                    <span className="text-slate-200">[{a.code}] {a.name}</span>
                    <span className="font-mono font-bold text-blue-300">{a.balance.toLocaleString()} جنيه مصري</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Liabilities & Equity */}
            <div className="rounded-2xl border border-slate-800 bg-slate-900 p-6 space-y-4">
              <div className="flex justify-between items-center border-b border-slate-800 pb-3">
                <h4 className="text-sm font-bold text-purple-400">الالتزامات وحقوق الملكية</h4>
                <span className="font-mono text-base font-bold text-white">
                  {(totalLiabilities + totalEquity).toLocaleString()} جنيه مصري
                </span>
              </div>

              <div>
                <h5 className="text-[11px] font-bold text-amber-400 mb-2">الالتزامات (Liabilities)</h5>
                <div className="space-y-1.5 text-xs">
                  {liabilities.map((l) => (
                    <div key={l.id} className="flex justify-between items-center p-2 rounded-lg bg-slate-950/60 border border-slate-800">
                      <span className="text-slate-200">[{l.code}] {l.name}</span>
                      <span className="font-mono font-bold text-amber-400">{l.balance.toLocaleString()} جنيه مصري</span>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <h5 className="text-[11px] font-bold text-purple-400 mb-2">حقوق الملكية ورؤوس الأموال</h5>
                <div className="space-y-1.5 text-xs">
                  {equity.map((eq) => (
                    <div key={eq.id} className="flex justify-between items-center p-2 rounded-lg bg-slate-950/60 border border-slate-800">
                      <span className="text-slate-200">[{eq.code}] {eq.name}</span>
                      <span className="font-mono font-bold text-purple-400">{eq.balance.toLocaleString()} جنيه مصري</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
