/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  AlertOctagon,
  AlertTriangle,
  Check,
  CheckCircle2,
  Database,
  Eye,
  History,
  Key,
  Lock,
  Plus,
  RefreshCw,
  Shield,
  ShieldAlert,
  ShieldCheck,
  Trash2,
  UserCheck,
  UserPlus,
  Users,
  X,
} from 'lucide-react';
import { useERP } from '../../context/ERPContext';
import { User, UserRole } from '../../types/erp';

export const OwnerSecretModule: React.FC = () => {
  const {
    currentUser,
    users,
    auditLogs,
    isOwnerSecretUnlocked,
    lockOwnerSecret,
    updateOwnerSecretPin,
    updateUserPermissions,
    addNewUser,
    toggleUserStatus,
    resetDatabaseToDefaults,
  } = useERP();

  const [activeTab, setActiveTab] = useState<'users' | 'audit' | 'security' | 'danger'>('users');
  const [showNewUserModal, setShowNewUserModal] = useState(false);
  const [confirmReset, setConfirmReset] = useState(false);

  // Owner PIN Change State
  const [currentPinInput, setCurrentPinInput] = useState('');
  const [newPinInput, setNewPinInput] = useState('');
  const [confirmNewPinInput, setConfirmNewPinInput] = useState('');
  const [pinStatusMsg, setPinStatusMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const handlePinChangeSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setPinStatusMsg(null);

    if (newPinInput !== confirmNewPinInput) {
      setPinStatusMsg({ type: 'error', text: 'الرمز السري الجديد وتأكيده غير متطابقين!' });
      return;
    }

    const res = updateOwnerSecretPin(currentPinInput, newPinInput);
    if (res.success) {
      setPinStatusMsg({ type: 'success', text: res.message });
      setCurrentPinInput('');
      setNewPinInput('');
      setConfirmNewPinInput('');
    } else {
      setPinStatusMsg({ type: 'error', text: res.message });
    }
  };

  // New User Form (Default is Read-Only as requested by specification #3)
  const [newUsername, setNewUsername] = useState('');
  const [newName, setNewName] = useState('');
  const [newRole, setNewRole] = useState<UserRole>('viewer');
  const [newEmail, setNewEmail] = useState('');

  // If user is not owner, show completely blocked screen
  if (currentUser.role !== 'owner' || !isOwnerSecretUnlocked) {
    return (
      <div className="min-h-[60vh] flex flex-col items-center justify-center text-center p-6 bg-slate-950 rounded-3xl border border-rose-900/60 shadow-2xl">
        <div className="p-4 bg-rose-950/60 rounded-full border border-rose-800 text-rose-400 mb-4 animate-pulse">
          <ShieldAlert className="w-12 h-12" />
        </div>
        <h3 className="text-xl font-bold text-white mb-2">منطقة سرية ومحمية بالكامل</h3>
        <p className="text-xs text-slate-400 max-w-md leading-relaxed mb-6">
          هذه لوحة التحكم السرية والمستقلة الخاصة بالمالك الرئيسي (Owner) وحده. لا يمتلك أي مستخدم
          أو مدير آخر صلاحية الدخول إليها أو رؤية محتواها أو تغيير بياناتها.
        </p>
        <div className="text-[11px] text-amber-400 bg-amber-950/40 px-4 py-2 rounded-xl border border-amber-850">
          تم قيد محاولة الوصول غير المصرح بها في سجل التدقيق الأمني المشفر للمالك.
        </div>
      </div>
    );
  }

  const handleCreateUser = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newUsername || !newName) return;

    // By default: Read-Only per Specification #3
    addNewUser({
      username: newUsername.trim(),
      name: newName.trim(),
      role: newRole,
      email: newEmail || `${newUsername}@factory.internal`,
      isActive: true,
      permissions: {
        canView: true,
        canAdd: newRole === 'manager' || newRole === 'accountant',
        canEdit: false,
        canDelete: false,
        canApprove: newRole === 'manager',
        canPost: newRole === 'accountant',
        canExport: true,
        canImport: false,
        canAccessOwnerPanel: false, // Absolutely never granted to other users!
        allowedModules:
          newRole === 'accountant'
            ? ['dashboard', 'journal', 'accounting', 'reports']
            : newRole === 'warehouse'
            ? ['dashboard', 'inventory', 'tools']
            : ['dashboard'],
      },
    });

    setShowNewUserModal(false);
    setNewUsername('');
    setNewName('');
    setNewEmail('');
    setNewRole('viewer');
  };

  return (
    <div className="space-y-6">
      {/* Secret Control Room Header */}
      <div className="p-6 rounded-3xl bg-gradient-to-l from-amber-950/70 via-slate-900 to-slate-900 border-2 border-amber-500/60 shadow-2xl">
        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-amber-500/20 rounded-2xl border border-amber-500/40 text-amber-400">
              <Shield className="w-8 h-8" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl font-bold text-amber-300">
                  لوحة تحكم المالك السرية والمستقلة (Owner Master Sanctuary)
                </h2>
                <span className="px-2.5 py-0.5 rounded-full text-[10px] bg-amber-500/30 text-amber-300 border border-amber-500/50 font-bold uppercase">
                  تحت سيطرتك وحدك
                </span>
              </div>
              <p className="text-xs text-slate-300 mt-1 max-w-2xl leading-relaxed">
                هذه الغرفة السرية لا تظهر مطلقاً لأي مستخدم آخر. لا يمكن لأي مدير أو موظف تعديل
                حسابك أو تغيير صلاحياتك أو الاستيلاء على التحكم. أنت المتحكم الحصري في إعدادات
                المصنع، المستخدمين، الصلاحيات، وسجل التدقيق.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={lockOwnerSecret}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-amber-300 border border-amber-500/40 text-xs font-bold transition cursor-pointer shadow-md"
            >
              <Lock className="w-4 h-4" />
              <span>قفل اللوحة والخروج الآمن</span>
            </button>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex gap-2 mt-6 pt-5 border-t border-slate-800">
          <button
            onClick={() => setActiveTab('users')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition cursor-pointer ${
              activeTab === 'users'
                ? 'bg-amber-500 text-slate-950'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            إدارة المستخدمين ومصفوفة الصلاحيات
          </button>
          <button
            onClick={() => setActiveTab('audit')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition cursor-pointer ${
              activeTab === 'audit'
                ? 'bg-amber-500 text-slate-950'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            سجل التدقيق الأمني (Audit Trail)
          </button>
          <button
            onClick={() => setActiveTab('security')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'security'
                ? 'bg-amber-500 text-slate-950'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Key className="w-3.5 h-3.5" />
            <span>تغيير الرمز السري للمالك (PIN)</span>
          </button>
          <button
            onClick={() => setActiveTab('danger')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition cursor-pointer ${
              activeTab === 'danger'
                ? 'bg-rose-600 text-white'
                : 'text-slate-400 hover:text-rose-400 hover:bg-slate-800'
            }`}
          >
            إعادة الضبط والمفاتيح الحرجة
          </button>
        </div>
      </div>

      {/* 1. Users & Permissions Matrix Tab */}
      {activeTab === 'users' && (
        <div className="space-y-4">
          <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div>
              <h3 className="font-bold text-sm text-white flex items-center gap-2">
                <Users className="w-4 h-4 text-blue-400" />
                <span>مصفوفة الصلاحيات والتفويض للموظفين والمديرين</span>
              </h3>
              <p className="text-xs text-slate-400 mt-1">
                الوضع الافتراضي لأي مستخدم جديد هو (مشاهدة فقط) بدون أي إضافة أو تعديل أو حذف.
              </p>
            </div>
            <button
              onClick={() => setShowNewUserModal(true)}
              className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold transition shadow-lg cursor-pointer"
            >
              <UserPlus className="w-4 h-4" />
              <span>إنشاء حساب مستخدم جديد</span>
            </button>
          </div>

          <div className="rounded-2xl border border-slate-800 bg-slate-900 overflow-hidden shadow-xl">
            <table className="w-full text-right text-xs">
              <thead className="bg-slate-950 text-slate-400 font-semibold border-b border-slate-800">
                <tr>
                  <th className="p-3.5">المستخدم</th>
                  <th className="p-3.5">الرتبة</th>
                  <th className="p-3.5 text-center">مشاهدة</th>
                  <th className="p-3.5 text-center">إضافة</th>
                  <th className="p-3.5 text-center">تعديل</th>
                  <th className="p-3.5 text-center">حذف</th>
                  <th className="p-3.5 text-center">اعتماد</th>
                  <th className="p-3.5 text-center">ترحيل</th>
                  <th className="p-3.5 text-center">تصدير إكسل</th>
                  <th className="p-3.5 text-center">حالة الحساب</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800">
                {users.map((u) => {
                  const isUserOwner = u.role === 'owner';

                  return (
                    <tr key={u.id} className="hover:bg-slate-800/40">
                      <td className="p-3.5">
                        <div className="font-bold text-white flex items-center gap-2">
                          <span>{u.name}</span>
                          {isUserOwner && (
                            <span className="text-[10px] px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/40">
                              المالك
                            </span>
                          )}
                        </div>
                        <span className="text-[10px] text-slate-400 font-mono">@{u.username}</span>
                      </td>
                      <td className="p-3.5">
                        <span className="px-2 py-0.5 rounded-full text-[10px] bg-slate-800 text-slate-300 border border-slate-700">
                          {u.role}
                        </span>
                      </td>

                      {/* Permissions Checkboxes */}
                      <td className="p-3.5 text-center">
                        <input
                          type="checkbox"
                          checked={u.permissions.canView}
                          disabled={isUserOwner}
                          onChange={(e) =>
                            updateUserPermissions(u.id, { canView: e.target.checked })
                          }
                          className="rounded text-blue-600 cursor-pointer"
                        />
                      </td>
                      <td className="p-3.5 text-center">
                        <input
                          type="checkbox"
                          checked={u.permissions.canAdd}
                          disabled={isUserOwner}
                          onChange={(e) =>
                            updateUserPermissions(u.id, { canAdd: e.target.checked })
                          }
                          className="rounded text-blue-600 cursor-pointer"
                        />
                      </td>
                      <td className="p-3.5 text-center">
                        <input
                          type="checkbox"
                          checked={u.permissions.canEdit}
                          disabled={isUserOwner}
                          onChange={(e) =>
                            updateUserPermissions(u.id, { canEdit: e.target.checked })
                          }
                          className="rounded text-blue-600 cursor-pointer"
                        />
                      </td>
                      <td className="p-3.5 text-center">
                        <input
                          type="checkbox"
                          checked={u.permissions.canDelete}
                          disabled={isUserOwner}
                          onChange={(e) =>
                            updateUserPermissions(u.id, { canDelete: e.target.checked })
                          }
                          className="rounded text-blue-600 cursor-pointer"
                        />
                      </td>
                      <td className="p-3.5 text-center">
                        <input
                          type="checkbox"
                          checked={u.permissions.canApprove}
                          disabled={isUserOwner}
                          onChange={(e) =>
                            updateUserPermissions(u.id, { canApprove: e.target.checked })
                          }
                          className="rounded text-blue-600 cursor-pointer"
                        />
                      </td>
                      <td className="p-3.5 text-center">
                        <input
                          type="checkbox"
                          checked={u.permissions.canPost}
                          disabled={isUserOwner}
                          onChange={(e) =>
                            updateUserPermissions(u.id, { canPost: e.target.checked })
                          }
                          className="rounded text-blue-600 cursor-pointer"
                        />
                      </td>
                      <td className="p-3.5 text-center">
                        <input
                          type="checkbox"
                          checked={u.permissions.canExport}
                          disabled={isUserOwner}
                          onChange={(e) =>
                            updateUserPermissions(u.id, { canExport: e.target.checked })
                          }
                          className="rounded text-blue-600 cursor-pointer"
                        />
                      </td>
                      <td className="p-3.5 text-center">
                        {!isUserOwner ? (
                          <button
                            onClick={() => toggleUserStatus(u.id)}
                            className={`px-2 py-0.5 rounded-full text-[10px] font-bold border cursor-pointer ${
                              u.isActive
                                ? 'bg-emerald-950 text-emerald-400 border-emerald-800'
                                : 'bg-rose-950 text-rose-400 border-rose-800'
                            }`}
                          >
                            {u.isActive ? 'مفعل' : 'موقوف'}
                          </button>
                        ) : (
                          <span className="text-[10px] text-amber-400 font-bold">دائم وحصري</span>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 2. Audit Trail Tab */}
      {activeTab === 'audit' && (
        <div className="space-y-4">
          <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 flex justify-between items-center">
            <div className="flex items-center gap-2">
              <History className="w-5 h-5 text-amber-400" />
              <h3 className="font-bold text-sm text-white">
                سجل التدقيق والمراقبة الأمنية (Audit Trail)
              </h3>
            </div>
            <span className="text-xs text-slate-400">
              سجل محمي ضد الحذف - يوثق كل إضافة وتعديل وترحيل بدقة
            </span>
          </div>

          <div className="rounded-2xl border border-slate-800 bg-slate-900 overflow-hidden shadow-xl">
            <table className="w-full text-right text-xs">
              <thead className="bg-slate-950 text-slate-400 font-semibold border-b border-slate-800">
                <tr>
                  <th className="p-3.5">الوقت والتاريخ</th>
                  <th className="p-3.5">المستخدم</th>
                  <th className="p-3.5">القسم / الوحدة</th>
                  <th className="p-3.5">نوع الإجراء</th>
                  <th className="p-3.5">تفاصيل العملية</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800">
                {auditLogs.map((log) => (
                  <tr key={log.id} className="hover:bg-slate-800/40">
                    <td className="p-3.5 font-mono text-slate-300">{log.timestamp}</td>
                    <td className="p-3.5 font-semibold text-white">{log.userName}</td>
                    <td className="p-3.5 text-blue-400">{log.module}</td>
                    <td className="p-3.5">
                      <span className="px-2 py-0.5 rounded text-[10px] bg-slate-800 text-slate-300 border border-slate-700">
                        {log.action}
                      </span>
                    </td>
                    <td className="p-3.5 text-slate-300 max-w-md">{log.details}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 3. Owner PIN Change Security Tab */}
      {activeTab === 'security' && (
        <div className="p-6 rounded-3xl bg-slate-900 border border-amber-500/40 space-y-6 shadow-2xl">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-amber-500/20 text-amber-400 rounded-2xl border border-amber-500/40">
              <Key className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-bold text-base text-amber-300">
                إدارة وتغيير الرمز السري الحصري للمالك (Owner Secret PIN)
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                يمكنك من هنا تغيير وتحديث كلمة مرور/رمز فتح لوحة التحكم السرية للمالك لمنع أي شخص آخر من تخمينها أو معرفتها.
              </p>
            </div>
          </div>

          {pinStatusMsg && (
            <div
              className={`p-4 rounded-xl border text-xs font-bold flex items-center gap-2 ${
                pinStatusMsg.type === 'success'
                  ? 'bg-emerald-950/60 border-emerald-800 text-emerald-300'
                  : 'bg-rose-950/60 border-rose-800 text-rose-300'
              }`}
            >
              <ShieldCheck className="w-5 h-5 shrink-0" />
              <span>{pinStatusMsg.text}</span>
            </div>
          )}

          <form onSubmit={handlePinChangeSubmit} className="max-w-md space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                الرمز السري الحالي للمالك:
              </label>
              <input
                type="password"
                value={currentPinInput}
                onChange={(e) => setCurrentPinInput(e.target.value)}
                placeholder="أدخل الرمز السري الحالي"
                className="w-full px-4 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-amber-400 font-mono text-sm focus:outline-none focus:border-amber-400"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                الرمز السري الجديد المطلوب:
              </label>
              <input
                type="password"
                value={newPinInput}
                onChange={(e) => setNewPinInput(e.target.value)}
                placeholder="أدخل الرمز السري الجديد (4 أرقام/أحرف على الأقل)"
                className="w-full px-4 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-amber-400 font-mono text-sm focus:outline-none focus:border-amber-400"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                تأكيد الرمز السري الجديد:
              </label>
              <input
                type="password"
                value={confirmNewPinInput}
                onChange={(e) => setConfirmNewPinInput(e.target.value)}
                placeholder="أعد إدخال الرمز السري الجديد للتأكيد"
                className="w-full px-4 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-amber-400 font-mono text-sm focus:outline-none focus:border-amber-400"
                required
              />
            </div>

            <button
              type="submit"
              className="w-full py-3 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-xs transition shadow-lg cursor-pointer"
            >
              حفظ وتطبيق الرمز السري الجديد
            </button>
          </form>

          <div className="p-4 rounded-2xl bg-amber-950/20 border border-amber-900/40 text-[11px] text-amber-300/80 leading-relaxed">
            ملاحظة أمنية: يتم حفظ وتشفير الرمز السري الجديد محلياً في ذاكرة متصفحك وسجل الحماية الخاص بك فقط. لا يظهر هذا الرمز في الشاشات أو للمستخدمين الآخرين إطلاقاً.
          </div>
        </div>
      )}

      {/* 4. Danger Zone Tab */}
      {activeTab === 'danger' && (
        <div className="p-6 rounded-2xl border border-rose-800/60 bg-rose-950/20 space-y-4">
          <div className="flex items-center gap-3 text-rose-400">
            <AlertOctagon className="w-6 h-6" />
            <h4 className="font-bold text-base">إعادة ضبط المصنع وقاعدة البيانات</h4>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed max-w-xl">
            هذا الإجراء يقوم بإعادة تهيئة كافة الجداول والحسابات والقيود والماكينات إلى الحالة
            الافتراضية المعتمدة (بما فيها مساهمة الـ 2.4 مليون للماكينات). لا تستخدم هذا الإجراء
            إلا بعد أخذ نسخة احتياطية كاملة.
          </p>

          {!confirmReset ? (
            <button
              onClick={() => setConfirmReset(true)}
              className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs shadow-lg cursor-pointer"
            >
              طلب إعادة ضبط النظام الافتراضي
            </button>
          ) : (
            <div className="flex items-center gap-3 p-4 rounded-xl bg-rose-950 border border-rose-800">
              <span className="text-xs font-bold text-rose-200">
                هل أنت متأكد تماماً من رغبتك في إعادة ضبط قاعدة البيانات؟
              </span>
              <button
                onClick={() => {
                  resetDatabaseToDefaults();
                  setConfirmReset(false);
                }}
                className="px-4 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs"
              >
                نعم، أعد الضبط
              </button>
              <button
                onClick={() => setConfirmReset(false)}
                className="px-3 py-1.5 rounded-lg bg-slate-800 text-slate-300 text-xs"
              >
                تراجع
              </button>
            </div>
          )}
        </div>
      )}

      {/* Add User Modal */}
      {showNewUserModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-3xl max-w-md w-full p-6 text-white shadow-2xl">
            <h3 className="text-base font-bold text-white mb-2">إنشاء حساب مستخدم جديد</h3>
            <p className="text-xs text-slate-400 mb-4">
              الوضع الافتراضي عند إنشاء الحساب هو وضع (مشاهدة فقط)، ويمكنك بعد ذلك توسيع صلاحياته
              وفق ما تراه مناسباً.
            </p>

            <form onSubmit={handleCreateUser} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-400 font-semibold mb-1">اسم الموظف الثلاثي</label>
                <input
                  type="text"
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  placeholder="مثال: خالد عبد الرحمن"
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-amber-400"
                  required
                />
              </div>

              <div>
                <label className="block text-slate-400 font-semibold mb-1">اسم المستخدم للدخول</label>
                <input
                  type="text"
                  value={newUsername}
                  onChange={(e) => setNewUsername(e.target.value)}
                  placeholder="khaled_acc"
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white font-mono focus:outline-none focus:border-amber-400"
                  required
                />
              </div>

              <div>
                <label className="block text-slate-400 font-semibold mb-1">الرتبة الوظيفية</label>
                <select
                  value={newRole}
                  onChange={(e) => setNewRole(e.target.value as any)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-amber-400"
                >
                  <option value="viewer">مشاهد فقط (Default View-Only)</option>
                  <option value="accountant">محاسب</option>
                  <option value="warehouse">أمين مخزن</option>
                  <option value="production">مشرف إنتاج وتشغيل</option>
                  <option value="manager">مدير عام</option>
                </select>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowNewUserModal(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 font-semibold"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold transition shadow-lg cursor-pointer"
                >
                  إنشاء الحساب
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
