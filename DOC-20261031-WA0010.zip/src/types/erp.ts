/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type UserRole = 'owner' | 'manager' | 'accountant' | 'warehouse' | 'production' | 'viewer';

export interface UserPermissions {
  canView: boolean;
  canAdd: boolean;
  canEdit: boolean;
  canDelete: boolean;
  canApprove: boolean;
  canPost: boolean;
  canExport: boolean;
  canImport: boolean;
  canAccessOwnerPanel: boolean;
  allowedModules: string[];
}

export interface User {
  id: string;
  username: string;
  name: string;
  role: UserRole;
  email: string;
  phone?: string;
  isActive: boolean;
  lastLogin?: string;
  permissions: UserPermissions;
}

export interface Account {
  id: string;
  code: string;
  name: string;
  type: 'asset' | 'liability' | 'equity' | 'revenue' | 'expense';
  parentCode?: string;
  balance: number;
  description?: string;
}

export interface JournalLine {
  accountId: string;
  accountCode: string;
  accountName: string;
  debit: number;
  credit: number;
  note?: string;
}

export interface JournalEntry {
  id: string;
  entryNumber: string;
  date: string;
  description: string;
  referenceType?: 'manual' | 'sales' | 'purchase' | 'production' | 'depreciation' | 'capital' | 'payroll' | 'inventory';
  referenceId?: string;
  isPosted: boolean;
  isReversed?: boolean;
  createdBy: string;
  createdAt: string;
  lines: JournalLine[];
  totalAmount: number;
}

export interface Partner {
  id: string;
  name: string;
  initialContribution: number;
  currentBalance: number;
  notes: string;
  hasSubAccountInOtherPartner?: string; // e.g. Partner 4 & 5 stored in Partner 3's account
  ownershipSharePercentage?: number;
}

export interface BankTreasury {
  id: string;
  name: string;
  type: 'treasury' | 'bank';
  accountNumber?: string;
  currency: string;
  currentBalance: number;
  branch?: string;
}

export interface Machine {
  id: string;
  code: string;
  name: string;
  type: string;
  brand: string;
  model: string;
  purchaseDate: string;
  purchaseCost: number;
  currentBookValue: number;
  usefulLifeYears: number;
  depreciationRateYearly: number;
  status: 'running' | 'idle' | 'maintenance' | 'breakdown';
  location: string;
  totalRunHours: number;
  totalBreakdownHours: number;
  hourlyOperatingCost: number;
  powerConsumptionKw: number;
  lastMaintenanceDate?: string;
  notes?: string;
}

export interface CuttingTool {
  id: string;
  code: string;
  name: string; // e.g. End Mill 6mm Carbide 4-Flute
  size: string;
  type: string;
  supplier: string;
  unitPrice: number;
  expectedLifespanHours: number;
  actualRunHours: number;
  usageCount: number;
  currentMachineId?: string;
  currentOrderId?: string;
  status: 'active' | 'worn_out' | 'broken';
  breakageReason?: 'normal_wear' | 'exceptional_breakage';
  replacementDate?: string;
  notes?: string;
}

export interface InventoryItem {
  id: string;
  code: string;
  barcode?: string;
  name: string;
  category: 'raw_materials' | 'cutting_tools' | 'wip' | 'finished_goods' | 'scrap';
  unit: string;
  warehouseId: string;
  currentStock: number;
  minAlertStock: number;
  movingAverageCost: number;
  lastPurchasePrice: number;
  sellingPrice?: number;
}

export interface Warehouse {
  id: string;
  code: string;
  name: string;
  type: 'raw' | 'tools' | 'wip' | 'finished' | 'scrap';
  location: string;
  managerName: string;
}

export interface BOMItem {
  itemId: string;
  itemName: string;
  quantity: number;
  unit: string;
  unitCost: number;
  expectedScrapRate: number; // e.g. 0.03 for 3%
}

export interface BOMOperation {
  machineId: string;
  machineName: string;
  operationName: string;
  cycleTimeMinutes: number;
  hourlyRate: number;
}

export interface ProductBOM {
  id: string;
  productId: string;
  productCode: string;
  productName: string;
  version: string;
  rawMaterials: BOMItem[];
  operations: BOMOperation[];
  estimatedMaterialCost: number;
  estimatedLaborCost: number;
  estimatedMachineCost: number;
  totalEstimatedCost: number;
  suggestedSellingPrice: number;
  notes?: string;
}

export interface ProductionOrder {
  id: string;
  orderNumber: string;
  bomId: string;
  productName: string;
  requiredQuantity: number;
  producedQuantity: number;
  acceptedQuantity: number;
  rejectedQuantity: number;
  reworkedQuantity: number;
  scrapQuantity: number;
  startDate: string;
  expectedEndDate: string;
  status: 'planned' | 'in_progress' | 'completed' | 'cancelled';
  assignedMachineId: string;
  assignedOperator: string;
  actualMaterialCost: number;
  actualDirectLaborCost: number;
  actualMachineOperatingCost: number;
  actualToolingCost: number;
  totalActualCost: number;
  costPerAcceptedUnit: number;
  notes?: string;
}

export interface ScrapDowntimeLog {
  id: string;
  date: string;
  time: string;
  type: 'scrap' | 'downtime' | 'tool_breakage';
  machineId?: string;
  productionOrderId?: string;
  quantityOrHours: number;
  unit: 'pieces' | 'kg' | 'hours';
  isNormal: boolean; // Normal vs Exceptional
  reason: string;
  responsiblePerson: string;
  financialImpact: number;
  correctiveAction: string;
  isApproved: boolean;
}

export interface FixedAsset {
  id: string;
  assetCode: string;
  name: string;
  category: string;
  purchaseDate: string;
  purchaseCost: number;
  salvageValue: number;
  usefulLifeYears: number;
  depreciationMethod: 'straight_line' | 'declining_balance';
  accumulatedDepreciation: number;
  currentBookValue: number;
  status: 'active' | 'retired' | 'sold';
}

export interface AuditLog {
  id: string;
  timestamp: string;
  userId: string;
  userName: string;
  action: 'create' | 'update' | 'delete' | 'post' | 'reverse' | 'login' | 'permission_change' | 'backup';
  module: string;
  details: string;
  previousValue?: string;
  newValue?: string;
}

export interface ThemeConfig {
  preset: 'blue' | 'navy' | 'dark' | 'emerald' | 'gray' | 'purple' | 'light';
  primaryColor: string;
  accentColor: string;
  companyName: string;
  companySubtitle: string;
  logoUrl?: string;
  fontSize: 'small' | 'medium' | 'large';
  borderRadius: 'sm' | 'md' | 'lg' | 'xl';
  layoutDensity: 'compact' | 'normal' | 'spacious';
}
