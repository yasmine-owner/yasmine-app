/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { ERPProvider, useERP } from './context/ERPContext';
import { Sidebar } from './components/layout/Sidebar';
import { TopHeader } from './components/layout/TopHeader';
import { DashboardModule } from './components/modules/DashboardModule';
import { JournalModule } from './components/modules/JournalModule';
import { AccountingModule } from './components/modules/AccountingModule';
import { PartnersModule } from './components/modules/PartnersModule';
import { TreasuryModule } from './components/modules/TreasuryModule';
import { ManufacturingModule } from './components/modules/ManufacturingModule';
import { MachinesModule } from './components/modules/MachinesModule';
import { CuttingToolsModule } from './components/modules/CuttingToolsModule';
import { InventoryModule } from './components/modules/InventoryModule';
import { SalesPurchasesModule } from './components/modules/SalesPurchasesModule';
import { ScrapDowntimeModule } from './components/modules/ScrapDowntimeModule';
import { CostingPricingModule } from './components/modules/CostingPricingModule';
import { FixedAssetsModule } from './components/modules/FixedAssetsModule';
import { ReportsModule } from './components/modules/ReportsModule';
import { AppearanceModule } from './components/modules/AppearanceModule';
import { BackupExportModule } from './components/modules/BackupExportModule';
import { OwnerSecretModule } from './components/modules/OwnerSecretModule';
import { MobileBottomNav } from './components/layout/MobileBottomNav';

function MainApp() {
  const [activeModule, setActiveModule] = useState<string>('dashboard');
  const [collapsed, setCollapsed] = useState<boolean>(false);
  const [mobileOpen, setMobileOpen] = useState<boolean>(false);
  const { theme, currentUser } = useERP();

  const renderModule = () => {
    switch (activeModule) {
      case 'dashboard':
        return <DashboardModule setActiveModule={setActiveModule} />;
      case 'journal':
        return <JournalModule />;
      case 'accounting':
        return <AccountingModule />;
      case 'partners':
        return <PartnersModule />;
      case 'treasury':
        return <TreasuryModule />;
      case 'manufacturing':
        return <ManufacturingModule />;
      case 'machines':
        return <MachinesModule />;
      case 'cutting_tools':
        return <CuttingToolsModule />;
      case 'inventory':
        return <InventoryModule />;
      case 'sales_purchases':
        return <SalesPurchasesModule />;
      case 'scrap_downtime':
        return <ScrapDowntimeModule />;
      case 'costing_pricing':
        return <CostingPricingModule />;
      case 'fixed_assets':
        return <FixedAssetsModule />;
      case 'reports':
        return <ReportsModule />;
      case 'appearance':
        return <AppearanceModule />;
      case 'backup_export':
        return <BackupExportModule />;
      case 'owner_secret':
        return <OwnerSecretModule />;
      default:
        return <DashboardModule setActiveModule={setActiveModule} />;
    }
  };

  return (
    <div className="flex h-screen w-full overflow-hidden bg-slate-950 text-slate-100 font-sans" dir="rtl">
      {/* Sidebar Navigation (Desktop Column + Mobile Drawer) */}
      <Sidebar
        activeModule={activeModule}
        setActiveModule={setActiveModule}
        collapsed={collapsed}
        setCollapsed={setCollapsed}
        mobileOpen={mobileOpen}
        setMobileOpen={setMobileOpen}
      />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0 h-full overflow-hidden bg-slate-950">
        <TopHeader
          activeModule={activeModule}
          setActiveModule={setActiveModule}
          onOpenMobileMenu={() => setMobileOpen(true)}
        />

        <main className="flex-1 overflow-y-auto p-3 sm:p-5 lg:p-8 space-y-5 sm:space-y-6 pb-24 lg:pb-8">
          {renderModule()}
        </main>
      </div>

      {/* Mobile Bottom Navigation Bar */}
      <MobileBottomNav
        activeModule={activeModule}
        setActiveModule={setActiveModule}
        openMobileMenu={() => setMobileOpen(true)}
      />
    </div>
  );
}

export default function App() {
  return (
    <ERPProvider>
      <MainApp />
    </ERPProvider>
  );
}
