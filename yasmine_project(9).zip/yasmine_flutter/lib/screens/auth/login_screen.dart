import 'package:flutter/material.dart';
import '../../services/auth_service.dart';
import 'tech_register_screen.dart';
import '../customer/customer_home.dart';

/// شاشة الدخول — وضع التجربة: دخول مباشر برقم الموبايل بدون SMS
/// (نرجع OTP الحقيقي عند تفعيل خطة Blaze قبل الإطلاق)
class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final phone = TextEditingController();
  bool loading = false;

  Future<void> _directLogin() async {
    final ph = phone.text.trim();
    if (ph.length != 11) {
      ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('اكتب رقم موبايل صحيح (11 رقم)')));
      return;
    }
    setState(() => loading = true);
    final role = await showDialog<String>(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        title: const Text('أهلاً بيك في الياسمين'),
        content: const Text('سجّل دخولك كـ:'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context, 'customer'),
              child: const Text('🚗 عميل')),
          TextButton(
              onPressed: () => Navigator.pop(context, 'tech'),
              child: const Text('🔧 فني / صنايعي')),
        ],
      ),
    );
    if (role == 'customer') {
      await AuthService.registerCustomerDirect(uid: ph, name: ph, phone: ph);
      if (!mounted) return;
      Navigator.pushReplacement(
          context, MaterialPageRoute(builder: (_) => CustomerHome(uid: ph)));
    } else if (role == 'tech') {
      if (!mounted) return;
      Navigator.pushReplacement(context,
          MaterialPageRoute(builder: (_) => TechRegisterScreen(uid: ph)));
    }
    if (mounted) setState(() => loading = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Spacer(),
              Center(
                child: Container(
                  width: 90,
                  height: 90,
                  decoration: BoxDecoration(
                    color: const Color(0xFF4DA3FF),
                    borderRadius: BorderRadius.circular(26),
                  ),
                  child: const Center(
                    child: Text('ي',
                        style: TextStyle(
                            fontSize: 44,
                            fontWeight: FontWeight.bold,
                            color: Color(0xFF0D1F3C))),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              const Center(
                  child: Text('الياسمين لإصلاح أعطال السيارات',
                      style: TextStyle(
                          fontSize: 18, fontWeight: FontWeight.bold))),
              const Center(
                  child: Text('في الطرق والصحراء — فنيك يوصلك في مكانك',
                      style: TextStyle(color: Colors.grey))),
              const Spacer(),
              TextField(
                controller: phone,
                keyboardType: TextInputType.phone,
                maxLength: 11,
                decoration: const InputDecoration(
                    labelText: 'رقم الموبايل (11 رقم)', counterText: ''),
              ),
              const SizedBox(height: 12),
              ElevatedButton(
                onPressed: loading ? null : _directLogin,
                child: loading
                    ? const SizedBox(
                        width: 22,
                        height: 22,
                        child: CircularProgressIndicator(
                            color: Colors.white, strokeWidth: 2))
                    : const Text('دخول'),
              ),
              const SizedBox(height: 8),
              const Text(
                'وضع التجربة: الدخول مباشر بدون كود — التحقق بالـ SMS يُفعَّل قبل الإطلاق',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 11, color: Colors.grey),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
