import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../../services/auth_service.dart';
import '../tech/tech_home.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

/// تسجيل فني جديد — لا يستقبل طلبات إلا بعد اعتماد المالك من اللوحة
class TechRegisterScreen extends StatefulWidget {
  final String uid;
  const TechRegisterScreen({super.key, required this.uid});
  @override
  State<TechRegisterScreen> createState() => _TechRegisterScreenState();
}

class _TechRegisterScreenState extends State<TechRegisterScreen> {
  final name = TextEditingController(), area = TextEditingController();
  List<String> specs = [];
  bool loading = false;

  Future<void> _save() async {
    if (name.text.trim().isEmpty || area.text.trim().isEmpty || specs.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('أكمل الاسم والمنطقة واختر تخصصاً')));
      return;
    }
    setState(() => loading = true);
    await AuthService.registerTechnician({
      'name': name.text.trim(), 'phone': FirebaseAuth.instance.currentUser?.phoneNumber ?? '',
      'area': area.text.trim(), 'specs': specs,
    });
    if (!mounted) return;
    Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => TechHome(uid: widget.uid)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(appBar: AppBar(title: const Text('تسجيل فني جديد')),
      body: StreamBuilder(
        stream: FirebaseFirestore.instance.collection('settings').doc('app').snapshots(),
        builder: (_, snap) {
          final svcs = Map<String, bool>.from(snap.data?.data()?['services'] ?? const {});
          return ListView(padding: const EdgeInsets.all(16), children: [
            TextField(controller: name, decoration: const InputDecoration(labelText: 'الاسم')),
            const SizedBox(height: 10),
            TextField(controller: area, decoration: const InputDecoration(labelText: 'المناطق التي تعمل بها')),
            const SizedBox(height: 16),
            const Text('تخصصاتك', style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            ...svcs.entries.where((e) => e.value).map((e) => CheckboxListTile(
              title: Text(e.key), value: specs.contains(e.key),
              onChanged: (v) => setState(() => v! ? specs.add(e.key) : specs.remove(e.key)),
            )),
            const SizedBox(height: 10),
            ElevatedButton(onPressed: loading ? null : _save, child: const Text('إرسال للاعتماد')),
            const SizedBox(height: 10),
            const Card(color: Color(0xFFFDF1DC), child: Padding(padding: EdgeInsets.all(12),
              child: Text('⏳ لن تستقبل طلبات مدفوعة إلا بعد اعتماد حسابك من المالك.', style: TextStyle(color: Color(0xFF9A6305))))),
          ]);
        },
      ));
  }
}
