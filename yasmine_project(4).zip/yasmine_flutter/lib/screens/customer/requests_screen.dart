import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../../models/models.dart';
import '../../services/db_service.dart';
import 'package:url_launcher/url_launcher.dart';

/// طلبات العميل الكاملة — دورة الطلب بالكامل من الدفع حتى التقييم
class RequestsScreen extends StatelessWidget {
  final String uid;
  const RequestsScreen({super.key, required this.uid});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder(
      stream: DbService.myRequests(uid),
      builder: (_, snap) {
        if (!snap.hasData) return const Center(child: CircularProgressIndicator());
        final list = snap.data!;
        if (list.isEmpty) return const Center(child: Text('لسه مفيش طلبات — اطلب من الرئيسية'));
        return ListView(padding: const EdgeInsets.all(12), children: list.map((r) => _RequestCard(r: r, uid: uid)).toList());
      },
    );
  }
}

class _RequestCard extends StatelessWidget {
  final RequestModel r; final String uid;
  const _RequestCard({required this.r, required this.uid});

  Color _statusColor(String s) => {
    'completed': Colors.green, 'accepted': Colors.blue, 'working': Colors.blue,
    'cancelled': Colors.grey, 'refunded': Colors.grey,
    'open': Colors.teal, 'awaiting_payment': Colors.red, 'awaiting_tech_payment': Colors.orange, 'chosen': Colors.orange,
  }[s] ?? Colors.grey;

  @override
  Widget build(BuildContext context) {
    return Card(margin: const EdgeInsets.only(bottom: 12), child: Padding(padding: const EdgeInsets.all(12), child: Column(
      crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [
        Expanded(child: Text(r.serviceId, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16))),
        Chip(label: Text(RequestStatusLabel(r.status)), backgroundColor: _statusColor(r.status).withOpacity(.12)),
      ]),
      Text('${r.car} • ${r.loc}', style: const TextStyle(color: Colors.grey, fontSize: 13)),
      const SizedBox(height: 8),
      if (r.status == 'awaiting_payment')
        const _Notice(color: Color(0xFFFDF1DC), text: '💸 حوّل الرسوم على حسابات المالك وأرفق الإيصال من بطاقة الرسوم في الرئيسية — الطلب ينشر بعد تأكيد المالك فقط.'),
      if (r.status == 'open') _Offers(r: r),
      if (r.status == 'chosen' || r.status == 'awaiting_tech_payment')
        _Notice(color: const Color(0xFFFDF1DC), text: r.status == 'chosen'
          ? '⏳ اخترت فني — بيدفع إيداع المنصة الآن، موقعك يتفتح له بعد تأكيد المالك.'
          : '⏳ وصل إيصال إيداع الفني — بانتظار تأكيد المالك.'),
      if (r.status == 'accepted' || r.status == 'working') _Tracking(r: r),
      if (r.status == 'completed') _Rating(r: r),
      if (['open', 'chosen', 'awaiting_tech_payment'].contains(r.status))
        TextButton(onPressed: () => _cancel(context), child: const Text('إلغاء الطلب')),
    ])));
  }

  Future<void> _cancel(BuildContext context) async {
    final ok = await showDialog<bool>(context: context, builder: (_) => AlertDialog(
      title: const Text('إلغاء الطلب؟'),
      content: const Text('رسومك تتحول لطلب استرداد يراجعه المالك وفق السياسة.'),
      actions: [TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('تراجع')),
        FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('إلغاء'))]));
    if (ok == true) {
      await DbService.advanceRequest(r.id, 'cancelled');
      final p = await DbService.payments.where('reqId', isEqualTo: r.id).where('party', isEqualTo: 'customer').get();
      for (final d in p.docs) { if (d['status'] == 'success' || d['status'] == 'pending') await d.reference.update({'status': 'refund_requested'}); }
    }
  }
}

// عروض الفنيين + الاختيار
class _Offers extends StatelessWidget {
  final RequestModel r;
  const _Offers({required this.r});

  @override
  Widget build(BuildContext context) {
    if (r.offers.isEmpty) return const _Notice(color: Color(0xFFE8F2FF), text: '🔎 بنبحث لك عن فنيين معتمدين قريبين...');
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text('عروض الفنيين (${r.offers.length}) — اختار الأنسب:', style: const TextStyle(fontWeight: FontWeight.bold)),
      const SizedBox(height: 6),
      FutureBuilder(
        future: DbService.technicians.get(),
        builder: (_, snap) {
          final techs = {for (final d in snap.data?.docs ?? []) d.id: Technician.fromDoc(d)};
          return Column(children: r.offers.map((o) {
            final t = techs[o.techId];
            return Card(child: Padding(padding: const EdgeInsets.all(10), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                Expanded(child: Text(t?.name ?? 'فني', style: const TextStyle(fontWeight: FontWeight.bold))),
                if (t != null) Chip(label: Text('★ ${t.rating} (${t.jobs})'), visualDensity: VisualDensity.compact),
              ]),
              if (t != null) Text(t.area, style: const TextStyle(color: Colors.grey, fontSize: 12)),
              Wrap(spacing: 6, children: [
                Chip(label: Text('📍 ${o.dist}'), visualDensity: VisualDensity.compact),
                Chip(label: Text('⏱ ${o.eta} دقيقة'), visualDensity: VisualDensity.compact),
                Chip(label: Text('تقديري: ${o.price} ج'), visualDensity: VisualDensity.compact),
              ]),
              const SizedBox(height: 4),
              SizedBox(width: double.infinity, child: FilledButton(
                onPressed: () => DbService.chooseOffer(r.id, o.techId),
                child: const Text('اختيار هذا الفني'))),
            ])));
          }).toList());
        },
      ),
    ]);
  }
}

// التتبع + تأكيد الإنهاء + التواصل + الشكوى
class _Tracking extends StatelessWidget {
  final RequestModel r;
  const _Tracking({required this.r});

  Future<void> _complain(BuildContext context) async {
    final c = TextEditingController();
    final ok = await showDialog<bool>(context: context, builder: (_) => AlertDialog(
      title: const Text('⚠️ شكوى / طلب استرداد'),
      content: TextField(controller: c, maxLines: 4, decoration: const InputDecoration(hintText: 'اكتب تفاصيل الشكوى')),
      actions: [TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('إلغاء')),
        FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('إرسال'))]));
    if (ok == true && c.text.trim().isNotEmpty) {
      await DbService.addComplaint({'reqId': r.id, 'by': r.customerName, 'phone': r.customerPhone,
        'text': c.text.trim(), 'status': 'open', 't': FieldValue.serverTimestamp()});
    }
  }

  @override
  Widget build(BuildContext context) {
    final steps = ['accepted', 'working', 'completed'];
    final idx = r.status == 'accepted' ? 0 : 1;
    return FutureBuilder(
      future: DbService.technicians.doc(r.chosenTechId).get(),
      builder: (_, snap) {
        final t = snap.hasData ? Technician.fromDoc(snap.data!) : null;
        return Column(children: [
          Row(children: steps.asMap().entries.map((e) {
            final done = e.key <= idx, last = e.key == steps.length - 1;
            return Expanded(child: Row(children: [
              CircleAvatar(radius: 12, backgroundColor: done ? Colors.blue : Colors.grey.shade300,
                child: Icon(done ? Icons.check : Icons.circle, size: 10, color: Colors.white)),
              if (!last) Expanded(child: Container(height: 2, color: done ? Colors.blue : Colors.grey.shade300)),
            ]));
          }).toList()),
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: const [
            Text('في الطريق', style: TextStyle(fontSize: 11)), Text('جارٍ العمل', style: TextStyle(fontSize: 11)), Text('تم', style: TextStyle(fontSize: 11))]),
          const SizedBox(height: 8),
          if (t != null) Card(color: const Color(0xFFE4F7EC), child: ListTile(
            leading: const Icon(Icons.build_circle, color: Colors.green),
            title: Text('🔧 ${t.name}'),
            subtitle: Text('${t.phoneNumber} — اتفقوا مباشرة على سعر الإصلاح'),
            trailing: IconButton(icon: const Icon(Icons.call, color: Colors.green),
              onPressed: () => launchUrl(Uri.parse('tel:${t.phoneNumber}'))),
          )),
          if (r.status == 'working') SizedBox(width: double.infinity, child: FilledButton(
            style: FilledButton.styleFrom(backgroundColor: Colors.green),
            onPressed: () => DbService.advanceRequest(r.id, 'completed'),
            child: const Text('✅ تأكيد انتهاء الخدمة'))),
          TextButton(onPressed: () => _complain(context), child: const Text('⚠️ شكوى / طلب استرداد')),
        ]);
      },
    );
  }
}

// التقييم بالنجوم
class _Rating extends StatelessWidget {
  final RequestModel r;
  const _Rating({required this.r});

  @override
  Widget build(BuildContext context) {
    int val = 5;
    return StatefulBuilder(builder: (_, setS) => Column(children: [
      const Text('🎉 الخدمة اكتملت — قيّم الفني:', style: TextStyle(fontWeight: FontWeight.bold)),
      const SizedBox(height: 6),
      Row(mainAxisAlignment: MainAxisAlignment.center, children: List.generate(5, (i) => IconButton(
        icon: Icon(i < val ? Icons.star : Icons.star_border, color: Colors.amber, size: 32),
        onPressed: () => setS(() => val = i + 1)))),
      FilledButton(onPressed: () => DbService.rate(r.id, r.chosenTechId, val), child: const Text('إرسال التقييم')),
    ]));
  }
}

class _Notice extends StatelessWidget {
  final Color color; final String text;
  const _Notice({required this.color, required this.text});
  @override
  Widget build(BuildContext context) => Container(
    width: double.infinity, padding: const EdgeInsets.all(10), decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(10)),
    child: Text(text, style: const TextStyle(fontSize: 12.5)));
}

String RequestStatusLabel(String s) => const {
  'awaiting_payment': 'بانتظار دفع الرسوم', 'awaiting_tech_payment': 'بانتظار تأكيد إيداع الفني',
  'open': 'منشور — بانتظار العروض', 'chosen': 'تم اختيار فني', 'accepted': 'الفني في الطريق',
  'working': 'جارٍ العمل', 'completed': 'مكتمل', 'cancelled': 'ملغى', 'refunded': 'مسترد',
}[s] ?? s;
