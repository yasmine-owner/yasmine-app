#!/bin/bash
# ==============================================================================
# سكربت نشر تطبيق «الياسمين جو | YASMIN GO» في مستودعات جوجل السحابية
# Google Cloud Source Repositories & Cloud Build
# مهندس المنصة: محمد صلاح
# ==============================================================================

set -e

PROJECT_ID="yasmin-go-egypt"
REPO_NAME="yasmin-go-app"
REGION="europe-west3"

echo "🚀 بدء تجهيز مستودع جوجل السحابي لمشروع الياسمين جو..."

# 1. تهيئة Git محلياً
if [ ! -d ".git" ]; then
  git init
  echo "✅ تم تهيئة مستودع Git محلي"
fi

git add .
git commit -m "feat: Initial commit of YASMIN GO Mobility & Rescue Platform (By Eng. Mohamed Salah)" || true

# 2. تسجيل الدخول والاتصال بـ Google Cloud SDK
echo "🔑 التحقق من Google Cloud CLI (gcloud)..."
# gcloud auth login
# gcloud config set project $PROJECT_ID

# 3. إنشاء مستودع Google Cloud Source Repository
echo "📦 إنشاء مستودع جوجل السحابي باسم $REPO_NAME ..."
# gcloud source repos create $REPO_NAME || true

# 4. ربط المستودع ودفع الكود
echo "🔄 دفع الأكواد إلى مستودع جوجل السحابي..."
# git remote add google https://source.developers.google.com/p/$PROJECT_ID/r/$REPO_NAME || true
# git push --all google

# 5. بناء الحاوية على Google Cloud Build والنشر على Cloud Run
echo "⚡ بناء ونشر التطبيق على Google Cloud Run..."
# gcloud builds submit --tag gcr.io/$PROJECT_ID/$REPO_NAME
# gcloud run deploy yasmin-go --image gcr.io/$PROJECT_ID/$REPO_NAME --platform managed --region $REGION --allow-unauthenticated

echo "🎉 تم اكتمال الإرشادات بنجاح!"
