export type PortalType = 'customer' | 'technician' | 'owner' | 'architecture';

export type AppLanguage = 'ar' | 'en';

export type RoadEnvironment = 'desert' | 'highway' | 'city';

export type ServiceTypeCategory = 'ride' | 'breakdown' | 'winch';

export type ServiceCategoryId =
  | 'smart_ride'
  | 'tires'
  | 'batteries_electric'
  | 'mechanics_engine'
  | 'cooling_heat'
  | 'brakes_suspension'
  | 'diagnostics_obd'
  | 'ac_cooling'
  | 'winch_desert_rescue'
  | 'parts_delivery'
  | 'key_services'
  | 'hybrid_electric';

export type ProviderRole =
  | 'driver'
  | 'mechanic'
  | 'tire_battery'
  | 'winch_operator'
  | 'auto_electrician';

export type ProviderVerificationStatus = 'pending_review' | 'approved' | 'rejected' | 'suspended';

export type RideVehicleCategory = 'standard' | 'comfort' | 'family_van' | 'desert_4x4';

export interface ServiceCategory {
  id: ServiceCategoryId;
  type: ServiceTypeCategory;
  titleAr: string;
  titleEn: string;
  subtitleAr: string;
  subtitleEn: string;
  iconName: string;
  badgeAr: string;
  badgeEn: string;
  subServicesAr: string[];
  subServicesEn: string[];
  requiredQualificationsAr: string;
  defaultPlatformFeeEgp: number;
  active: boolean;
  emergencyPriority: boolean;
}

export interface Vehicle {
  id: string;
  brand: string;
  model: string;
  year: string;
  plateNumber: string;
  driveType: 'دفع أمامي / خلفي' | 'دفع رباعي 4x4' | 'نقل خفيف / بيك أب' | 'سيارة كهربائية';
}

export interface EgyptLocation {
  id: string;
  roadName: string;
  governorate: string;
  environment: RoadEnvironment;
  kmMarker: string;
  direction: string;
  coordinates: { lat: string; lng: string };
  landmark: string;
  coverageStatus: 'قوية 4G' | 'متوسطة 3G' | 'طوارئ صحراوية';
  mapX: number;
  mapY: number;
}

export interface TechnicianReview {
  id: string;
  customerName: string;
  date: string;
  rating: number;
  serviceTitle: string;
  roadLocation: string;
  comment: string;
}

export interface TechnicianDocument {
  id: string;
  title: string;
  refNumber: string;
  expiryDate: string;
  status: 'معتمد' | 'قيد المراجعة' | 'يحتاج تجديد';
  fileUrl?: string;
}

export interface Technician {
  id: string;
  name: string;
  phoneMasked: string;
  phoneFull: string;
  role: ProviderRole;
  verificationStatus: ProviderVerificationStatus;
  specialtyTitle: string;
  categories: ServiceCategoryId[];
  supportedVehicles: string[];
  coveredZones: string[];
  vehicleModel: string;
  vehiclePlate: string;
  rating: number;
  reviewsCount: number;
  completedRescues: number;
  isVerified: boolean;
  isAvailable: boolean;
  isDesertEquipped: boolean;
  walletBalanceEgp: number;
  totalEarningsEgp: number;
  commissionDueEgp: number;
  documents: TechnicianDocument[];
  reviews: TechnicianReview[];
  joinedDate: string;
  nationalIdNumber?: string;
}

export interface TechnicianOffer {
  id: string;
  requestId: string;
  technician: Technician;
  quotePriceEgp: number;
  etaMinutes: number;
  distanceKm: number;
  technicianNote: string;
  createdAt: string;
  platformFeeTechnicianEgp: number;
}

export type OrderStatus =
  | 'draft'
  | 'pending_otp'
  | 'pending_payment'
  | 'paid_broadcasting'
  | 'pending_offers'
  | 'offer_accepted'
  | 'technician_fee_pending'
  | 'technician_fee_paid'
  | 'technician_en_route'
  | 'technician_arrived'
  | 'in_progress'
  | 'completed'
  | 'cancelled';

export interface BreakdownOrder {
  id: string;
  orderCode: string;
  orderType: 'ride' | 'breakdown' | 'winch';
  customerName: string;
  customerPhone: string;
  customerVerifiedWithOtp?: boolean;
  vehicle: Vehicle;
  categoryId: ServiceCategoryId;
  serviceTitle: string;
  pickupAddress?: string;
  destinationAddress?: string;
  suggestedFareEgp?: number;
  rideCategory?: RideVehicleCategory;
  symptoms: string[];
  problemDescription: string;
  environment: RoadEnvironment;
  location: EgyptLocation;
  customKm: string;
  customerPlatformFeeEgp: number;
  customerPaidPlatformFee: boolean;
  selectedOffer?: TechnicianOffer;
  technicianPlatformFeeEgp?: number;
  technicianPaidPlatformFee?: boolean;
  locationRevealed?: boolean;
  status: OrderStatus;
  createdAt: string;
  trackingStep: number; // 0 to 4
  repairCostAgreedEgp?: number;
  paymentMethod?: 'cash' | 'instapay' | 'vodafone_cash' | 'card';
  customerRating?: number;
  customerReviewText?: string;
  complaint?: {
    reason: string;
    status: 'مفتوحة' | 'قيد المراجعة' | 'تم الحل' | 'تم الاسترداد';
    refundRequested: boolean;
  };
}

export interface CoverageZone {
  id: string;
  name: string;
  governorate: string;
  environment: RoadEnvironment;
  activeTechniciansCount: number;
  basePlatformFeeEgp: number;
  desertMultiplier: number;
  status: 'نشط' | 'تغطية جزئية' | 'مغلق مؤقتاً';
  patrolPoints: string;
}

export interface CustomerRecord {
  id: string;
  name: string;
  phone: string;
  governorate: string;
  vehiclesCount: number;
  totalOrders: number;
  status: 'نشط' | 'محظور';
  joinedDate: string;
  isOtpVerified?: boolean;
}

export interface ComplaintRecord {
  id: string;
  ticketCode: string;
  orderCode: string;
  customerName: string;
  technicianName: string;
  roadName: string;
  category: string;
  description: string;
  createdAt: string;
  priority: 'عاجل' | 'متوسط' | 'عادي';
  status: 'مفتوحة' | 'قيد المراجعة' | 'تم الحل';
  resolutionAction?: string;
}

export interface PlatformTransaction {
  id: string;
  refCode: string;
  orderCode: string;
  party: 'العميل' | 'الفني';
  partyName: string;
  amountEgp: number;
  type: 'رسوم منصة' | 'استرداد رسوم' | 'تسوية محفظة' | 'عمولة نقل ذكي';
  paymentProvider: 'InstaPay (محاكاة)' | 'Vodafone Cash (محاكاة)' | 'Fawry (محاكاة)' | 'Paymob (محاكاة)' | 'نقدي للكابتن';
  status: 'ناجحة (محاكاة)' | 'معلقة' | 'مستردة' | 'فاشلة';
  date: string;
  reason?: string;
  receivingAccountId?: string;
}

export type ReceivingAccountType =
  | 'instapay'
  | 'vodafone_cash'
  | 'orange_cash'
  | 'etisalat_cash'
  | 'bank_account'
  | 'paymob_gateway'
  | 'fawry_gateway';

export interface PaymentReceivingAccount {
  id: string;
  title: string;
  type: ReceivingAccountType;
  accountIdentifier: string;
  accountHolderName: string;
  bankOrProviderName: string;
  merchantIdOrCode?: string;
  apiKeyOrSecretMasked?: string;
  isDefault: boolean;
  isActive: boolean;
  totalCollectedEgp: number;
  notes: string;
  updatedAt: string;
}

export interface SubAdmin {
  id: string;
  name: string;
  email: string;
  phone: string;
  role: 'support' | 'verifier' | 'finance' | 'operations';
  roleTitleAr: string;
  permissions: string[];
  active: boolean;
  createdAt: string;
}

export interface PlatformPricingSettings {
  rideCommissionPercent: number;
  breakdownCommissionPercent: number;
  winchCommissionPercent: number;
  minBaseFareEgp: number;
  perKmRateEgp: number;
  desertMultiplier: number;
  autoApproveProviders: boolean;
  emergencyHotline: string;
  allowCashPayments: boolean;
}

export interface SystemNotification {
  id: string;
  title: string;
  titleEn: string;
  body: string;
  bodyEn: string;
  target: 'all' | 'customers' | 'providers';
  date: string;
  icon?: string;
  read?: boolean;
}
