import React, { useState } from 'react';
import {
  Smartphone,
  Crown,
  Copy,
  Check,
  ExternalLink,
  X,
  Download,
  AlertTriangle,
  HelpCircle,
  Share2,
  ShieldCheck,
  Sparkles,
  QrCode,
  ArrowRight,
  Layers,
  Monitor,
} from 'lucide-react';
import { AppLanguage } from '../../types/yasmine';

interface InstallGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: AppLanguage;
  onTriggerNativeInstall?: () => void;
  hasNativePrompt?: boolean;
}

export const InstallGuideModal: React.FC<InstallGuideModalProps> = ({
  isOpen,
  onClose,
  language,
  onTriggerNativeInstall,
  hasNativePrompt,
}) => {
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'quick_install' | 'owner_vs_client' | 'google_play' | 'zip_download'>('quick_install');

  if (!isOpen) return null;

  const currentOrigin =
    typeof window !== 'undefined'
      ? window.location.origin
      : 'https://ais-pre-oh34kbidnyqsw3p72bxc6f-561396168334.europe-west3.run.app';

  const publicAppUrl = currentOrigin;
  const ownerAppUrl = `${currentOrigin}/?view=owner`;

  const copyToClipboard = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 3000);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-5 overflow-y-auto">
      <div className="bg-[#0B192C] border border-sky-500/30 rounded-3xl max-w-3xl w-full text-white shadow-2xl overflow-hidden my-auto max-h-[90vh] flex flex-col">
        {/* Modal Header */}
        <div className="bg-gradient-to-r from-sky-950 via-slate-900 to-amber-950/60 p-4 sm:p-6 border-b border-sky-500/20 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-sky-500/20 border border-sky-500/40 flex items-center justify-center text-sky-400">
              <Smartphone className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-base sm:text-lg font-black text-white flex items-center gap-2">
                <span>دليل تثبيت وتشغيل التطبيق على الهواتف</span>
                <span className="text-[11px] bg-sky-500/20 text-sky-300 border border-sky-500/30 px-2 py-0.5 rounded-full font-mono">
                  الياسمين جو
                </span>
              </h3>
              <p className="text-xs text-slate-300 mt-0.5">
                توضيح كامل لكيفية التثبيت على هاتفك وهواتف العملاء والفنيين
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-9 h-9 rounded-xl bg-white/10 hover:bg-white/20 text-slate-300 hover:text-white flex items-center justify-center transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-sky-500/20 bg-slate-950/60 px-3 sm:px-6 gap-2 overflow-x-auto shrink-0 text-xs font-black">
          <button
            type="button"
            onClick={() => setActiveTab('quick_install')}
            className={`py-3 px-3 border-b-2 transition-all flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
              activeTab === 'quick_install'
                ? 'border-sky-400 text-sky-300'
                : 'border-transparent text-slate-400 hover:text-white'
            }`}
          >
            <Smartphone className="w-4 h-4" />
            <span>١. الروابط المباشرة والتثبيت السريع</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('owner_vs_client')}
            className={`py-3 px-3 border-b-2 transition-all flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
              activeTab === 'owner_vs_client'
                ? 'border-amber-400 text-amber-300'
                : 'border-transparent text-slate-400 hover:text-white'
            }`}
          >
            <Crown className="w-4 h-4 text-amber-400" />
            <span>٢. هل لوحة المالك تنزل مع تطبيق العميل؟</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('google_play')}
            className={`py-3 px-3 border-b-2 transition-all flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
              activeTab === 'google_play'
                ? 'border-emerald-400 text-emerald-300'
                : 'border-transparent text-slate-400 hover:text-white'
            }`}
          >
            <Layers className="w-4 h-4 text-emerald-400" />
            <span>٣. الرفع على متجر Google Play</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('zip_download')}
            className={`py-3 px-3 border-b-2 transition-all flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
              activeTab === 'zip_download'
                ? 'border-purple-400 text-purple-300'
                : 'border-transparent text-slate-400 hover:text-white'
            }`}
          >
            <Download className="w-4 h-4 text-purple-400" />
            <span>٤. تحميل الملفات المضغوطة (ZIP)</span>
          </button>
        </div>

        {/* Tab Content */}
        <div className="p-4 sm:p-6 overflow-y-auto space-y-6 flex-1 text-slate-200">
          {/* TAB 1: QUICK INSTALL LINKS */}
          {activeTab === 'quick_install' && (
            <div className="space-y-6">
              {/* Highlight Card with Instant Install Action */}
              <div className="p-5 rounded-2xl bg-gradient-to-r from-sky-950/80 via-slate-900 to-sky-950 border border-sky-500/40 space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div className="flex items-start gap-3">
                    <Sparkles className="w-5 h-5 text-sky-400 shrink-0 mt-0.5" />
                    <div>
                      <div className="font-black text-sky-200 text-sm">
                        حل مشكلة التثبيت: الآن أصبح تطبيقاً رسمياً مستقلاً (وليس مجرد صفحة جوجل)!
                      </div>
                      <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                        تم تفعيل محرك الـ PWA، وربط أيقونات الأندرويد الرسمية وملف الخدمة <code className="text-amber-300 font-mono">sw.js</code>. الآن يمكنك تثبيته فوراً ليعمل كأي تطبيق نزلته من المتجر.
                      </p>
                    </div>
                  </div>

                  {onTriggerNativeInstall && (
                    <button
                      type="button"
                      onClick={() => {
                        onClose();
                        onTriggerNativeInstall();
                      }}
                      className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-sky-400 to-sky-500 hover:from-sky-300 hover:to-sky-400 text-slate-950 font-black text-xs flex items-center gap-2 shadow-lg shadow-sky-500/30 shrink-0 transition-all cursor-pointer active:scale-95 whitespace-nowrap self-start sm:self-auto"
                    >
                      <Smartphone className="w-4 h-4" />
                      <span>{hasNativePrompt ? '📲 تثبيت التطبيق الآن على الهاتف' : '📲 فتح نافذة التثبيت المباشر'}</span>
                    </button>
                  )}
                </div>

                <div className="p-3 rounded-xl bg-emerald-950/40 border border-emerald-500/30 text-emerald-200 text-xs flex items-center gap-2">
                  <Check className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span>
                    <strong>النتيجة بعد التثبيت:</strong> ستظهر أيقونة «الياسمين جو» على شاشة هاتفك، وعند فتحها لن يظهر متصفح جوجل ولا شريط الروابط، بل يفتح كـ App كامل!
                  </span>
                </div>
              </div>

              {/* Grid: Client App vs Owner Dashboard */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Link 1: Client & Driver App */}
                <div className="p-5 rounded-2xl bg-slate-900/90 border border-sky-500/30 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-black text-sky-400 bg-sky-500/10 px-2.5 py-1 rounded-lg border border-sky-500/20">
                      رابط تطبيق الجمهور (العميل والسائق)
                    </span>
                    <span className="text-[11px] text-slate-400">للهاتف والكمبيوتر</span>
                  </div>

                  <p className="text-xs text-slate-300">
                    هذا هو الرابط الذي ترسله للعميل ليطلب رحلة أو ونش، وللفني أو الكابتن لتقديم عروض الأسعار:
                  </p>

                  <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between gap-2">
                    <code className="text-[11px] text-sky-300 font-mono truncate select-all">
                      {publicAppUrl}
                    </code>
                    <button
                      type="button"
                      onClick={() => copyToClipboard(publicAppUrl, 'public_url')}
                      className="px-3 py-1 rounded-lg bg-sky-500 hover:bg-sky-400 text-slate-950 font-bold text-xs flex items-center gap-1 shrink-0 transition-all cursor-pointer"
                    >
                      {copiedKey === 'public_url' ? (
                        <>
                          <Check className="w-3.5 h-3.5" />
                          <span>تم النسخ</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3.5 h-3.5" />
                          <span>نسخ الرابط</span>
                        </>
                      )}
                    </button>
                  </div>

                  <div className="text-[11px] text-slate-400 space-y-1 bg-slate-950/50 p-3 rounded-xl border border-slate-800/80">
                    <div className="font-bold text-sky-300">طريقة التثبيت على هاتف العميل/السائق:</div>
                    <div>1. افتح الرابط في متصفح الموبايل (Chrome أو Safari).</div>
                    <div>2. اضغط على خيارات المتصفح (الثلاث نقاط أو زر المشاركة).</div>
                    <div>3. اختر <strong>«تثبيت التطبيق»</strong> أو <strong>«إضافة إلى الشاشة الرئيسية»</strong>.</div>
                    <div>4. سيظهر تطبيق «الياسمين جو» بأيقونته الرسمية على شاشة الهاتف كأي تطبيق عادي!</div>
                  </div>
                </div>

                {/* Link 2: Owner Dashboard */}
                <div className="p-5 rounded-2xl bg-amber-950/20 border border-amber-500/40 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-black text-amber-400 bg-amber-500/10 px-2.5 py-1 rounded-lg border border-amber-500/20 flex items-center gap-1">
                      <Crown className="w-3.5 h-3.5 text-amber-400" />
                      <span>رابط لوحة تحكم المالك الحصرية</span>
                    </span>
                    <span className="text-[11px] text-amber-400 font-bold">PIN: 2025</span>
                  </div>

                  <p className="text-xs text-amber-200/90">
                    خاص بك وحدك (المهندس محمد صلاح). يتيح لك التحكم في العمولات والأسعار وحسابات إنستاباي وفودافون كاش واعتماد الفنيين:
                  </p>

                  <div className="p-2.5 rounded-xl bg-slate-950 border border-amber-900/40 flex items-center justify-between gap-2">
                    <code className="text-[11px] text-amber-300 font-mono truncate select-all">
                      {ownerAppUrl}
                    </code>
                    <button
                      type="button"
                      onClick={() => copyToClipboard(ownerAppUrl, 'owner_url')}
                      className="px-3 py-1 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs flex items-center gap-1 shrink-0 transition-all cursor-pointer"
                    >
                      {copiedKey === 'owner_url' ? (
                        <>
                          <Check className="w-3.5 h-3.5" />
                          <span>تم النسخ</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3.5 h-3.5" />
                          <span>نسخ الرابط</span>
                        </>
                      )}
                    </button>
                  </div>

                  <div className="text-[11px] text-amber-200/80 space-y-1 bg-amber-950/40 p-3 rounded-xl border border-amber-500/20">
                    <div className="font-bold text-amber-300">طريقة تثبيت لوحة المالك على تليفونك الشخصي:</div>
                    <div>1. افتح الرابط السري أعلاه من تليفونك أنت فقط.</div>
                    <div>2. اضغط على خيارات المتصفح واختر <strong>«إضافة إلى الشاشة الرئيسية»</strong>.</div>
                    <div>3. ستنزل أيقونة خاصة بك باسم «لوحة المالك»، وافتحها وأدخل الرمز السري <strong>2025</strong>.</div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: OWNER VS CLIENT SEPARATION EXPLANATION */}
          {activeTab === 'owner_vs_client' && (
            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-emerald-950/40 border border-emerald-500/30 flex items-start gap-3">
                <ShieldCheck className="w-6 h-6 text-emerald-400 shrink-0 mt-0.5" />
                <div className="text-xs space-y-1.5">
                  <div className="font-bold text-emerald-200 text-sm">
                    إجابة حاسمة ومباشرة: هل لوحة التحكم تنزل على تليفون العميل أو الفني؟
                  </div>
                  <p className="text-emerald-100/90 leading-relaxed text-xs">
                    <strong>لا إطلاقاً وبشكل قاطع!</strong> التطبيق مصمم بمعمارية الفصل التام (Role-Based Isolation). العميل والفني لا يستطيعان رؤية لوحة التحكم ولا يعلمان بوجودها في التطبيق الذي ينزلانه.
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                {/* On other phones (Customer / Technician) */}
                <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
                  <div className="font-bold text-sky-400 flex items-center gap-1.5">
                    <Smartphone className="w-4 h-4" />
                    <span>ماذا يرى العميل والفني على هواتفهم؟</span>
                  </div>
                  <ul className="space-y-2 text-slate-300 list-disc list-inside leading-relaxed">
                    <li>يرى العميل: واجهة طلب المشوار، تحديد الموقع، واقتراح السعر واستقبال العروض، أو طلب صيانة وونش إنقاذ.</li>
                    <li>يرى الفني/الكابتن: رادار الطلبات القريبة، تقديم عرض سعر، والتنقل بالخريطة، وسداد عمولة المنصة لمحفظتك.</li>
                    <li><strong className="text-red-400">لا يوجد أي زر أو رابط يفتح لوحة التحكم أو أرباح المنصة.</strong></li>
                  </ul>
                </div>

                {/* On your personal phone (The Owner) */}
                <div className="p-4 rounded-2xl bg-amber-950/30 border border-amber-500/30 space-y-3">
                  <div className="font-bold text-amber-400 flex items-center gap-1.5">
                    <Crown className="w-4 h-4 text-amber-400" />
                    <span>ماذا يكون على تليفونك أنت الشخصي؟</span>
                  </div>
                  <ul className="space-y-2 text-amber-100/90 list-disc list-inside leading-relaxed">
                    <li>تثبت أنت رابط لوحة التحكم برمز PIN سري خاص بك: <code className="font-mono bg-black/40 px-1 rounded">2025</code> (يمكنك تغييره في أي وقت).</li>
                    <li>تتحكم في: نسبة عمولة التطبيق (مثلاً 10% أو 15%)، وأسعار الخدمات.</li>
                    <li>تحدد وتعدل أرقامك التي تُرسل عليها العمولات (حساب إنستاباي، ورقم فودافون كاش).</li>
                    <li>تعمل أنت كمدير للمنظومة: اعتماد السائقين الجدد، وحل الشكاوى.</li>
                  </ul>
                </div>
              </div>

              <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 text-xs text-slate-300 space-y-2">
                <div className="font-bold text-white flex items-center gap-2">
                  <HelpCircle className="w-4 h-4 text-sky-400" />
                  <span>هل أثبت التطبيق على تليفوني وتليفون آخر للتجربة؟</span>
                </div>
                <p className="leading-relaxed">
                  <strong>نعم، هذا هو السيناريو الأفضل تماماً لاختبار التطبيق:</strong>
                  <br />
                  1. افتح هاتفك أنت كمالك على رابط لوحة التحكم للمراقبة.
                  <br />
                  2. أحضر هاتف شخص آخر (أو افتح نافذة تصفح خفي) وافتح رابط الجمهور، وادخل كـ «عميل» واطلب مشواراً.
                  <br />
                  3. ادخل من تليفون ثالث أو متصفح آخر كـ «كابتن» وقدم عرض سعر للعميل ووافق عليه.. وستشاهد في تليفونك كمالك العمولة والطلب يظهران لحظياً!
                </p>
              </div>
            </div>
          )}

          {/* TAB 3: GOOGLE PLAY PUBLISHING */}
          {activeTab === 'google_play' && (
            <div className="space-y-4 text-xs">
              <div className="p-4 rounded-2xl bg-slate-900 border border-sky-500/30 space-y-2">
                <div className="font-bold text-sky-300 text-sm flex items-center gap-2">
                  <Layers className="w-4 h-4 text-sky-400" />
                  <span>كيف تحوّل الرابط إلى تطبيق Google Play رسمي (.AAB / .APK)؟</span>
                </div>
                <p className="text-slate-300 leading-relaxed">
                  بما أن التطبيق مبني كـ Progressive Web App مع ملف <code className="font-mono text-amber-300">manifest.json</code> وأيقونات مخصصة، يمكنك استخراج ملف التطبيق لمتجر Google Play في خطوات سهلة:
                </p>
              </div>

              <div className="space-y-3">
                <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 flex items-start gap-3">
                  <span className="w-6 h-6 rounded-full bg-sky-500 text-slate-950 font-black flex items-center justify-center shrink-0 text-xs">1</span>
                  <div>
                    <div className="font-bold text-white">الخطوة الأولى: أداة PWABuilder (أداة رسمية مجانية من مايكروسوفت وجوجل):</div>
                    <div className="text-slate-400 mt-1">
                      ادخل على موقع <a href="https://www.pwabuilder.com" target="_blank" rel="noreferrer" className="text-sky-400 underline font-mono">pwabuilder.com</a>، وضع رابط تطبيق الجمهور واضغط Start.
                    </div>
                  </div>
                </div>

                <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 flex items-start gap-3">
                  <span className="w-6 h-6 rounded-full bg-sky-500 text-slate-950 font-black flex items-center justify-center shrink-0 text-xs">2</span>
                  <div>
                    <div className="font-bold text-white">الخطوة الثانية: توليد حزمة الأندرويد (Generate Android Package):</div>
                    <div className="text-slate-400 mt-1">
                      اضغط على زر «Android Bundle»، سيقوم الموقع بتحميل ملف جاهز بصيغة <code className="font-mono text-emerald-300">app-release.aab</code>.
                    </div>
                  </div>
                </div>

                <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 flex items-start gap-3">
                  <span className="w-6 h-6 rounded-full bg-sky-500 text-slate-950 font-black flex items-center justify-center shrink-0 text-xs">3</span>
                  <div>
                    <div className="font-bold text-white">الخطوة الثالثة: الرفع على Google Play Console:</div>
                    <div className="text-slate-400 mt-1">
                      تسجل بحساب مطور في جوجل بلاي (Google Play Developer Console)، وترفع الملف <code className="font-mono text-emerald-300">app-release.aab</code>، وتضع اسم التطبيق «الياسمين جو» والوصف وصور الشاشة.
                    </div>
                  </div>
                </div>
              </div>

              <div className="p-3.5 rounded-xl bg-amber-950/30 border border-amber-500/30 text-amber-200">
                <strong>تنبيه هام جداً:</strong> عند النشر على Google Play، أنت تنشر رابط <strong>تطبيق الجمهور فقط</strong>. لا تضع رابط لوحة المالك في تطبيق المتجر حتى لا يراها أي مستخدم عادي.
              </div>
            </div>
          )}

          {/* TAB 4: DOWNLOAD ZIP & CLOUD REPOSITORIES */}
          {activeTab === 'zip_download' && (
            <div className="space-y-4 text-xs">
              <div className="p-5 rounded-2xl bg-gradient-to-r from-emerald-950/60 to-slate-900 border border-emerald-500/40 flex flex-col sm:flex-row items-center justify-between gap-4">
                <div>
                  <div className="font-black text-white text-sm flex items-center gap-2">
                    <Download className="w-5 h-5 text-emerald-400" />
                    <span>تحميل الكود والملفات بالكامل في ملف مضغوط (.ZIP)</span>
                  </div>
                  <p className="text-slate-300 text-xs mt-1">
                    الملف يحتوي على جميع الأكواد المصدرية، ملفات الواجهات، إعدادات النشر Dockerfile، وسكربت الرفع التلقائي.
                  </p>
                </div>

                <a
                  href="/yasmin-go-app.zip"
                  download="yasmin-go-app.zip"
                  className="px-5 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs flex items-center gap-2 shadow-lg shadow-emerald-500/30 shrink-0 transition-all cursor-pointer"
                >
                  <Download className="w-4 h-4" />
                  <span>تنزيل الملف المضغوط (ZIP)</span>
                </a>
              </div>

              <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
                <div className="font-bold text-white text-xs">طريقة رفع الملف المضغوط إلى مستودعات جوجل (Google Cloud Source Repositories):</div>
                <div className="space-y-2 text-slate-300 leading-relaxed font-mono text-[11px] bg-slate-950 p-3 rounded-xl border border-slate-800">
                  <div className="text-slate-500"># 1. فك ضغط الملف على جهاز الكمبيوتر:</div>
                  <div>unzip yasmin-go-app.zip -d yasmin-go</div>
                  <div>cd yasmin-go</div>
                  <div className="text-slate-500 mt-2"># 2. إنشاء مستودع جوجل السحابي:</div>
                  <div>gcloud source repos create yasmin-go-repo</div>
                  <div className="text-slate-500 mt-2"># 3. ربط الكود ورفعه:</div>
                  <div>git init</div>
                  <div>git add .</div>
                  <div>git commit -m &quot;Initial commit: YASMIN GO Platform&quot;</div>
                  <div>git push --all google</div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="bg-slate-950/80 px-4 sm:px-6 py-3 border-t border-sky-500/20 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs shrink-0">
          <span className="text-slate-400 text-[11px]">
            منصة الياسمين جو | YASMIN GO — بقيادة المهندس محمد صلاح
          </span>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold cursor-pointer"
            >
              إغلاق النافذة
            </button>
            <button
              type="button"
              onClick={() => {
                copyToClipboard(publicAppUrl, 'footer_copy');
              }}
              className="px-4 py-1.5 rounded-xl bg-sky-500 hover:bg-sky-400 text-slate-950 font-black flex items-center gap-1.5 cursor-pointer"
            >
              {copiedKey === 'footer_copy' ? (
                <>
                  <Check className="w-3.5 h-3.5" />
                  <span>تم نسخ رابط التطبيق</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  <span>نسخ رابط التطبيق للجمهور</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
