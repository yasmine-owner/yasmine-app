import React from 'react';
import {
  ShieldAlert,
  ShieldCheck,
  Disc,
  BatteryCharging,
  Wrench,
  Thermometer,
  Cpu,
  Wind,
  Truck,
  PackageCheck,
  Key,
  Zap,
  Car,
  CheckCircle2,
  Clock,
  Sparkles,
  PhoneCall,
  Navigation,
} from 'lucide-react';
import { ServiceCategoryId, AppLanguage } from '../../types/yasmine';

interface LogoProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  variant?: 'dark' | 'light';
  showSubtitle?: boolean;
  language?: AppLanguage;
}

export const YasmineLogo: React.FC<LogoProps> = ({
  size = 'md',
  variant = 'dark',
  showSubtitle = true,
  language = 'ar',
}) => {
  const iconDimensions = {
    sm: 'w-8 h-8',
    md: 'w-11 h-11',
    lg: 'w-14 h-14',
    xl: 'w-20 h-20',
  }[size];

  const titleClasses = {
    sm: 'text-sm font-extrabold',
    md: 'text-base sm:text-lg font-black',
    lg: 'text-xl sm:text-2xl font-black',
    xl: 'text-2xl sm:text-3xl font-black',
  }[size];

  const textColor = variant === 'dark' ? 'text-white' : 'text-[#0B192C]';
  const subTextColor = variant === 'dark' ? 'text-sky-300' : 'text-sky-700';

  return (
    <div className="inline-flex items-center gap-3 select-none">
      <div
        className={`${iconDimensions} relative rounded-2xl bg-gradient-to-br from-[#0B192C] via-[#0F2542] to-[#040C16] border border-sky-400/40 flex items-center justify-center shadow-lg shadow-sky-500/10 shrink-0 overflow-hidden ring-1 ring-sky-500/20`}
      >
        <div className="absolute inset-0 bg-gradient-to-tr from-sky-500/20 via-transparent to-amber-400/15 pointer-events-none" />
        
        {/* Custom YASMIN GO Emblem */}
        <svg
          viewBox="0 0 64 64"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="w-4/5 h-4/5 relative z-10 drop-shadow"
          aria-label="الياسمين جو YASMIN GO"
        >
          {/* Rescue & Mobility Shield Outer */}
          <path
            d="M32 4L55 12V29C55 44 45 54.5 32 59.5C19 54.5 9 44 9 29V12L32 4Z"
            fill="#0A1829"
            stroke="#38BDF8"
            strokeWidth="2.4"
          />

          {/* Golden Roadway Paths (Moving Forward / GO) */}
          <path
            d="M20 52L28.5 34H35.5L44 52"
            stroke="#38BDF8"
            strokeWidth="2.2"
            strokeLinecap="round"
          />
          <path
            d="M32 35V52"
            stroke="#F59E0B"
            strokeWidth="2"
            strokeDasharray="3 3"
            strokeLinecap="round"
          />

          {/* Fast Car / Tow Silhouette */}
          <path
            d="M26 31L29 24H35L38 31H26Z"
            fill="#0284C7"
            opacity="0.9"
          />
          <circle cx="28" cy="31" r="2.2" fill="#F8FAFC" />
          <circle cx="36" cy="31" r="2.2" fill="#F8FAFC" />

          {/* Egyptian Jasmine Flower 5 Petals */}
          <g transform="translate(32, 17)">
            <ellipse cx="0" cy="-5" rx="2.5" ry="4.5" fill="#FFFFFF" />
            <ellipse
              cx="4.7"
              cy="-1.5"
              rx="2.5"
              ry="4.5"
              transform="rotate(72 4.7 -1.5)"
              fill="#FFFFFF"
            />
            <ellipse
              cx="2.9"
              cy="4"
              rx="2.5"
              ry="4.5"
              transform="rotate(144 2.9 4)"
              fill="#FFFFFF"
            />
            <ellipse
              cx="-2.9"
              cy="4"
              rx="2.5"
              ry="4.5"
              transform="rotate(216 -2.9 4)"
              fill="#FFFFFF"
            />
            <ellipse
              cx="-4.7"
              cy="-1.5"
              rx="2.5"
              ry="4.5"
              transform="rotate(288 -4.7 -1.5)"
              fill="#FFFFFF"
            />
            <circle cx="0" cy="0" r="2.3" fill="#F59E0B" />
            <circle cx="0" cy="0" r="1.1" fill="#FFFFFF" />
          </g>
        </svg>
      </div>

      <div className="flex flex-col">
        <div className="flex items-center gap-1.5">
          <span className={`${titleClasses} ${textColor} tracking-tight leading-tight whitespace-nowrap font-black`}>
            {language === 'ar' ? 'الياسمين جو' : 'YASMIN GO'}
          </span>
          <span className="text-[10px] sm:text-xs font-black px-1.5 py-0.5 rounded-md bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 shadow-sm uppercase tracking-wider">
            GO
          </span>
        </div>
        {showSubtitle && (
          <span className={`text-[10px] sm:text-xs font-bold ${subTextColor} mt-0.5 whitespace-nowrap`}>
            {language === 'ar'
              ? 'نقل ذكي • أعطال سيارات • ونش وإنقاذ مصر'
              : 'Smart Rides • Roadside • Towing Egypt'}
          </span>
        )}
      </div>
    </div>
  );
};

export const SimulationNotice: React.FC<{
  title: string;
  description: string;
  variant?: 'sky' | 'navy' | 'amber';
}> = ({ title, description, variant = 'sky' }) => {
  if (variant === 'amber') {
    return (
      <div className="rounded-2xl bg-amber-500/10 text-amber-200 p-3.5 border border-amber-500/30 flex items-start gap-3">
        <Sparkles className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
        <div className="text-xs leading-relaxed">
          <p className="font-extrabold text-amber-300 mb-0.5">{title}</p>
          <p className="text-amber-100/90">{description}</p>
        </div>
      </div>
    );
  }

  if (variant === 'navy') {
    return (
      <div className="rounded-2xl bg-[#0B192C] text-white p-3.5 border border-sky-500/30 flex items-start gap-3 shadow-md">
        <ShieldCheck className="w-5 h-5 text-sky-400 shrink-0 mt-0.5" />
        <div className="text-xs leading-relaxed">
          <p className="font-extrabold text-sky-300 mb-0.5">{title}</p>
          <p className="text-slate-200">{description}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="rounded-2xl bg-sky-50 text-[#0B192C] p-3.5 border border-sky-200 flex items-start gap-3">
      <ShieldCheck className="w-5 h-5 text-sky-600 shrink-0 mt-0.5" />
      <div className="text-xs leading-relaxed">
        <p className="font-extrabold text-[#0B192C] mb-0.5">{title}</p>
        <p className="text-slate-700">{description}</p>
      </div>
    </div>
  );
};

export const SafetyEmergencyBanner: React.FC<{ language?: AppLanguage }> = ({ language = 'ar' }) => {
  return (
    <div className="rounded-2xl bg-amber-500/10 border border-amber-500/30 p-3.5 flex items-start gap-3 text-amber-100 text-xs leading-relaxed">
      <ShieldAlert className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
      <div>
        <span className="font-black block text-amber-300 mb-0.5">
          {language === 'ar'
            ? 'إرشادات السلامة الإلزامية على الطرق السريعة والصحراوية في مصر:'
            : 'Mandatory Safety Instructions on Egyptian Desert & Highway Routes:'}
        </span>
        {language === 'ar'
          ? 'توقف بأمان على الطبان الأيمن بعيداً عن مسار السيارات، قم بتشغيل إشارات الانتظار الرباعية فوراً، ضع مثلث التحذير العاكس على بعد ٥٠–١٠٠ متر، وانتظر داخل السيارة بحزام الأمان إذا كانت المنطقة خطرة أو مزدحمة.'
          : 'Pull over safely to the right shoulder away from main traffic lanes, turn on hazard lights immediately, set reflective warning triangle 50-100m behind vehicle, and keep seatbelts fastened.'}
      </div>
    </div>
  );
};

export const CategoryIcon: React.FC<{
  categoryId: ServiceCategoryId;
  className?: string;
}> = ({ categoryId, className = 'w-5 h-5 text-sky-400' }) => {
  switch (categoryId) {
    case 'smart_ride':
      return <Car className={className} />;
    case 'winch_desert_rescue':
      return <Truck className={className} />;
    case 'tires':
      return <Disc className={className} />;
    case 'batteries_electric':
      return <BatteryCharging className={className} />;
    case 'mechanics_engine':
      return <Wrench className={className} />;
    case 'cooling_heat':
      return <Thermometer className={className} />;
    case 'brakes_suspension':
      return <ShieldAlert className={className} />;
    case 'diagnostics_obd':
      return <Cpu className={className} />;
    case 'ac_cooling':
      return <Wind className={className} />;
    case 'parts_delivery':
      return <PackageCheck className={className} />;
    case 'key_services':
      return <Key className={className} />;
    case 'hybrid_electric':
      return <Zap className={className} />;
    default:
      return <Wrench className={className} />;
  }
};
