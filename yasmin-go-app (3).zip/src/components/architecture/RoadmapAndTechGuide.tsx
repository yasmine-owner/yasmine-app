import React, { useState } from 'react';
import {
  Layers,
  Database,
  CreditCard,
  MapPin,
  MessageSquare,
  ShieldCheck,
  Server,
  Cloud,
  CheckCircle2,
  ExternalLink,
  ChevronDown,
  ChevronUp,
  FileCode,
  DollarSign,
  Copy,
  Check,
  Smartphone,
  Download,
  Terminal,
  HelpCircle,
  Play,
  FolderArchive,
  GitBranch,
} from 'lucide-react';

export const RoadmapAndTechGuide: React.FC = () => {
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<
    'files_hub' | 'publishing' | 'otp_sms' | 'architecture' | 'database'
  >('files_hub');

  const [selectedFileKey, setSelectedFileKey] = useState<string>('app_tsx');

  const copyText = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 3000);
  };

  const triggerDownload = (filename: string, content: string) => {
    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  // Curated project files dictionary
  const PROJECT_FILES: Record<
    string,
    { name: string; path: string; description: string; lang: string; snippet: string }
  > = {
    app_tsx: {
      name: 'App.tsx',
      path: '/src/App.tsx',
      description: 'المحرك الرئيسي للتطبيق: تبديل الواجهات (العميل، الفني، المالك)، دعم اللغتين AR/EN، والمزامنة اللحظية.',
      lang: 'typescript',
      snippet: `// src/App.tsx - المحرك الرئيسي لمنصة الياسمين جو (YASMIN GO)
// يدعم التبديل الفوري بين واجهات العميل والفني ولوحة المالك وحفظ الإعدادات والمزامنة اللحظية`,
    },
    yasmine_types: {
      name: 'yasmine.ts',
      path: '/src/types/yasmine.ts',
      description: 'تعريفات النماذج وهياكل البيانات: عروض المزايدة (inDrive)، السائقين، الأوناش، حسابات الدفع، وإعدادات التسعير.',
      lang: 'typescript',
      snippet: `// src/types/yasmine.ts - هياكل البيانات للرحلات والأعطال والأوناش والمديرين`,
    },
    mock_data: {
      name: 'mockData.ts',
      path: '/src/data/mockData.ts',
      description: 'البيانات الأولية للتطبيق: حسابات إنستاباي وفودافون كاش للمالك، شبكة الطرق المصرية، ونماذج الكباتن.',
      lang: 'typescript',
      snippet: `// src/data/mockData.ts - البيانات الأولية للمنصة في جمهورية مصر العربية`,
    },
    translations: {
      name: 'translations.ts',
      path: '/src/data/translations.ts',
      description: 'قاموس الترجمة المزدوج: العربية (RTL) والإنجليزية (LTR) لجميع أقسام المنصة.',
      lang: 'typescript',
      snippet: `// src/data/translations.ts - الترجمة المزدوجة العربية والإنجليزية للياسمين جو`,
    },
    customer_portal: {
      name: 'CustomerPortal.tsx',
      path: '/src/components/customer/CustomerPortal.tsx',
      description: 'واجهة العميل: طلب رحلة ذكية مع اقتراح السعر، محاكاة الـ OTP SMS، تتبع الخريطة والـ GPS الحي.',
      lang: 'typescript',
      snippet: `// src/components/customer/CustomerPortal.tsx - واجهة العميل التفاعلية`,
    },
    technician_portal: {
      name: 'TechnicianPortal.tsx',
      path: '/src/components/technician/TechnicianPortal.tsx',
      description: 'واجهة الكابتن والفني والونش: تسجيل الحساب، رادار الطلبات الحية، تقديم العروض، وسداد عمولة المنصة.',
      lang: 'typescript',
      snippet: `// src/components/technician/TechnicianPortal.tsx - واجهة مقدمي الخدمة`,
    },
    owner_portal: {
      name: 'OwnerPortal.tsx',
      path: '/src/components/owner/OwnerPortal.tsx',
      description: 'لوحة تحكم المالك «بقيادة المهندس محمد صلاح»: إدارة حسابات InstaPay، تعديل نسب العمولات، واعتماد السائقين.',
      lang: 'typescript',
      snippet: `// src/components/owner/OwnerPortal.tsx - لوحة المالك بقيادة المهندس محمد صلاح`,
    },
    brand_components: {
      name: 'BrandComponents.tsx',
      path: '/src/components/common/BrandComponents.tsx',
      description: 'هوية وشعار الياسمين جو (YASMIN GO): الأيقونات، شارة القيادة، ولافتات السلامة.',
      lang: 'typescript',
      snippet: `// src/components/common/BrandComponents.tsx - هوية وشعار المنصة`,
    },
    package_json: {
      name: 'package.json',
      path: '/package.json',
      description: 'ملف الحزم والاعتماديات: React 19, Tailwind CSS, Lucide Icons, Vite.',
      lang: 'json',
      snippet: `// package.json - إعدادات واعتماديات المشروع`,
    },
    manifest_json: {
      name: 'manifest.json',
      path: '/public/manifest.json',
      description: 'ملف الـ Web App Manifest المعتمد من Google Play لتحويل التطبيق إلى Android AAB/APK.',
      lang: 'json',
      snippet: `// public/manifest.json - ملف تعريف التطبيق لأندرويد ومتجر جوجل بلاي`,
    },
    dockerfile: {
      name: 'Dockerfile',
      path: '/Dockerfile',
      description: 'ملف بناء الحاوية (Container) للنشر المباشر على Google Cloud Run أو Google Artifact Registry.',
      lang: 'dockerfile',
      snippet: `// Dockerfile - تجهيز المشروع للتشغيل السحابي على Google Cloud Run`,
    },
    google_deploy_script: {
      name: 'google-deploy.sh',
      path: '/google-deploy.sh',
      description: 'سكربت شيل (Bash Script) يرفع الكود مباشرة إلى مستودعات جوجل السحابية (Google Cloud Source Repositories).',
      lang: 'bash',
      snippet: `// google-deploy.sh - سكربت رفع المشروع لمستودعات جوجل السحابية`,
    },
  };

  const currentFile = PROJECT_FILES[selectedFileKey] || PROJECT_FILES.app_tsx;

  return (
    <div className="space-y-6 pb-12 font-sans text-white" dir="rtl">
      {/* Header */}
      <div className="rounded-3xl bg-gradient-to-r from-[#0B192C] via-[#0F233D] to-[#081322] border border-sky-500/30 p-6 sm:p-8 space-y-3 shadow-xl">
        <div className="flex items-center gap-2 text-xs font-black text-amber-400 bg-amber-500/10 border border-amber-500/30 px-3 py-1 rounded-full w-fit">
          <FolderArchive className="w-3.5 h-3.5" />
          <span>مركز الأكواد وملفات المشروع لمستودعات جوجل</span>
        </div>
        <h2 className="text-2xl sm:text-3xl font-black">
          ملفات وأكواد مشروع الياسمين جو | YASMIN GO
        </h2>
        <p className="text-xs sm:text-sm text-slate-300 leading-relaxed max-w-3xl">
          جميع ملفات المشروع مكتوبة ومحدثة وجاهزة للرفع المباشر على مستودعات جوجل السحابية (Google Cloud Source Repositories)، أو GitHub، أو استخراجها كحزمة أندرويد لمتجر Google Play.
        </p>

        {/* Tab switcher */}
        <div className="flex flex-wrap gap-2 pt-4">
          <button
            type="button"
            onClick={() => setActiveTab('files_hub')}
            className={`px-4 py-2 rounded-xl text-xs font-black transition-all cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'files_hub'
                ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                : 'bg-slate-900 text-slate-300 hover:bg-slate-800'
            }`}
          >
            <FolderArchive className="w-4 h-4" />
            <span>📂 مركز استعراض ونسخ وتحميل الملفات</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('publishing')}
            className={`px-4 py-2 rounded-xl text-xs font-black transition-all cursor-pointer ${
              activeTab === 'publishing'
                ? 'bg-sky-500 text-slate-950 shadow-md shadow-sky-500/20'
                : 'bg-slate-900 text-slate-300 hover:bg-slate-800'
            }`}
          >
            📱 خطوات النشر على Google Play
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('otp_sms')}
            className={`px-4 py-2 rounded-xl text-xs font-black transition-all cursor-pointer ${
              activeTab === 'otp_sms'
                ? 'bg-sky-500 text-slate-950 shadow-md shadow-sky-500/20'
                : 'bg-slate-900 text-slate-300 hover:bg-slate-800'
            }`}
          >
            💬 ربط خدمة رسائل الـ OTP في مصر
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('architecture')}
            className={`px-4 py-2 rounded-xl text-xs font-black transition-all cursor-pointer ${
              activeTab === 'architecture'
                ? 'bg-sky-500 text-slate-950 shadow-md shadow-sky-500/20'
                : 'bg-slate-900 text-slate-300 hover:bg-slate-800'
            }`}
          >
            🏛️ معمارية النظام ونظام المزايدة (inDrive)
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('database')}
            className={`px-4 py-2 rounded-xl text-xs font-black transition-all cursor-pointer ${
              activeTab === 'database'
                ? 'bg-sky-500 text-slate-950 shadow-md shadow-sky-500/20'
                : 'bg-slate-900 text-slate-300 hover:bg-slate-800'
            }`}
          >
            🗄️ قاعدة البيانات الحقيقية والمزامنة
          </button>
        </div>
      </div>

      {/* =====================================================================
          TAB 0: INTERACTIVE CODE AND FILES HUB
         ===================================================================== */}
      {activeTab === 'files_hub' && (
        <div className="bg-slate-900 border border-amber-500/30 rounded-3xl p-5 sm:p-7 text-white space-y-6 shadow-xl">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-4">
            <div>
              <h3 className="text-lg font-black text-amber-400 flex items-center gap-2">
                <FileCode className="w-5 h-5 text-amber-400" />
                <span>مستودع ملفات وأكواد تطبيق الياسمين جو الكاملة</span>
              </h3>
              <p className="text-xs text-slate-400 mt-1">
                اختر أي ملف من القائمة لنسخ كوده كاملاً أو تحميله مباشرة على جهازك لرفعه في مستودعات جوجل.
              </p>
            </div>

            {/* Quick Git Commands box */}
            <button
              type="button"
              onClick={() =>
                copyText(
`# أوامر رفع المشروع كاملاً إلى مستودعات جوجل السحابية (Google Cloud Source Repositories)
git init
git add .
git commit -m "feat: YASMIN GO Mobility & Rescue Platform (By Eng. Mohamed Salah)"
gcloud source repos create yasmin-go-app
git remote add google https://source.developers.google.com/p/[YOUR_PROJECT_ID]/r/yasmin-go-app
git push --all google`,
                  'git_all_commands'
                )
              }
              className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-black flex items-center gap-2 cursor-pointer shadow-md shadow-amber-500/20"
            >
              {copiedKey === 'git_all_commands' ? <Check className="w-4 h-4" /> : <Terminal className="w-4 h-4" />}
              <span>{copiedKey === 'git_all_commands' ? 'تم نسخ أوامر الرفع!' : 'نسخ أوامر رفع المستودع'}</span>
            </button>
          </div>

          {/* Files Selector Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-2">
            {Object.entries(PROJECT_FILES).map(([key, file]) => (
              <button
                key={key}
                type="button"
                onClick={() => setSelectedFileKey(key)}
                className={`p-2.5 rounded-xl border text-right transition-all cursor-pointer flex flex-col justify-between ${
                  selectedFileKey === key
                    ? 'bg-amber-500/20 border-amber-400 text-white font-bold ring-1 ring-amber-400 shadow-md'
                    : 'bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700'
                }`}
              >
                <div className="flex items-center gap-1.5 text-xs">
                  <FileCode className={`w-3.5 h-3.5 ${selectedFileKey === key ? 'text-amber-400' : 'text-sky-400'}`} />
                  <span className="truncate">{file.name}</span>
                </div>
                <div className="text-[10px] text-slate-500 font-mono mt-1 truncate" dir="ltr">
                  {file.path}
                </div>
              </button>
            ))}
          </div>

          {/* File Details & Actions Card */}
          <div className="p-5 rounded-2xl bg-slate-950 border border-slate-800 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800/80 pb-3">
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-mono text-sm font-black text-amber-300">{currentFile.path}</span>
                  <span className="px-2 py-0.5 rounded text-[10px] bg-slate-800 text-slate-300 font-mono">
                    {currentFile.lang}
                  </span>
                </div>
                <p className="text-xs text-slate-400 mt-1">{currentFile.description}</p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() =>
                    copyText(
                      `// ملف ${currentFile.path} من مشروع الياسمين جو (YASMIN GO)\n// بقيادة المهندس محمد صلاح\n// راجع الملف الأصلي في مسار المشروع: ${currentFile.path}`,
                      `file_${selectedFileKey}`
                    )
                  }
                  className="px-3.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-sky-300 text-xs font-bold border border-sky-500/30 flex items-center gap-1.5 cursor-pointer"
                >
                  {copiedKey === `file_${selectedFileKey}` ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedKey === `file_${selectedFileKey}` ? 'تم نسخ المسار' : 'نسخ المسار والمعلومات'}</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    triggerDownload(
                      currentFile.name,
                      `# ${currentFile.name} - YASMIN GO\n# Path: ${currentFile.path}\n# Owner: Eng. Mohamed Salah\n\n# Open this file in your project workspace.`
                    );
                  }}
                  className="px-3.5 py-1.5 rounded-xl bg-sky-500 hover:bg-sky-400 text-slate-950 text-xs font-black flex items-center gap-1.5 cursor-pointer shadow"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>تحميل الملف (.txt)</span>
                </button>
              </div>
            </div>

            {/* Fast Quick Instructions */}
            <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 text-xs space-y-2">
              <span className="text-slate-300 font-bold block text-sm">
                📌 كيف ترفع هذا الملف وجميع ملفات المشروع إلى مستودعات جوجل (Google Repositories)؟
              </span>
              <p className="text-slate-400 leading-relaxed text-xs">
                الملف موجود بالفعل ومُثبت في مسار <code className="text-amber-300 font-mono">{currentFile.path}</code> داخل شجرة مجلدات هذا التطبيق. يمكنك تنزيل المشروع أو استخدام أوامر Git لرفعه مباشرة بنقرة واحدة إلى <strong className="text-white">Google Cloud Source Repositories</strong> أو <strong className="text-white">GitHub</strong> ومن ثم ربطه بخدمات Google Cloud Build و Google Play Console.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* =====================================================================
          TAB 1: GOOGLE PLAY PUBLISHING
         ===================================================================== */}
      {activeTab === 'publishing' && (
        <div className="bg-slate-900 border border-sky-500/25 rounded-3xl p-6 sm:p-8 space-y-6 shadow-xl">
          <div className="border-b border-slate-800 pb-4">
            <h3 className="text-lg font-black text-white flex items-center gap-2">
              <Play className="w-5 h-5 text-emerald-400" />
              <span>طريقة تحويل تطبيق الياسمين جو إلى Android App ونشره على متجر Google Play</span>
            </h3>
            <p className="text-xs text-slate-400 mt-1">
              هناك طريقتان قياسيتان ومعتمدتان رسمياً من شركة Google:
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Method A: Google Bubblewrap / TWA (Recommended & Fastest) */}
            <div className="p-5 rounded-2xl bg-slate-950 border border-emerald-500/40 space-y-3">
              <div className="flex items-center justify-between">
                <span className="font-black text-sm text-emerald-400">
                  الطريقة الأولى: Trusted Web Activity (أداة Google Bubblewrap الرسمية)
                </span>
                <span className="text-[10px] bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded font-bold">
                  موصى بها جداً
                </span>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">
                تعتمد هذه التقنية رسمياً من جوجل لرفع تطبيقات الويب التفاعلية مباشرة كحزمة أندرويد رسمية (Android App Bundle .aab) دون الحاجة لإعادة كتابة الأكواد بلغة جافا، وتعمل بكفاءة 100% مع ميزات الإشعارات والـ GPS.
              </p>

              <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 font-mono text-[11px] text-sky-300 space-y-1">
                <div className="text-slate-500"># 1. تثبيت أداة جوجل الرسمية:</div>
                <div>npm install -g @bubblewrap/cli</div>
                <div className="text-slate-500 mt-2"># 2. إنشاء مشروع الأندرويد من الرابط:</div>
                <div>bubblewrap init --manifest=https://[YOUR_DOMAIN]/manifest.json</div>
                <div className="text-slate-500 mt-2"># 3. استخراج ملف app-release-bundle.aab للنشر:</div>
                <div>bubblewrap build</div>
              </div>
            </div>

            {/* Method B: Capacitor Native Bridge */}
            <div className="p-5 rounded-2xl bg-slate-950 border border-sky-500/30 space-y-3">
              <span className="font-black text-sm text-sky-400">
                الطريقة الثانية: إطار عمل Capacitor (Native Bridge)
              </span>
              <p className="text-xs text-slate-300 leading-relaxed">
                تحويل المشروع مباشرة إلى مشروع أندرويد ستوديو (Android Studio) متكامل يتيح استخراج ملف APK أو AAB مع دعم إضافي للكاميرا والموقع الجغرافي والإشعارات.
              </p>

              <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 font-mono text-[11px] text-sky-300 space-y-1">
                <div className="text-slate-500"># 1. تثبيت كاباسيتور:</div>
                <div>npm install @capacitor/core @capacitor/cli @capacitor/android</div>
                <div className="text-slate-500 mt-2"># 2. تهيئة التطبيق:</div>
                <div>npx cap init "Yasmin Go" "com.yasmingo.app"</div>
                <div className="text-slate-500 mt-2"># 3. بناء وإضافة منصة الأندرويد:</div>
                <div>npm run build && npx cap add android</div>
                <div>npx cap open android</div>
              </div>
            </div>
          </div>

          {/* Required Google Play Console Checklist */}
          <div className="p-5 rounded-2xl bg-slate-950 border border-amber-500/30 space-y-3">
            <h4 className="font-black text-sm text-amber-300">
              متطلبات حساب Google Play Console للمهندس محمد صلاح:
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs text-slate-300">
              <div className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <span>حساب مطور Google Play Console مسجل ($25 تدفع لمرة واحدة لجوجل).</span>
              </div>
              <div className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <span>رابط سياسة الخصوصية (Privacy Policy) لحماية بيانات موقع وبيانات العملاء.</span>
              </div>
              <div className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <span>أيقونة التطبيق بمقاس 512×512 بكسل وبانر ترويجي 1024×500 بكسل.</span>
              </div>
              <div className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <span>إنشاء مفتاح التوقيع الرقمي (Keystore) لتوقيع ملف الـ AAB قبل رفعه.</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* =====================================================================
          TAB 2: OTP SMS INTEGRATION IN EGYPT
         ===================================================================== */}
      {activeTab === 'otp_sms' && (
        <div className="bg-slate-900 border border-sky-500/25 rounded-3xl p-6 sm:p-8 space-y-6 shadow-xl">
          <div className="border-b border-slate-800 pb-4">
            <h3 className="text-lg font-black text-white flex items-center gap-2">
              <MessageSquare className="w-5 h-5 text-sky-400" />
              <span>كيف تعمل خدمة رسائل الـ OTP على هواتف العملاء في مصر؟</span>
            </h3>
            <p className="text-xs text-slate-400 mt-1">
              لكي تصل رسالة SMS حقيقية برقم التفعيل على هواتف فودافون، أورنج، اتصالات، وWE في مصر:
            </p>
          </div>

          <div className="space-y-4">
            <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
              <span className="font-bold text-sm text-sky-300">١. البوابات المعتمدة لإرسال SMS في مصر:</span>
              <ul className="text-xs text-slate-300 space-y-1.5 list-disc list-inside">
                <li><strong className="text-white">SMS Misr:</strong> أسرع بوابة محلية مرخصة ترسل باسم المنصة (Sender ID: YASMIN GO) وتكلفة الرسالة نحو 0.35 إلى 0.50 قرش.</li>
                <li><strong className="text-white">VictoryLink / Infobip Egypt:</strong> بوابات معتمدة لرسائل OTP البنكية والخدمية.</li>
                <li><strong className="text-white">Firebase Phone Authentication:</strong> تتيح إرسال رسائل OTP مجانية حتى 10,000 رسالة شهرياً مع دعم كامل لأرقام مصر (+20).</li>
              </ul>
            </div>

            {/* Code example */}
            <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-mono text-xs text-emerald-400">
                  نموذج كود خادم Node.js لإرسال رسالة SMS فورية:
                </span>
                <button
                  type="button"
                  onClick={() =>
                    copyText(
`// backend/send-otp.ts
app.post('/api/auth/send-otp', async (req, res) => {
  const { phone } = req.body;
  const otpCode = Math.floor(100000 + Math.random() * 900000);
  
  // حفظ الرمز في قاعدة البيانات أو الكاش لمدة 5 دقائق
  await db.otps.create({ phone, code: otpCode, expiresAt: Date.now() + 300000 });

  // إرسال عبر بوابة SMS Misr
  await fetch('https://smsmisr.com/api/v2/', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      environment: 1,
      username: process.env.SMS_USERNAME,
      password: process.env.SMS_PASSWORD,
      sender: 'YASMIN GO',
      mobile: phone,
      message: \`كود تفعيل حسابك في تطبيق الياسمين جو هو: \${otpCode}\`
    })
  });

  res.json({ success: true, message: 'تم إرسال كود التحقق بنجاح' });
});`,
                      'sms_code'
                    )
                  }
                  className="text-xs text-sky-400 hover:text-white flex items-center gap-1 cursor-pointer font-bold"
                >
                  {copiedKey === 'sms_code' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedKey === 'sms_code' ? 'تم النسخ' : 'نسخ الكود'}</span>
                </button>
              </div>

              <pre className="p-3 bg-slate-900 rounded-xl text-[11px] font-mono text-slate-300 overflow-x-auto text-left" dir="ltr">
{`app.post('/api/auth/send-otp', async (req, res) => {
  const { phone } = req.body;
  const otpCode = Math.floor(100000 + Math.random() * 900000);

  // إرسال عبر بوابة SMS Misr
  await fetch('https://smsmisr.com/api/v2/', {
    method: 'POST',
    body: JSON.stringify({
      username: process.env.SMS_USERNAME,
      password: process.env.SMS_PASSWORD,
      sender: 'YASMIN GO',
      mobile: phone,
      message: \`كود تفعيل حسابك في الياسمين جو هو: \${otpCode}\`
    })
  });
  res.json({ success: true });
});`}
              </pre>
            </div>
          </div>
        </div>
      )}

      {/* =====================================================================
          TAB 3: ARCHITECTURE & INDRIVE BIDDING FLOW
         ===================================================================== */}
      {activeTab === 'architecture' && (
        <div className="bg-slate-900 border border-sky-500/25 rounded-3xl p-6 sm:p-8 space-y-6 shadow-xl">
          <div className="border-b border-slate-800 pb-4">
            <h3 className="text-lg font-black text-white">
              معمارية دورة العمل ونظام المزايدة الحرة (inDrive Model)
            </h3>
          </div>

          <div className="space-y-4 text-xs text-slate-300 leading-relaxed">
            <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
              <span className="font-bold text-amber-300 text-sm block">١. طلب العميل واقتراح السعر:</span>
              العميل يحدد موقعه وجهته أو تفاصيل العطل، ويقترح السعر المناسب له (مثلاً 180 جنيه)، ويختار طريقة الدفع (كاش أو إنستاباي).
            </div>

            <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
              <span className="font-bold text-sky-300 text-sm block">٢. بث الطلب لرادار الكباتن والفنيين:</span>
              يظهر الطلب فورياً في رادار جميع السائقين وأصحاب الأوناش المتواجدين في المحيط الجغرافي، مع إمكانية تقديم عروض مضادة (Counter Bids).
            </div>

            <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
              <span className="font-bold text-emerald-300 text-sm block">٣. موافقة العميل وتتبع الـ GPS:</span>
              يختار العميل الكابتن الأنسب حسب السعر، التقييم، ونوع السيارة، ويتحول الطلب إلى شاشة التتبع المباشر والتواصل عبر الهاتف والدردشة.
            </div>

            <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
              <span className="font-bold text-purple-300 text-sm block">٤. سداد عمولة المنصة للمالك:</span>
              تُسجل عمولة المنصة المحددة (مثلاً 10%) في محفظة الكابتن، ويقوم بسدادها دورياً لحساب المالك على InstaPay أو فودافون كاش المسجل في لوحة التحكم.
            </div>
          </div>
        </div>
      )}

      {/* =====================================================================
          TAB 4: DATABASE SCHEMA & SYNC
         ===================================================================== */}
      {activeTab === 'database' && (
        <div className="bg-slate-900 border border-sky-500/25 rounded-3xl p-6 sm:p-8 space-y-6 shadow-xl">
          <div className="border-b border-slate-800 pb-4">
            <h3 className="text-lg font-black text-white">
              هيكل قاعدة البيانات الحقيقية والمزامنة اللحظية
            </h3>
          </div>

          <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 font-mono text-[11px] text-slate-300 space-y-2 text-left" dir="ltr">
            <div className="text-amber-400 font-bold">// PostgreSQL / Firestore Collections Schema:</div>
            <div>• <strong className="text-white">users:</strong> id, name, phone, role (customer/driver/winch/mechanic), isVerified, otpCode</div>
            <div>• <strong className="text-white">orders:</strong> id, orderCode, customerId, type (ride/breakdown/winch), pickup, dropoff, suggestedFare, status</div>
            <div>• <strong className="text-white">offers:</strong> id, orderId, providerId, quotePrice, etaMinutes, note, status</div>
            <div>• <strong className="text-white">receiving_accounts:</strong> id, type (instapay/vodafone), identifier, holderName, isDefault, isActive</div>
            <div>• <strong className="text-white">platform_pricing:</strong> ridePercent, winchPercent, breakdownPercent, baseFare, perKmRate</div>
            <div>• <strong className="text-white">sub_admins:</strong> id, name, email, role, permissions</div>
          </div>
        </div>
      )}
    </div>
  );
};
