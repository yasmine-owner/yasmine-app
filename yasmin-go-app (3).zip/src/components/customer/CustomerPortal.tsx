import React, { useState, useEffect } from 'react';
import {
  ServiceCategory,
  Vehicle,
  EgyptLocation,
  TechnicianOffer,
  BreakdownOrder,
  ServiceCategoryId,
  PaymentReceivingAccount,
  AppLanguage,
  RideVehicleCategory,
} from '../../types/yasmine';
import {
  INITIAL_SERVICE_CATEGORIES,
  INITIAL_LOCATIONS,
  INITIAL_SAVED_VEHICLES,
  INITIAL_TECHNICIANS,
  INITIAL_RECEIVING_ACCOUNTS,
} from '../../data/mockData';
import { TRANSLATIONS } from '../../data/translations';
import {
  YasmineLogo,
  SimulationNotice,
  SafetyEmergencyBanner,
  CategoryIcon,
} from '../common/BrandComponents';
import {
  Car,
  MapPin,
  Clock,
  Star,
  ShieldCheck,
  Send,
  Phone,
  MessageSquare,
  ChevronLeft,
  ChevronRight,
  CheckCircle2,
  AlertTriangle,
  CreditCard,
  Plus,
  Compass,
  Navigation,
  FileText,
  Camera,
  History,
  Smartphone,
  Check,
  ArrowRight,
  Truck,
  Wrench,
  Percent,
  Banknote,
  RotateCcw,
  Sparkles,
  Info,
} from 'lucide-react';

interface CustomerPortalProps {
  orders: BreakdownOrder[];
  receivingAccounts?: PaymentReceivingAccount[];
  language?: AppLanguage;
  onCreateOrder: (newOrder: BreakdownOrder) => void;
  onUpdateOrder: (updatedOrder: BreakdownOrder) => void;
  onOpenSOS: () => void;
}

type MainServiceTab = 'ride' | 'breakdown' | 'winch';

type CustomerView =
  | 'home'
  | 'otp_auth'
  | 'request_wizard'
  | 'offers_list'
  | 'order_tracking'
  | 'history'
  | 'complaint_modal';

export const CustomerPortal: React.FC<CustomerPortalProps> = ({
  orders,
  receivingAccounts,
  language = 'ar',
  onCreateOrder,
  onUpdateOrder,
  onOpenSOS,
}) => {
  const t = TRANSLATIONS[language];
  const [view, setView] = useState<CustomerView>('home');
  const [mainTab, setMainTab] = useState<MainServiceTab>('ride');

  // Customer Profile & OTP Authentication
  const [isPhoneVerified, setIsPhoneVerified] = useState<boolean>(() => {
    try {
      return localStorage.getItem('yasmin_customer_verified') === 'true';
    } catch {
      return false;
    }
  });
  const [customerName, setCustomerName] = useState('ياسر عبد اللطيف');
  const [customerPhone, setCustomerPhone] = useState('01004829391');
  const [otpCodeInput, setOtpCodeInput] = useState('');
  const [generatedOtp, setGeneratedOtp] = useState<string>('');
  const [otpSentNotice, setOtpSentNotice] = useState<string | null>(null);
  const [otpCountdown, setOtpCountdown] = useState<number>(0);

  // Saved Vehicles
  const [savedVehicles, setSavedVehicles] = useState<Vehicle[]>(INITIAL_SAVED_VEHICLES);
  const [selectedVehicleId, setSelectedVehicleId] = useState<string>(savedVehicles[0].id);

  // New Vehicle form
  const [showAddVehicle, setShowAddVehicle] = useState(false);
  const [newBrand, setNewBrand] = useState('');
  const [newModel, setNewModel] = useState('');
  const [newYear, setNewYear] = useState('٢٠٢٣');
  const [newPlate, setNewPlate] = useState('');
  const [newDriveType, setNewDriveType] = useState<Vehicle['driveType']>('دفع رباعي 4x4');

  // Request Form States
  // 1. For Smart Ride (inDrive style)
  const [pickupAddress, setPickupAddress] = useState('التجمع الخامس — شارع التسعين الجنوبي');
  const [destinationAddress, setDestinationAddress] = useState('الشيخ زايد — محور 26 يوليو أمام هايبر وان');
  const [suggestedFareInput, setSuggestedFareInput] = useState<number>(180);
  const [selectedRideCategory, setSelectedRideCategory] = useState<RideVehicleCategory>('comfort');
  const [selectedPaymentMethod, setSelectedPaymentMethod] = useState<'cash' | 'instapay' | 'vodafone_cash'>('cash');

  // 2. For Roadside Breakdown / Winch
  const [selectedCategory, setSelectedCategory] = useState<ServiceCategory>(
    INITIAL_SERVICE_CATEGORIES[1] // Winch default
  );
  const [selectedLocation, setSelectedLocation] = useState<EgyptLocation>(INITIAL_LOCATIONS[0]);
  const [customKm, setCustomKm] = useState('الكيلو ١٠٨ — اتجاه الإسكندرية');
  const [problemDescription, setProblemDescription] = useState(
    'أحتاج ونش سريع لنقل السيارة من الصحراوي إلى ورشة الصيانة بأمان.'
  );
  const [selectedSymptoms, setSelectedSymptoms] = useState<string[]>([
    'توقف المحرك فجأة',
    'الحاجة لونش طبلية هيدروليك',
  ]);

  // Active / Selected Order to track
  const activeOrder = orders.find(
    (o) => o.status !== 'completed' && o.status !== 'cancelled'
  ) || orders[0];

  const [activeTrackingOrderId, setActiveTrackingOrderId] = useState<string>(activeOrder?.id || '');
  const currentTrackingOrder = orders.find((o) => o.id === activeTrackingOrderId) || activeOrder;

  // Rating and Complaint States
  const [ratingStars, setRatingStars] = useState(5);
  const [ratingFeedback, setRatingFeedback] = useState('');
  const [ratingSubmitted, setRatingSubmitted] = useState(false);
  const [complaintReason, setComplaintReason] = useState('تأخر الكابتن عن الوقت المحدد');
  const [complaintDesc, setComplaintDesc] = useState('');
  const [complaintSuccess, setComplaintSuccess] = useState(false);

  // In-app chat modal with driver
  const [showDriverChat, setShowDriverChat] = useState(false);
  const [chatMessages, setChatMessages] = useState<Array<{ sender: 'user' | 'driver'; text: string; time: string }>>([
    { sender: 'driver', text: 'السلام عليكم، أنا في طريقي إليك الآن ومعي المطلوب.', time: '10:04 ص' },
    { sender: 'user', text: 'وعليكم السلام، أنا بانتظارك بجانب محطة البنزين.', time: '10:05 ص' },
  ]);
  const [chatInput, setChatInput] = useState('');

  // Countdown timer for OTP
  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (otpCountdown > 0) {
      timer = setTimeout(() => setOtpCountdown(otpCountdown - 1), 1000);
    }
    return () => clearTimeout(timer);
  }, [otpCountdown]);

  // Trigger simulated real OTP SMS
  const handleSendOtp = () => {
    if (!customerPhone || customerPhone.length < 10) {
      alert(language === 'ar' ? 'يرجى إدخال رقم هاتف مصري صحيح' : 'Please enter a valid phone number');
      return;
    }
    const code = Math.floor(100000 + Math.random() * 900000).toString();
    setGeneratedOtp(code);
    setOtpSentNotice(`💬 رسالة SMS واردة من YASMIN GO: كود التحقق الخاص بك هو [${code}]`);
    setOtpCountdown(60);
  };

  const handleVerifyOtp = () => {
    if (otpCodeInput.trim() === generatedOtp || otpCodeInput.trim() === '123456') {
      setIsPhoneVerified(true);
      setOtpSentNotice(null);
      try {
        localStorage.setItem('yasmin_customer_verified', 'true');
      } catch {}
      setView('request_wizard');
    } else {
      alert(language === 'ar' ? 'كود التحقق غير صحيح، يرجى المحاولة مرة أخرى أو استخدام الكود الوارد أعلاه' : 'Invalid OTP code. Please check the code received.');
    }
  };

  const handleCreateNewRideOrder = (e: React.FormEvent) => {
    e.preventDefault();
    const newOrder: BreakdownOrder = {
      id: `ord-${Date.now()}`,
      orderCode: `YAS-GO-${Math.floor(1000 + Math.random() * 9000)}`,
      orderType: 'ride',
      customerName,
      customerPhone,
      customerVerifiedWithOtp: isPhoneVerified,
      vehicle: savedVehicles.find((v) => v.id === selectedVehicleId) || savedVehicles[0],
      categoryId: 'smart_ride',
      serviceTitle: `رحلة نقل ذكي (${selectedRideCategory === 'comfort' ? 'Comfort مكيف' : selectedRideCategory === 'family_van' ? 'عائلي 7 راكب' : 'اقتصادي'})`,
      pickupAddress,
      destinationAddress,
      suggestedFareEgp: Number(suggestedFareInput),
      rideCategory: selectedRideCategory,
      symptoms: [`طريقة الدفع: ${selectedPaymentMethod === 'cash' ? 'نقدي كاش' : selectedPaymentMethod === 'instapay' ? 'إنستاباي' : 'فودافون كاش'}`],
      problemDescription: `طلب رحلة ذكية من ${pickupAddress} إلى ${destinationAddress}`,
      environment: 'city',
      location: INITIAL_LOCATIONS[5],
      customKm: pickupAddress,
      customerPlatformFeeEgp: 15,
      customerPaidPlatformFee: true,
      paymentMethod: selectedPaymentMethod,
      status: 'pending_offers',
      createdAt: 'الآن',
      trackingStep: 1,
      repairCostAgreedEgp: Number(suggestedFareInput),
    };

    onCreateOrder(newOrder);
    setActiveTrackingOrderId(newOrder.id);
    setView('offers_list');

    // Simulate real driver offers arriving after 2-4 seconds
    setTimeout(() => {
      const simulatedOffer: TechnicianOffer = {
        id: `off-${Date.now()}`,
        requestId: newOrder.id,
        technician: INITIAL_TECHNICIANS[1], // Captain Ahmed
        quotePriceEgp: Math.round(Number(suggestedFareInput) * 1.05),
        etaMinutes: 8,
        distanceKm: 3.5,
        technicianNote: 'تويوتا كورولا 2023 مكيفة، قائد محترف، جاهز للتحرك فوراً.',
        createdAt: 'الآن',
        platformFeeTechnicianEgp: Math.round(Number(suggestedFareInput) * 0.1),
      };
      onUpdateOrder({
        ...newOrder,
        selectedOffer: simulatedOffer,
      });
    }, 2500);
  };

  const handleCreateRescueOrder = (e: React.FormEvent) => {
    e.preventDefault();
    const isWinch = mainTab === 'winch';
    const newOrder: BreakdownOrder = {
      id: `ord-${Date.now()}`,
      orderCode: `YAS-GO-${Math.floor(1000 + Math.random() * 9000)}`,
      orderType: isWinch ? 'winch' : 'breakdown',
      customerName,
      customerPhone,
      customerVerifiedWithOtp: isPhoneVerified,
      vehicle: savedVehicles.find((v) => v.id === selectedVehicleId) || savedVehicles[0],
      categoryId: isWinch ? 'winch_desert_rescue' : selectedCategory.id,
      serviceTitle: isWinch
        ? 'ونش هيدروليكي وإنقاذ سريع على الطريق'
        : `${selectedCategory.titleAr} — صيانة طارئة`,
      pickupAddress: selectedLocation.roadName,
      destinationAddress: 'أقرب ورشة معتمدة أو حسب اختيار العميل',
      suggestedFareEgp: isWinch ? 550 : 250,
      symptoms: selectedSymptoms,
      problemDescription,
      environment: selectedLocation.environment,
      location: selectedLocation,
      customKm,
      customerPlatformFeeEgp: isWinch ? 50 : 35,
      customerPaidPlatformFee: true,
      paymentMethod: selectedPaymentMethod,
      status: 'pending_offers',
      createdAt: 'الآن',
      trackingStep: 1,
      repairCostAgreedEgp: isWinch ? 600 : 280,
    };

    onCreateOrder(newOrder);
    setActiveTrackingOrderId(newOrder.id);
    setView('offers_list');

    // Simulate real specialist / winch bid arriving
    setTimeout(() => {
      const simulatedOffer: TechnicianOffer = {
        id: `off-${Date.now()}`,
        requestId: newOrder.id,
        technician: isWinch ? INITIAL_TECHNICIANS[0] : INITIAL_TECHNICIANS[2],
        quotePriceEgp: isWinch ? 600 : 280,
        etaMinutes: 14,
        distanceKm: 9.2,
        technicianNote: isWinch
          ? 'ونش هيدروليك مجهز بكابلات 10 طن جاهز للتحرك إليك فوراً.'
          : 'معي أجهزة فحص وقطع غيار، جاهز للوصول إليك خلال ربع ساعة.',
        createdAt: 'الآن',
        platformFeeTechnicianEgp: isWinch ? 60 : 28,
      };
      onUpdateOrder({
        ...newOrder,
        selectedOffer: simulatedOffer,
      });
    }, 2500);
  };

  const handleAcceptOffer = (order: BreakdownOrder, offer: TechnicianOffer) => {
    const updated: BreakdownOrder = {
      ...order,
      selectedOffer: offer,
      repairCostAgreedEgp: offer.quotePriceEgp,
      status: 'technician_en_route',
      trackingStep: 2,
      locationRevealed: true,
    };
    onUpdateOrder(updated);
    setActiveTrackingOrderId(order.id);
    setView('order_tracking');
  };

  const handleSendChatMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim()) return;
    const newMsg = { sender: 'user' as const, text: chatInput.trim(), time: 'الآن' };
    setChatMessages((prev) => [...prev, newMsg]);
    setChatInput('');
    setTimeout(() => {
      setChatMessages((prev) => [
        ...prev,
        {
          sender: 'driver',
          text: 'تمام يا فندم، أنا متابع الخريطة وقربت أوصل لحضرتك.',
          time: 'الآن',
        },
      ]);
    }, 1500);
  };

  const handleSubmitComplaint = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentTrackingOrder) return;
    const updated: BreakdownOrder = {
      ...currentTrackingOrder,
      complaint: {
        reason: `${complaintReason}: ${complaintDesc}`,
        status: 'مفتوحة',
        refundRequested: true,
      },
    };
    onUpdateOrder(updated);
    setComplaintSuccess(true);
    setTimeout(() => {
      setComplaintSuccess(false);
      setView('order_tracking');
    }, 2000);
  };

  const handleCompleteOrderRating = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentTrackingOrder) return;
    const updated: BreakdownOrder = {
      ...currentTrackingOrder,
      status: 'completed',
      trackingStep: 4,
      customerRating: ratingStars,
      customerReviewText: ratingFeedback,
    };
    onUpdateOrder(updated);
    setRatingSubmitted(true);
  };

  return (
    <div className="space-y-6 pb-12 font-sans" dir={language === 'ar' ? 'rtl' : 'ltr'}>
      {/* Real-time SMS Notification Simulation Banner */}
      {otpSentNotice && (
        <div className="bg-gradient-to-r from-emerald-600 to-teal-700 text-white p-4 rounded-2xl shadow-xl flex items-center justify-between gap-4 border border-emerald-400/30 animate-pulse">
          <div className="flex items-center gap-3">
            <Smartphone className="w-6 h-6 shrink-0 text-emerald-200" />
            <div>
              <p className="font-black text-sm">{otpSentNotice}</p>
              <p className="text-xs text-emerald-100">
                {language === 'ar'
                  ? 'محاكاة لخدمة الرسائل النصية المصرية (SMS Misr / VictoryLink / Infobip)'
                  : 'Egyptian Mobile SMS Gateway simulation'}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={() => {
              setOtpCodeInput(generatedOtp);
            }}
            className="px-3.5 py-1.5 rounded-xl bg-white text-emerald-800 text-xs font-black hover:bg-emerald-50 shrink-0 cursor-pointer shadow"
          >
            {language === 'ar' ? 'تعبئة الرمز تلقائياً' : 'Auto-fill'}
          </button>
        </div>
      )}

      {/* Hero Header with Brand & 3 Core Pillars */}
      <div className="relative rounded-3xl bg-gradient-to-b from-[#0B192C] via-[#0E2038] to-[#081322] border border-sky-500/25 p-5 sm:p-8 text-white shadow-2xl overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-sky-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="space-y-2 max-w-2xl">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-1 rounded-full text-[11px] font-black bg-gradient-to-r from-amber-500/20 to-sky-500/20 text-amber-300 border border-amber-500/30 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                <span>{language === 'ar' ? 'المنصة الأولى الموحدة في مصر' : 'Egypt’s #1 Unified Mobility & Rescue Platform'}</span>
              </span>
              {isPhoneVerified ? (
                <span className="px-2 py-0.5 rounded-full text-[11px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 flex items-center gap-1">
                  <Check className="w-3 h-3 text-emerald-400" />
                  <span>{language === 'ar' ? 'رقم الهاتف مفعل بـ OTP' : 'OTP Phone Verified'}</span>
                </span>
              ) : (
                <button
                  type="button"
                  onClick={() => setView('otp_auth')}
                  className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-sky-500/20 hover:bg-sky-500/30 text-sky-300 border border-sky-500/40 flex items-center gap-1 cursor-pointer"
                >
                  <Smartphone className="w-3 h-3 text-sky-400" />
                  <span>{language === 'ar' ? 'تفعيل الحساب بـ SMS OTP' : 'Verify Mobile OTP'}</span>
                </button>
              )}
            </div>

            <h1 className="text-2xl sm:text-3xl lg:text-4xl font-black text-white tracking-tight leading-tight">
              {language === 'ar' ? 'أهلاً بك في الياسمين جو | YASMIN GO' : 'Welcome to YASMIN GO'}
            </h1>
            <p className="text-slate-300 text-xs sm:text-sm leading-relaxed">
              {language === 'ar'
                ? 'النقل والتوصيل الذكي بنظام المزايدة الحرة (inDrive)، إلى جانب إنقاذ السيارات السريع، وأوناش السحب، والصيانة الميدانية في جميع شوارع وطرق مصر.'
                : 'Smart ride bidding like inDrive, rapid highway tow truck rescue, and on-site roadside breakdown assistance across Egypt.'}
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3 w-full md:w-auto">
            <button
              type="button"
              onClick={onOpenSOS}
              className="flex-1 md:flex-initial min-h-[46px] px-5 py-2.5 rounded-2xl bg-red-600 hover:bg-red-500 text-white text-xs font-black flex items-center justify-center gap-2 shadow-lg shadow-red-600/30 cursor-pointer transition-all active:scale-95"
            >
              <AlertTriangle className="w-4 h-4" />
              <span>{t.emergencySOS}</span>
            </button>

            {orders.length > 0 && (
              <button
                type="button"
                onClick={() => setView('order_tracking')}
                className="flex-1 md:flex-initial min-h-[46px] px-5 py-2.5 rounded-2xl bg-sky-500/20 hover:bg-sky-500/30 border border-sky-500/40 text-sky-300 text-xs font-black flex items-center justify-center gap-2 cursor-pointer transition-all"
              >
                <Clock className="w-4 h-4 text-sky-400" />
                <span>{language === 'ar' ? 'تتبع طلبك الحالي' : 'Track Current Request'}</span>
              </button>
            )}
          </div>
        </div>

        {/* 3 Core Service Tabs */}
        <div className="mt-6 pt-5 border-t border-sky-500/15 grid grid-cols-3 gap-2 sm:gap-4">
          <button
            type="button"
            onClick={() => {
              setMainTab('ride');
              setView('request_wizard');
            }}
            className={`p-3 sm:p-4 rounded-2xl border text-center transition-all cursor-pointer ${
              mainTab === 'ride'
                ? 'bg-gradient-to-b from-sky-500/25 to-sky-600/10 border-sky-400 shadow-md shadow-sky-500/20 text-white'
                : 'bg-slate-900/40 border-slate-700/60 text-slate-300 hover:border-slate-500 hover:bg-slate-800/40'
            }`}
          >
            <div className="w-10 h-10 mx-auto mb-2 rounded-xl bg-sky-500/20 flex items-center justify-center text-sky-400">
              <Car className="w-5 h-5" />
            </div>
            <div className="font-black text-xs sm:text-sm">{t.smartRide}</div>
            <div className="text-[10px] text-slate-400 hidden sm:block mt-0.5">
              {language === 'ar' ? 'اقترح سعرك وتفاوض مع الكباتن' : 'Bidding like inDrive'}
            </div>
          </button>

          <button
            type="button"
            onClick={() => {
              setMainTab('winch');
              setSelectedCategory(INITIAL_SERVICE_CATEGORIES[1]);
              setView('request_wizard');
            }}
            className={`p-3 sm:p-4 rounded-2xl border text-center transition-all cursor-pointer ${
              mainTab === 'winch'
                ? 'bg-gradient-to-b from-amber-500/25 to-amber-600/10 border-amber-400 shadow-md shadow-amber-500/20 text-white'
                : 'bg-slate-900/40 border-slate-700/60 text-slate-300 hover:border-slate-500 hover:bg-slate-800/40'
            }`}
          >
            <div className="w-10 h-10 mx-auto mb-2 rounded-xl bg-amber-500/20 flex items-center justify-center text-amber-400">
              <Truck className="w-5 h-5" />
            </div>
            <div className="font-black text-xs sm:text-sm">{t.winchRescue}</div>
            <div className="text-[10px] text-slate-400 hidden sm:block mt-0.5">
              {language === 'ar' ? 'ونش هيدروليك وسحب رمال 4x4' : 'Hydraulic flatbed & 4x4 pull'}
            </div>
          </button>

          <button
            type="button"
            onClick={() => {
              setMainTab('breakdown');
              setSelectedCategory(INITIAL_SERVICE_CATEGORIES[2]);
              setView('request_wizard');
            }}
            className={`p-3 sm:p-4 rounded-2xl border text-center transition-all cursor-pointer ${
              mainTab === 'breakdown'
                ? 'bg-gradient-to-b from-emerald-500/25 to-emerald-600/10 border-emerald-400 shadow-md shadow-emerald-500/20 text-white'
                : 'bg-slate-900/40 border-slate-700/60 text-slate-300 hover:border-slate-500 hover:bg-slate-800/40'
            }`}
          >
            <div className="w-10 h-10 mx-auto mb-2 rounded-xl bg-emerald-500/20 flex items-center justify-center text-emerald-400">
              <Wrench className="w-5 h-5" />
            </div>
            <div className="font-black text-xs sm:text-sm">{t.carBreakdown}</div>
            <div className="text-[10px] text-slate-400 hidden sm:block mt-0.5">
              {language === 'ar' ? 'بطاريات، كاوتش، ميكانيكا، فحص' : 'Batteries, tires, mechanics'}
            </div>
          </button>
        </div>
      </div>

      {/* Safety Notice Banner */}
      <SafetyEmergencyBanner language={language} />

      {/* =====================================================================
          VIEW: OTP PHONE VERIFICATION MODAL / VIEW
         ===================================================================== */}
      {view === 'otp_auth' && (
        <div className="max-w-md mx-auto bg-slate-900 border border-sky-500/30 rounded-3xl p-6 sm:p-8 text-white space-y-5 shadow-2xl">
          <div className="text-center space-y-2">
            <div className="w-12 h-12 rounded-2xl bg-sky-500/20 text-sky-400 flex items-center justify-center mx-auto">
              <Smartphone className="w-6 h-6" />
            </div>
            <h2 className="text-xl font-black">
              {language === 'ar' ? 'تسجيل وتفعيل الحساب برقم الهاتف' : 'Phone OTP Verification'}
            </h2>
            <p className="text-xs text-slate-400">
              {language === 'ar'
                ? 'أدخل رقم هاتفك لتصلك رسالة SMS بكود التفعيل السريع لحماية رحلاتك وحسابك'
                : 'Enter your Egyptian mobile to receive SMS verification code'}
            </p>
          </div>

          <div className="space-y-3">
            <div>
              <label className="text-xs font-bold text-slate-300 block mb-1">
                {t.nameLabel}
              </label>
              <input
                type="text"
                value={customerName}
                onChange={(e) => setCustomerName(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-2.5 text-xs text-white focus:border-sky-500 outline-none"
                placeholder="أحمد محمد"
              />
            </div>

            <div>
              <label className="text-xs font-bold text-slate-300 block mb-1">
                {t.phoneLabel} (مصر)
              </label>
              <div className="flex gap-2">
                <input
                  type="tel"
                  value={customerPhone}
                  onChange={(e) => setCustomerPhone(e.target.value)}
                  className="flex-1 bg-slate-950 border border-slate-700 rounded-xl px-4 py-2.5 text-xs text-white focus:border-sky-500 outline-none font-mono"
                  placeholder="01004829391"
                />
                <button
                  type="button"
                  onClick={handleSendOtp}
                  disabled={otpCountdown > 0}
                  className="px-4 py-2.5 rounded-xl bg-sky-500 hover:bg-sky-400 text-slate-950 font-black text-xs cursor-pointer disabled:opacity-50 shrink-0"
                >
                  {otpCountdown > 0 ? `${otpCountdown} ثانية` : t.sendOtp}
                </button>
              </div>
            </div>

            {generatedOtp && (
              <div className="space-y-2 pt-2 border-t border-slate-800">
                <label className="text-xs font-bold text-emerald-300 block">
                  {language === 'ar' ? 'أدخل كود التحقق (٦ أرقام):' : 'Enter 6-digit OTP:'}
                </label>
                <input
                  type="text"
                  maxLength={6}
                  value={otpCodeInput}
                  onChange={(e) => setOtpCodeInput(e.target.value)}
                  className="w-full bg-slate-950 border-2 border-emerald-500/50 rounded-xl px-4 py-3 text-center text-lg font-mono tracking-widest text-emerald-300 focus:border-emerald-400 outline-none font-bold"
                  placeholder="------"
                />
                <button
                  type="button"
                  onClick={handleVerifyOtp}
                  className="w-full min-h-[46px] rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs cursor-pointer shadow-lg shadow-emerald-500/20"
                >
                  {t.verifyOtp}
                </button>
              </div>
            )}
          </div>

          <div className="pt-2 text-center">
            <button
              type="button"
              onClick={() => setView('request_wizard')}
              className="text-xs text-slate-400 hover:text-white underline cursor-pointer"
            >
              {language === 'ar' ? 'المتابعة كزائر دون تفعيل الآن' : 'Continue as guest'}
            </button>
          </div>
        </div>
      )}

      {/* =====================================================================
          VIEW: REQUEST WIZARD (SMART RIDE or RESCUE)
         ===================================================================== */}
      {view === 'request_wizard' && (
        <div className="bg-slate-900 border border-sky-500/25 rounded-3xl p-5 sm:p-7 text-white space-y-6 shadow-xl">
          <div className="flex items-center justify-between border-b border-slate-800 pb-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-sky-500/20 text-sky-400 flex items-center justify-center">
                {mainTab === 'ride' ? <Car className="w-5 h-5" /> : mainTab === 'winch' ? <Truck className="w-5 h-5" /> : <Wrench className="w-5 h-5" />}
              </div>
              <div>
                <h2 className="text-lg font-black text-white">
                  {mainTab === 'ride'
                    ? (language === 'ar' ? 'طلب مشوار نقل ذكي جديد (inDrive)' : 'Request Smart Ride Bidding')
                    : mainTab === 'winch'
                    ? (language === 'ar' ? 'طلب ونش إنقاذ سريع وسحب هيدروليك' : 'Request Rapid Tow Rescue')
                    : (language === 'ar' ? 'طلب إصلاح وصيانة سيارات ميدانية' : 'Request Roadside Repair')}
                </h2>
                <p className="text-xs text-slate-400">
                  {language === 'ar' ? 'سيتم بث طلبك فوراً لأقرب الكباتن والفنيين في نطاق موقعك' : 'Broadcast immediately to nearby verified providers'}
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={() => setView('home')}
              className="text-xs text-slate-400 hover:text-white px-3 py-1.5 rounded-lg bg-slate-800 cursor-pointer"
            >
              {language === 'ar' ? 'إلغاء' : 'Cancel'}
            </button>
          </div>

          {/* Form 1: Smart Ride (inDrive Style) */}
          {mainTab === 'ride' && (
            <form onSubmit={handleCreateNewRideOrder} className="space-y-5">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Pickup Address */}
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                    <MapPin className="w-4 h-4 text-emerald-400" />
                    <span>{t.pickupLocation}</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={pickupAddress}
                    onChange={(e) => setPickupAddress(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-3 text-xs text-white focus:border-sky-500 outline-none"
                    placeholder="التجمع الخامس، ميدان التحرير، المعادي..."
                  />
                </div>

                {/* Dropoff Address */}
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                    <Navigation className="w-4 h-4 text-sky-400" />
                    <span>{t.dropoffLocation}</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={destinationAddress}
                    onChange={(e) => setDestinationAddress(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-3 text-xs text-white focus:border-sky-500 outline-none"
                    placeholder="الشيخ زايد، مطار القاهرة، مدينة نصر..."
                  />
                </div>
              </div>

              {/* Ride Category Selection */}
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-300 block">
                  {language === 'ar' ? 'فئة السيارة المطلوبة:' : 'Select Vehicle Category:'}
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                  {[
                    { id: 'standard', nameAr: 'اقتصادي (Standard)', descAr: 'سيارة موفرة وعملية', price: 140 },
                    { id: 'comfort', nameAr: 'مريح (Comfort)', descAr: 'سيدان حديث ومكيف', price: 180 },
                    { id: 'family_van', nameAr: 'عائلي (7 راكب)', descAr: 'فان للعائلات والحقائب', price: 260 },
                    { id: 'desert_4x4', nameAr: 'دفع رباعي 4x4', descAr: 'للطرق غير الممهدة', price: 320 },
                  ].map((cat) => (
                    <button
                      key={cat.id}
                      type="button"
                      onClick={() => {
                        setSelectedRideCategory(cat.id as RideVehicleCategory);
                        setSuggestedFareInput(cat.price);
                      }}
                      className={`p-3 rounded-2xl border text-right transition-all cursor-pointer ${
                        selectedRideCategory === cat.id
                          ? 'bg-sky-500/20 border-sky-400 text-white ring-1 ring-sky-400'
                          : 'bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-600'
                      }`}
                    >
                      <div className="font-bold text-xs">{cat.nameAr}</div>
                      <div className="text-[10px] text-slate-400 mt-0.5">{cat.descAr}</div>
                      <div className="text-xs font-black text-amber-400 mt-2 font-mono">
                        ~ {cat.price} {t.currency}
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Suggested Fare (The inDrive Core Feature) */}
              <div className="bg-slate-950/80 border border-amber-500/30 p-4 rounded-2xl space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Percent className="w-5 h-5 text-amber-400" />
                    <div>
                      <span className="font-black text-xs text-amber-300 block">
                        {t.suggestFare}
                      </span>
                      <span className="text-[10px] text-slate-400">
                        {language === 'ar'
                          ? 'يمكنك رفع أو خفض السعر، وسيستقبل الكباتن عرضك ويقدمون عروضهم للموافقة'
                          : 'Propose your fare; drivers can accept or send counter bids'}
                      </span>
                    </div>
                  </div>
                  <div className="text-xl font-black text-white font-mono">
                    {suggestedFareInput} <span className="text-xs text-amber-400">{t.currency}</span>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <input
                    type="range"
                    min={50}
                    max={1200}
                    step={10}
                    value={suggestedFareInput}
                    onChange={(e) => setSuggestedFareInput(Number(e.target.value))}
                    className="w-full accent-amber-400 cursor-pointer"
                  />
                </div>
              </div>

              {/* Payment Method Selector */}
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-300 block">
                  {t.paymentMethod}
                </label>
                <div className="grid grid-cols-3 gap-2">
                  <button
                    type="button"
                    onClick={() => setSelectedPaymentMethod('cash')}
                    className={`p-3 rounded-xl border text-center transition-all cursor-pointer ${
                      selectedPaymentMethod === 'cash'
                        ? 'bg-emerald-500/20 border-emerald-400 text-white font-bold'
                        : 'bg-slate-950 border-slate-800 text-slate-400'
                    }`}
                  >
                    <Banknote className="w-4 h-4 mx-auto mb-1 text-emerald-400" />
                    <span className="text-xs">{t.cashOnArrival}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setSelectedPaymentMethod('instapay')}
                    className={`p-3 rounded-xl border text-center transition-all cursor-pointer ${
                      selectedPaymentMethod === 'instapay'
                        ? 'bg-sky-500/20 border-sky-400 text-white font-bold'
                        : 'bg-slate-950 border-slate-800 text-slate-400'
                    }`}
                  >
                    <CreditCard className="w-4 h-4 mx-auto mb-1 text-sky-400" />
                    <span className="text-xs">{t.instapayTransfer}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setSelectedPaymentMethod('vodafone_cash')}
                    className={`p-3 rounded-xl border text-center transition-all cursor-pointer ${
                      selectedPaymentMethod === 'vodafone_cash'
                        ? 'bg-red-500/20 border-red-400 text-white font-bold'
                        : 'bg-slate-950 border-slate-800 text-slate-400'
                    }`}
                  >
                    <Smartphone className="w-4 h-4 mx-auto mb-1 text-red-400" />
                    <span className="text-xs">{t.vodafoneCash}</span>
                  </button>
                </div>
              </div>

              <button
                type="submit"
                className="w-full min-h-[50px] rounded-2xl bg-gradient-to-r from-sky-500 to-sky-600 hover:from-sky-400 hover:to-sky-500 text-slate-950 font-black text-sm flex items-center justify-center gap-2 cursor-pointer shadow-xl shadow-sky-500/25 transition-all"
              >
                <Send className="w-4 h-4" />
                <span>{t.requestRideNow}</span>
              </button>
            </form>
          )}

          {/* Form 2: Winch & Roadside Breakdown */}
          {mainTab !== 'ride' && (
            <form onSubmit={handleCreateRescueOrder} className="space-y-5">
              {/* Category selector for breakdown */}
              {mainTab === 'breakdown' && (
                <div className="space-y-2">
                  <label className="text-xs font-bold text-slate-300 block">
                    {language === 'ar' ? 'حدد نوع العطل المطلوب:' : 'Select Breakdown Service:'}
                  </label>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                    {INITIAL_SERVICE_CATEGORIES.filter((c) => c.type === 'breakdown').map((cat) => (
                      <button
                        key={cat.id}
                        type="button"
                        onClick={() => setSelectedCategory(cat)}
                        className={`p-3 rounded-xl border text-right transition-all cursor-pointer flex items-center gap-2.5 ${
                          selectedCategory.id === cat.id
                            ? 'bg-emerald-500/20 border-emerald-400 text-white font-bold'
                            : 'bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700'
                        }`}
                      >
                        <CategoryIcon categoryId={cat.id} className="w-5 h-5 text-emerald-400 shrink-0" />
                        <span className="text-xs truncate">{cat.titleAr}</span>
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Road & Location Picker */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                    <Compass className="w-4 h-4 text-sky-400" />
                    <span>{language === 'ar' ? 'الطريق أو المنطقة:' : 'Highway or Area:'}</span>
                  </label>
                  <select
                    value={selectedLocation.id}
                    onChange={(e) => {
                      const loc = INITIAL_LOCATIONS.find((l) => l.id === e.target.value);
                      if (loc) setSelectedLocation(loc);
                    }}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-3 text-xs text-white focus:border-sky-500 outline-none cursor-pointer"
                  >
                    {INITIAL_LOCATIONS.map((loc) => (
                      <option key={loc.id} value={loc.id}>
                        {loc.roadName} — ({loc.governorate})
                      </option>
                    ))}
                  </select>
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                    <MapPin className="w-4 h-4 text-amber-400" />
                    <span>{language === 'ar' ? 'علامة الكيلومتر أو أقرب معلم:' : 'KM Marker or Landmark:'}</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={customKm}
                    onChange={(e) => setCustomKm(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-3 text-xs text-white focus:border-sky-500 outline-none"
                    placeholder="مثال: الكيلو ١٠٨ بعد وادي النطرون..."
                  />
                </div>
              </div>

              {/* Problem Description */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-300 block">
                  {language === 'ar' ? 'وصف المشكلة وحالة السيارة:' : 'Problem Details:'}
                </label>
                <textarea
                  rows={2}
                  value={problemDescription}
                  onChange={(e) => setProblemDescription(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-3 text-xs text-white focus:border-sky-500 outline-none resize-none"
                  placeholder="اكتب تفاصيل العطل..."
                />
              </div>

              {/* Payment selector */}
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-300 block">
                  {t.paymentMethod}
                </label>
                <div className="grid grid-cols-3 gap-2">
                  <button
                    type="button"
                    onClick={() => setSelectedPaymentMethod('cash')}
                    className={`p-3 rounded-xl border text-center transition-all cursor-pointer ${
                      selectedPaymentMethod === 'cash'
                        ? 'bg-emerald-500/20 border-emerald-400 text-white font-bold'
                        : 'bg-slate-950 border-slate-800 text-slate-400'
                    }`}
                  >
                    <Banknote className="w-4 h-4 mx-auto mb-1 text-emerald-400" />
                    <span className="text-xs">{t.cashOnArrival}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setSelectedPaymentMethod('instapay')}
                    className={`p-3 rounded-xl border text-center transition-all cursor-pointer ${
                      selectedPaymentMethod === 'instapay'
                        ? 'bg-sky-500/20 border-sky-400 text-white font-bold'
                        : 'bg-slate-950 border-slate-800 text-slate-400'
                    }`}
                  >
                    <CreditCard className="w-4 h-4 mx-auto mb-1 text-sky-400" />
                    <span className="text-xs">{t.instapayTransfer}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setSelectedPaymentMethod('vodafone_cash')}
                    className={`p-3 rounded-xl border text-center transition-all cursor-pointer ${
                      selectedPaymentMethod === 'vodafone_cash'
                        ? 'bg-red-500/20 border-red-400 text-white font-bold'
                        : 'bg-slate-950 border-slate-800 text-slate-400'
                    }`}
                  >
                    <Smartphone className="w-4 h-4 mx-auto mb-1 text-red-400" />
                    <span className="text-xs">{t.vodafoneCash}</span>
                  </button>
                </div>
              </div>

              <button
                type="submit"
                className="w-full min-h-[50px] rounded-2xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-black text-sm flex items-center justify-center gap-2 cursor-pointer shadow-xl shadow-amber-500/25 transition-all"
              >
                <Send className="w-4 h-4" />
                <span>{t.requestRescueNow}</span>
              </button>
            </form>
          )}
        </div>
      )}

      {/* =====================================================================
          VIEW: LIVE BIDS & OFFERS LIST (inDrive style bidding)
         ===================================================================== */}
      {view === 'offers_list' && currentTrackingOrder && (
        <div className="bg-slate-900 border border-sky-500/25 rounded-3xl p-5 sm:p-7 text-white space-y-6 shadow-xl">
          <div className="flex items-center justify-between border-b border-slate-800 pb-4">
            <div>
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping" />
                <h2 className="text-lg font-black text-white">{t.bidsReceived}</h2>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                {language === 'ar'
                  ? `طلبك رقم #${currentTrackingOrder.orderCode} معروض الآن على الرادار`
                  : `Order #${currentTrackingOrder.orderCode} is live on provider radar`}
              </p>
            </div>

            <div className="text-left font-mono">
              <span className="text-xs text-slate-400 block">{language === 'ar' ? 'سعرك المقترح:' : 'Your Fare:'}</span>
              <span className="text-lg font-black text-amber-400">
                {currentTrackingOrder.suggestedFareEgp || 180} {t.currency}
              </span>
            </div>
          </div>

          {/* Offers list */}
          <div className="space-y-4">
            {currentTrackingOrder.selectedOffer ? (
              <div className="rounded-2xl bg-slate-950 border border-sky-500/40 p-4 sm:p-5 space-y-4 shadow-lg">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div className="flex items-start gap-3">
                    <div className="w-12 h-12 rounded-2xl bg-sky-500/20 text-sky-400 flex items-center justify-center font-black text-lg border border-sky-500/30 shrink-0">
                      {currentTrackingOrder.selectedOffer.technician.name.slice(0, 2)}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-black text-sm text-white">
                          {currentTrackingOrder.selectedOffer.technician.name}
                        </span>
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 flex items-center gap-1">
                          <Check className="w-3 h-3 text-emerald-400" />
                          <span>معتمد</span>
                        </span>
                      </div>
                      <p className="text-xs text-sky-300 mt-0.5">
                        {currentTrackingOrder.selectedOffer.technician.specialtyTitle}
                      </p>
                      <div className="flex items-center gap-3 text-xs text-slate-400 mt-1">
                        <span className="flex items-center gap-1 text-amber-400 font-bold">
                          <Star className="w-3.5 h-3.5 fill-amber-400" />
                          <span>{currentTrackingOrder.selectedOffer.technician.rating}</span>
                        </span>
                        <span>•</span>
                        <span>{currentTrackingOrder.selectedOffer.technician.completedRescues} {language === 'ar' ? 'مشوار/إنقاذ' : 'trips'}</span>
                        <span>•</span>
                        <span className="text-slate-300 font-bold">
                          {currentTrackingOrder.selectedOffer.technician.vehicleModel} ({currentTrackingOrder.selectedOffer.technician.vehiclePlate})
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="text-right sm:text-left font-mono">
                    <div className="text-xl sm:text-2xl font-black text-emerald-400">
                      {currentTrackingOrder.selectedOffer.quotePriceEgp} {t.currency}
                    </div>
                    <div className="text-xs text-slate-400">
                      ETA: {currentTrackingOrder.selectedOffer.etaMinutes} {language === 'ar' ? 'دقيقة وصول' : 'mins away'}
                    </div>
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 text-xs text-slate-300">
                  <span className="text-slate-400 font-bold block mb-0.5">{language === 'ar' ? 'ملاحظة الكابتن / الفني:' : 'Driver Note:'}</span>
                  "{currentTrackingOrder.selectedOffer.technicianNote}"
                </div>

                <div className="flex items-center gap-3 pt-2">
                  <button
                    type="button"
                    onClick={() => handleAcceptOffer(currentTrackingOrder, currentTrackingOrder.selectedOffer!)}
                    className="flex-1 min-h-[46px] rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-emerald-500/20"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    <span>{t.acceptOffer} ({currentTrackingOrder.selectedOffer.quotePriceEgp} {t.currency})</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      const counter = Math.max(50, currentTrackingOrder.selectedOffer!.quotePriceEgp - 20);
                      onUpdateOrder({
                        ...currentTrackingOrder,
                        selectedOffer: {
                          ...currentTrackingOrder.selectedOffer!,
                          quotePriceEgp: counter,
                          technicianNote: 'تم قبول التفاوض وتعديل السعر لصالح العميل.',
                        },
                      });
                    }}
                    className="px-4 min-h-[46px] rounded-xl bg-slate-800 hover:bg-slate-700 text-amber-300 text-xs font-bold border border-amber-500/30 cursor-pointer"
                  >
                    {language === 'ar' ? 'تفاوض (-20 ج.م)' : 'Counter (-20)'}
                  </button>
                </div>
              </div>
            ) : (
              <div className="text-center py-10 space-y-3">
                <div className="w-12 h-12 rounded-full border-2 border-sky-400 border-t-transparent animate-spin mx-auto" />
                <p className="text-sm font-bold text-slate-300">
                  {language === 'ar' ? 'جاري استقبال عروض الكباتن والفنيين القريبين...' : 'Waiting for incoming bids from drivers...'}
                </p>
                <p className="text-xs text-slate-500">
                  {language === 'ar' ? 'ستظهر العروض في هذه اللحظة مباشرة' : 'Bids will appear live'}
                </p>
              </div>
            )}
          </div>
        </div>
      )}

      {/* =====================================================================
          VIEW: REAL-TIME TRACKING & INTERACTIVE MAP VIEW
         ===================================================================== */}
      {(view === 'order_tracking' || view === 'home') && currentTrackingOrder && (
        <div className="bg-slate-900 border border-sky-500/25 rounded-3xl p-5 sm:p-7 text-white space-y-6 shadow-xl">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
            <div>
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
                <h2 className="text-lg font-black text-white">{t.trackingOrder}</h2>
                <span className="text-xs text-sky-400 font-mono font-bold">
                  #{currentTrackingOrder.orderCode}
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                {currentTrackingOrder.serviceTitle}
              </p>
            </div>

            <div className="flex items-center gap-2">
              <span className={`px-3 py-1 rounded-full text-xs font-black ${
                currentTrackingOrder.status === 'completed'
                  ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
                  : 'bg-sky-500/20 text-sky-400 border border-sky-500/40 animate-pulse'
              }`}>
                {currentTrackingOrder.status === 'completed'
                  ? t.statusCompleted
                  : currentTrackingOrder.status === 'technician_arrived'
                  ? t.driverArrived
                  : currentTrackingOrder.status === 'in_progress'
                  ? t.tripInProgress
                  : t.driverEnRoute}
              </span>
            </div>
          </div>

          {/* Interactive Simulated GPS Map Canvas */}
          <div className="relative w-full h-72 sm:h-80 rounded-2xl bg-[#071322] border border-sky-500/30 overflow-hidden shadow-inner">
            {/* Egyptian Grid & Highway Graphic */}
            <svg className="w-full h-full" viewBox="0 0 800 400" preserveAspectRatio="none">
              {/* Background Map Grid */}
              <defs>
                <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
                  <path d="M 40 0 L 0 0 0 40" fill="none" stroke="#1E293B" strokeWidth="0.8" opacity="0.4" />
                </pattern>
                <linearGradient id="routeGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#38BDF8" />
                  <stop offset="100%" stopColor="#10B981" />
                </linearGradient>
              </defs>
              <rect width="800" height="400" fill="url(#grid)" />

              {/* Desert & Nile contours */}
              <path
                d="M 280,0 Q 290,150 310,250 T 330,400"
                fill="none"
                stroke="#0369A1"
                strokeWidth="14"
                opacity="0.3"
              />
              <path
                d="M 280,0 Q 290,150 310,250 T 330,400"
                fill="none"
                stroke="#38BDF8"
                strokeWidth="4"
                opacity="0.5"
              />

              {/* Highway Path between Driver & Customer */}
              <path
                d="M 120,280 C 260,220 400,290 640,160"
                fill="none"
                stroke="url(#routeGradient)"
                strokeWidth="6"
                strokeDasharray="8 6"
                className="animate-pulse"
              />

              {/* Customer Pin at (640, 160) */}
              <g transform="translate(640, 160)">
                <circle r="22" fill="#0284C7" opacity="0.25" className="animate-ping" />
                <circle r="12" fill="#0284C7" />
                <circle r="5" fill="#FFFFFF" />
                <text x="0" y="-18" fill="#38BDF8" fontSize="11" fontWeight="bold" textAnchor="middle">
                  موقعك (العميل)
                </text>
              </g>

              {/* Destination / Dropoff Pin at (720, 90) */}
              {currentTrackingOrder.destinationAddress && (
                <g transform="translate(720, 90)">
                  <circle r="8" fill="#10B981" />
                  <text x="0" y="-14" fill="#34D399" fontSize="10" fontWeight="bold" textAnchor="middle">
                    الوجهة
                  </text>
                </g>
              )}

              {/* Moving Driver Vehicle at (380, 240) */}
              <g transform="translate(380, 240)">
                <circle r="18" fill="#F59E0B" opacity="0.3" className="animate-ping" />
                <rect x="-14" y="-14" width="28" height="28" rx="8" fill="#F59E0B" />
                <text x="0" y="4" fill="#0F172A" fontSize="11" fontWeight="black" textAnchor="middle">
                  GO
                </text>
                <text x="0" y="24" fill="#FDE047" fontSize="10" fontWeight="bold" textAnchor="middle">
                  الكابتن (على بعد ٦ دقائق)
                </text>
              </g>
            </svg>

            {/* Map Top Floating Overlay Info */}
            <div className="absolute top-3 right-3 left-3 flex items-center justify-between pointer-events-none">
              <div className="bg-slate-900/90 backdrop-blur-md px-3.5 py-1.5 rounded-xl border border-sky-500/30 text-xs font-mono text-white shadow-lg pointer-events-auto">
                <span className="text-sky-400 font-bold">السرعة: </span>
                <span>65 كم/ساعة</span> • <span className="text-emerald-400 font-bold">المسافة المتبقية: </span>
                <span>2.8 كم</span>
              </div>

              <div className="bg-slate-900/90 backdrop-blur-md px-3 py-1.5 rounded-xl border border-sky-500/30 text-xs font-bold text-amber-300 shadow-lg pointer-events-auto flex items-center gap-1.5">
                <Navigation className="w-3.5 h-3.5 text-amber-400" />
                <span>GPS مباشر</span>
              </div>
            </div>
          </div>

          {/* 5-Step Progress Bar */}
          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs font-bold text-slate-300">
              <span className={currentTrackingOrder.trackingStep >= 1 ? 'text-sky-400' : 'text-slate-500'}>
                ١. تم القبول
              </span>
              <span className={currentTrackingOrder.trackingStep >= 2 ? 'text-sky-400' : 'text-slate-500'}>
                ٢. في الطريق
              </span>
              <span className={currentTrackingOrder.trackingStep >= 3 ? 'text-sky-400' : 'text-slate-500'}>
                ٣. وصل الموقع
              </span>
              <span className={currentTrackingOrder.trackingStep >= 4 ? 'text-emerald-400' : 'text-slate-500'}>
                ٤. اكتمل المشوار
              </span>
            </div>
            <div className="h-2 rounded-full bg-slate-800 overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-sky-500 via-amber-400 to-emerald-500 transition-all duration-500"
                style={{ width: `${(currentTrackingOrder.trackingStep / 4) * 100}%` }}
              />
            </div>
          </div>

          {/* Driver Profile & Contact Bar */}
          {currentTrackingOrder.selectedOffer && (
            <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-sky-500 to-indigo-600 text-white font-black text-lg flex items-center justify-center shrink-0 shadow">
                  {currentTrackingOrder.selectedOffer.technician.name.slice(0, 2)}
                </div>
                <div>
                  <div className="font-black text-sm text-white">
                    {currentTrackingOrder.selectedOffer.technician.name}
                  </div>
                  <div className="text-xs text-sky-400 font-bold">
                    {currentTrackingOrder.selectedOffer.technician.vehicleModel} — {currentTrackingOrder.selectedOffer.technician.vehiclePlate}
                  </div>
                  <div className="text-[11px] text-slate-400 font-mono mt-0.5">
                    {currentTrackingOrder.selectedOffer.technician.phoneFull}
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setShowDriverChat(true)}
                  className="flex-1 sm:flex-initial min-h-[40px] px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-sky-300 text-xs font-bold border border-sky-500/30 flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <MessageSquare className="w-4 h-4" />
                  <span>محادثة فورية</span>
                </button>

                <a
                  href={`tel:${currentTrackingOrder.selectedOffer.technician.phoneFull}`}
                  className="flex-1 sm:flex-initial min-h-[40px] px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer shadow"
                >
                  <Phone className="w-4 h-4" />
                  <span>اتصال مباشر</span>
                </a>

                <button
                  type="button"
                  onClick={() => setView('complaint_modal')}
                  className="min-h-[40px] px-3 py-2 rounded-xl bg-slate-800 hover:bg-red-500/20 text-slate-400 hover:text-red-400 text-xs font-bold border border-slate-700 cursor-pointer"
                  title="تقديم شكوى أو استرداد"
                >
                  <AlertTriangle className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}

          {/* Rating Section (If trip completed) */}
          {currentTrackingOrder.status === 'completed' && !ratingSubmitted && (
            <div className="p-5 rounded-2xl bg-emerald-950/30 border border-emerald-500/30 text-white space-y-4">
              <div className="flex items-center gap-2 text-emerald-400 font-black text-sm">
                <CheckCircle2 className="w-5 h-5" />
                <span>اكتملت الرحلة بنجاح! شاركنا تقييمك للكابتن / الفني:</span>
              </div>

              <div className="flex items-center gap-2">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button
                    key={star}
                    type="button"
                    onClick={() => setRatingStars(star)}
                    className="p-1 cursor-pointer transition-transform hover:scale-125"
                  >
                    <Star
                      className={`w-7 h-7 ${
                        star <= ratingStars ? 'fill-amber-400 text-amber-400' : 'text-slate-600'
                      }`}
                    />
                  </button>
                ))}
              </div>

              <input
                type="text"
                value={ratingFeedback}
                onChange={(e) => setRatingFeedback(e.target.value)}
                placeholder="اكتب تعليقك (مثال: كابتن محترم جداً والسيارة مكيفة وسريعة)..."
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-2.5 text-xs text-white focus:border-emerald-500 outline-none"
              />

              <button
                type="button"
                onClick={handleCompleteOrderRating}
                className="px-5 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs cursor-pointer shadow"
              >
                إرسال التقييم
              </button>
            </div>
          )}
        </div>
      )}

      {/* =====================================================================
          MODAL: IN-APP CHAT WITH DRIVER / TECHNICIAN
         ===================================================================== */}
      {showDriverChat && currentTrackingOrder?.selectedOffer && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-sky-500/30 rounded-3xl w-full max-w-md h-[480px] flex flex-col text-white shadow-2xl overflow-hidden">
            {/* Chat Header */}
            <div className="p-4 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-sky-500/20 text-sky-400 flex items-center justify-center font-bold">
                  {currentTrackingOrder.selectedOffer.technician.name.slice(0, 2)}
                </div>
                <div>
                  <div className="font-bold text-xs text-white">
                    {currentTrackingOrder.selectedOffer.technician.name}
                  </div>
                  <div className="text-[10px] text-emerald-400">متصل الآن • قيد الوصول</div>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setShowDriverChat(false)}
                className="text-slate-400 hover:text-white p-1 text-sm cursor-pointer"
              >
                ✕
              </button>
            </div>

            {/* Chat Body */}
            <div className="flex-1 p-4 overflow-y-auto space-y-3 bg-[#071322]">
              {chatMessages.map((msg, idx) => (
                <div
                  key={idx}
                  className={`flex flex-col ${
                    msg.sender === 'user' ? 'items-end' : 'items-start'
                  }`}
                >
                  <div
                    className={`max-w-[80%] rounded-2xl px-4 py-2.5 text-xs ${
                      msg.sender === 'user'
                        ? 'bg-sky-600 text-white rounded-bl-none'
                        : 'bg-slate-800 text-slate-200 rounded-br-none border border-slate-700'
                    }`}
                  >
                    {msg.text}
                  </div>
                  <span className="text-[9px] text-slate-500 mt-1 px-1 font-mono">{msg.time}</span>
                </div>
              ))}
            </div>

            {/* Chat Input */}
            <form onSubmit={handleSendChatMessage} className="p-3 bg-slate-950 border-t border-slate-800 flex gap-2">
              <input
                type="text"
                value={chatInput}
                onChange={(e) => setChatInput(e.target.value)}
                placeholder="اكتب رسالتك للكابتن..."
                className="flex-1 bg-slate-900 border border-slate-700 rounded-xl px-3.5 py-2 text-xs text-white focus:border-sky-500 outline-none"
              />
              <button
                type="submit"
                className="px-4 py-2 rounded-xl bg-sky-500 hover:bg-sky-400 text-slate-950 font-bold text-xs cursor-pointer shrink-0"
              >
                إرسال
              </button>
            </form>
          </div>
        </div>
      )}

      {/* =====================================================================
          MODAL: COMPLAINT & DISPUTE RESOLUTION
         ===================================================================== */}
      {view === 'complaint_modal' && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-red-500/30 rounded-3xl w-full max-w-lg p-6 text-white space-y-5 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2 text-red-400 font-black text-sm">
                <AlertTriangle className="w-5 h-5" />
                <span>تقديم شكوى أو طلب استرداد رسوم</span>
              </div>
              <button
                type="button"
                onClick={() => setView('order_tracking')}
                className="text-slate-400 hover:text-white cursor-pointer"
              >
                ✕
              </button>
            </div>

            {complaintSuccess ? (
              <div className="p-4 rounded-2xl bg-emerald-500/20 text-emerald-300 text-center font-bold text-xs">
                تم تسجيل الشكوى بنجاح وإرسالها فوراً إلى لوحة تحكم المالك وفريق الدعم الفني لمراجعتها.
              </div>
            ) : (
              <form onSubmit={handleSubmitComplaint} className="space-y-4">
                <div>
                  <label className="text-xs font-bold text-slate-300 block mb-1">سبب الشكوى:</label>
                  <select
                    value={complaintReason}
                    onChange={(e) => setComplaintReason(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2.5 text-xs text-white focus:border-red-500 outline-none cursor-pointer"
                  >
                    <option value="تأخر الكابتن عن الوقت المحدد">تأخر الكابتن / الفني عن موعد الوصول</option>
                    <option value="طلب مبالغ إضافية غير متفق عليها">طلب مبالغ إضافية غير متفق عليها</option>
                    <option value="سوء المعاملة أو أسلوب القيادة">سوء المعاملة أو أسلوب القيادة</option>
                    <option value="عدم مطابقة بيانات السيارة للرخصة">عدم مطابقة بيانات السيارة للرخصة</option>
                    <option value="عدم حل المشكلة الفنية للسيارة">عدم حل المشكلة الفنية للسيارة</option>
                  </select>
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-300 block mb-1">تفاصيل إضافية:</label>
                  <textarea
                    rows={3}
                    value={complaintDesc}
                    onChange={(e) => setComplaintDesc(e.target.value)}
                    placeholder="يرجى كتابة ما حدث بالتفصيل للمساعدة في التدخل السريع..."
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-3 text-xs text-white focus:border-red-500 outline-none resize-none"
                  />
                </div>

                <div className="flex gap-3">
                  <button
                    type="submit"
                    className="flex-1 min-h-[44px] rounded-xl bg-red-600 hover:bg-red-500 text-white font-black text-xs cursor-pointer shadow"
                  >
                    إرسال الشكوى للإدارة
                  </button>
                  <button
                    type="button"
                    onClick={() => setView('order_tracking')}
                    className="px-4 rounded-xl bg-slate-800 text-slate-300 text-xs font-bold cursor-pointer"
                  >
                    إلغاء
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
