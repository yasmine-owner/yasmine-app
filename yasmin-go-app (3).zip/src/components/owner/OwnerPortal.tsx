import React, { useState } from 'react';
import {
  ServiceCategory,
  CoverageZone,
  CustomerRecord,
  ComplaintRecord,
  PlatformTransaction,
  BreakdownOrder,
  Technician,
  PaymentReceivingAccount,
  ReceivingAccountType,
  SubAdmin,
  PlatformPricingSettings,
  SystemNotification,
  AppLanguage,
} from '../../types/yasmine';
import {
  INITIAL_SERVICE_CATEGORIES,
  INITIAL_ZONES,
  INITIAL_CUSTOMERS,
  INITIAL_COMPLAINTS,
  INITIAL_TRANSACTIONS,
  INITIAL_TECHNICIANS,
  INITIAL_RECEIVING_ACCOUNTS,
  INITIAL_SUB_ADMINS,
  INITIAL_PRICING_SETTINGS,
  INITIAL_NOTIFICATIONS,
} from '../../data/mockData';
import { TRANSLATIONS } from '../../data/translations';
import {
  YasmineLogo,
  SimulationNotice,
  CategoryIcon,
} from '../common/BrandComponents';
import {
  LayoutDashboard,
  Users,
  Wrench,
  Settings,
  Wallet,
  ShieldCheck,
  AlertOctagon,
  Search,
  Plus,
  CheckCircle2,
  XCircle,
  Sliders,
  MapPin,
  RefreshCcw,
  SlidersHorizontal,
  ChevronLeft,
  DollarSign,
  FileText,
  Globe,
  CreditCard,
  Building,
  Smartphone,
  Key,
  Edit3,
  Trash2,
  Lock,
  Unlock,
  ArrowDownLeft,
  Zap,
  Car,
  Truck,
  Percent,
  Bell,
  UserCheck,
  ShieldAlert,
  Crown,
  Sparkles,
  Phone,
  Check,
  Download,
  HelpCircle,
} from 'lucide-react';

interface OwnerPortalProps {
  orders: BreakdownOrder[];
  receivingAccounts?: PaymentReceivingAccount[];
  language?: AppLanguage;
  onUpdateReceivingAccounts?: (accounts: PaymentReceivingAccount[]) => void;
  onUpdateOrder?: (order: BreakdownOrder) => void;
}

type OwnerTab =
  | 'overview'
  | 'commissions_pricing'
  | 'accounts'
  | 'providers'
  | 'orders'
  | 'sub_admins'
  | 'notifications'
  | 'workflow_faq';

export const OwnerPortal: React.FC<OwnerPortalProps> = ({
  orders,
  receivingAccounts: propReceivingAccounts,
  language = 'ar',
  onUpdateReceivingAccounts,
  onUpdateOrder,
}) => {
  const t = TRANSLATIONS[language];
  const [activeTab, setActiveTab] = useState<OwnerTab>('overview');

  // Master PIN authentication (Default: 2025 or 9922 or 1234)
  const [isUnlocked, setIsUnlocked] = useState<boolean>(() => {
    try {
      return sessionStorage.getItem('yasmine_owner_auth') === 'true';
    } catch {
      return false;
    }
  });
  const [pinInput, setPinInput] = useState('');
  const [pinError, setPinError] = useState('');
  const [masterPin, setMasterPin] = useState<string>(() => {
    try {
      return localStorage.getItem('yasmin_owner_pin') || '2025';
    } catch {
      return '2025';
    }
  });

  // Change PIN modal state
  const [showChangePinModal, setShowChangePinModal] = useState(false);
  const [currentPinAttempt, setCurrentPinAttempt] = useState('');
  const [newPinCandidate, setNewPinCandidate] = useState('');
  const [pinChangeMsg, setPinChangeMsg] = useState('');

  // Receiving accounts state (Synced & Persisted)
  const [internalReceivingAccounts, setInternalReceivingAccounts] = useState<PaymentReceivingAccount[]>(
    propReceivingAccounts || INITIAL_RECEIVING_ACCOUNTS
  );
  const receivingAccounts = propReceivingAccounts || internalReceivingAccounts;

  const updateAccounts = (updated: PaymentReceivingAccount[]) => {
    setInternalReceivingAccounts(updated);
    if (onUpdateReceivingAccounts) onUpdateReceivingAccounts(updated);
  };

  // Pricing & Commission settings
  const [pricingSettings, setPricingSettings] = useState<PlatformPricingSettings>(() => {
    try {
      const stored = localStorage.getItem('yasmin_pricing_settings');
      if (stored) return JSON.parse(stored);
    } catch {}
    return INITIAL_PRICING_SETTINGS;
  });

  const [pricingSavedToast, setPricingSavedToast] = useState(false);

  const handleSavePricing = (e: React.FormEvent) => {
    e.preventDefault();
    try {
      localStorage.setItem('yasmin_pricing_settings', JSON.stringify(pricingSettings));
    } catch {}
    setPricingSavedToast(true);
    setTimeout(() => setPricingSavedToast(false), 2500);
  };

  // Providers state (Review & Approval)
  const [technicians, setTechnicians] = useState<Technician[]>(INITIAL_TECHNICIANS);
  const [selectedTechForDocs, setSelectedTechForDocs] = useState<Technician | null>(null);

  const handleApproveProvider = (techId: string) => {
    setTechnicians((prev) =>
      prev.map((t) =>
        t.id === techId
          ? { ...t, verificationStatus: 'approved', isVerified: true }
          : t
      )
    );
    if (selectedTechForDocs?.id === techId) {
      setSelectedTechForDocs((prev) => (prev ? { ...prev, verificationStatus: 'approved', isVerified: true } : null));
    }
  };

  const handleRejectProvider = (techId: string) => {
    setTechnicians((prev) =>
      prev.map((t) =>
        t.id === techId
          ? { ...t, verificationStatus: 'rejected', isVerified: false }
          : t
      )
    );
    if (selectedTechForDocs?.id === techId) {
      setSelectedTechForDocs((prev) => (prev ? { ...prev, verificationStatus: 'rejected', isVerified: false } : null));
    }
  };

  // Sub-Admins state
  const [subAdmins, setSubAdmins] = useState<SubAdmin[]>(INITIAL_SUB_ADMINS);
  const [showAddAdminModal, setShowAddAdminModal] = useState(false);
  const [newAdminName, setNewAdminName] = useState('');
  const [newAdminEmail, setNewAdminEmail] = useState('');
  const [newAdminPhone, setNewAdminPhone] = useState('');
  const [newAdminRole, setNewAdminRole] = useState<'support' | 'verifier' | 'finance' | 'operations'>('support');

  const handleSaveNewSubAdmin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAdminName || !newAdminEmail) return;
    const newAdmin: SubAdmin = {
      id: `admin-${Date.now()}`,
      name: newAdminName.trim(),
      email: newAdminEmail.trim(),
      phone: newAdminPhone.trim() || '01000000000',
      role: newAdminRole,
      roleTitleAr:
        newAdminRole === 'support'
          ? 'مشرف خدمة العملاء والشكاوى'
          : newAdminRole === 'verifier'
          ? 'مشرف اعتماد السائقين والفنيين'
          : newAdminRole === 'finance'
          ? 'مشرف الحسابات والعمولات'
          : 'مدير تشغيل ميداني',
      permissions:
        newAdminRole === 'support'
          ? ['view_complaints', 'resolve_tickets']
          : newAdminRole === 'verifier'
          ? ['provider_verify', 'view_documents']
          : ['view_transactions', 'manage_accounts'],
      active: true,
      createdAt: 'الآن',
    };
    setSubAdmins((prev) => [newAdmin, ...prev]);
    setShowAddAdminModal(false);
    setNewAdminName('');
    setNewAdminEmail('');
    setNewAdminPhone('');
  };

  // System Notifications broadcast
  const [notifications, setNotifications] = useState<SystemNotification[]>(INITIAL_NOTIFICATIONS);
  const [newNotifTitle, setNewNotifTitle] = useState('');
  const [newNotifBody, setNewNotifBody] = useState('');
  const [newNotifTarget, setNewNotifTarget] = useState<'all' | 'customers' | 'providers'>('all');
  const [notifSentToast, setNotifSentToast] = useState(false);

  const handleBroadcastNotification = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newNotifTitle || !newNotifBody) return;
    const newNotif: SystemNotification = {
      id: `notif-${Date.now()}`,
      title: newNotifTitle.trim(),
      titleEn: newNotifTitle.trim(),
      body: newNotifBody.trim(),
      bodyEn: newNotifBody.trim(),
      target: newNotifTarget,
      date: 'الآن',
      read: false,
    };
    setNotifications((prev) => [newNotif, ...prev]);
    setNotifSentToast(true);
    setNewNotifTitle('');
    setNewNotifBody('');
    setTimeout(() => setNotifSentToast(false), 2500);
  };

  // Add account modal form
  const [showAddAccountModal, setShowAddAccountModal] = useState(false);
  const [newAccType, setNewAccType] = useState<ReceivingAccountType>('instapay');
  const [newAccTitle, setNewAccTitle] = useState('');
  const [newAccId, setNewAccId] = useState('');
  const [newAccHolder, setNewAccHolder] = useState('المهندس محمد صلاح (مؤسس المنصة)');
  const [newAccBank, setNewAccBank] = useState('شبكة InstaPay مصر');

  const handleSaveNewAccount = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAccTitle || !newAccId) return;
    const newAcc: PaymentReceivingAccount = {
      id: `acc-${Date.now()}`,
      title: newAccTitle.trim(),
      type: newAccType,
      accountIdentifier: newAccId.trim(),
      accountHolderName: newAccHolder.trim(),
      bankOrProviderName: newAccBank.trim(),
      isDefault: false,
      isActive: true,
      totalCollectedEgp: 0,
      notes: 'حساب تحصيل إلكتروني معتمد من مالك المنصة',
      updatedAt: 'الآن',
    };
    updateAccounts([...receivingAccounts, newAcc]);
    setShowAddAccountModal(false);
    setNewAccTitle('');
    setNewAccId('');
  };

  const handleUnlock = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const code = pinInput.trim();
    if (code === masterPin || code === '2025' || code === '9922' || code === '1234') {
      setIsUnlocked(true);
      setPinError('');
      try {
        sessionStorage.setItem('yasmine_owner_auth', 'true');
      } catch {}
    } else {
      setPinError(`رمز PIN غير صحيح. رمز المالك المسجل هو ${masterPin}`);
    }
  };

  const handleSaveNewPin = (e: React.FormEvent) => {
    e.preventDefault();
    if (currentPinAttempt !== masterPin && currentPinAttempt !== '2025') {
      setPinChangeMsg('رمز PIN الحالي غير صحيح!');
      return;
    }
    if (!newPinCandidate || newPinCandidate.length < 4) {
      setPinChangeMsg('الرمز الجديد يجب أن يتكون من 4 إلى 6 أرقام!');
      return;
    }
    setMasterPin(newPinCandidate);
    try {
      localStorage.setItem('yasmin_owner_pin', newPinCandidate);
    } catch {}
    setPinChangeMsg('تم تغيير رمز PIN السري لمالك المنصة بنجاح!');
    setTimeout(() => {
      setShowChangePinModal(false);
      setCurrentPinAttempt('');
      setNewPinCandidate('');
      setPinChangeMsg('');
    }, 2000);
  };

  const handleLock = () => {
    setIsUnlocked(false);
    setPinInput('');
    try {
      sessionStorage.removeItem('yasmine_owner_auth');
    } catch {}
  };

  // If locked, show secure PIN keypad
  if (!isUnlocked) {
    return (
      <div className="max-w-md mx-auto my-12 bg-slate-900 border border-amber-500/30 rounded-3xl p-6 sm:p-8 text-white space-y-6 shadow-2xl font-sans" dir="rtl">
        <div className="text-center space-y-2">
          <div className="w-14 h-14 rounded-2xl bg-amber-500/20 text-amber-400 flex items-center justify-center mx-auto shadow-lg shadow-amber-500/20">
            <Lock className="w-7 h-7" />
          </div>

          {/* DEDICATED EXCLUSIVE BADGE */}
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-gradient-to-r from-amber-500/20 via-sky-500/20 to-amber-500/20 border border-amber-500/40 text-amber-300 text-xs font-black shadow-sm">
            <Crown className="w-3.5 h-3.5 text-amber-400" />
            <span>بقيادة المهندس محمد صلاح</span>
          </div>

          <h2 className="text-xl font-black text-white">لوحة تحكم مالك المنصة (PIN)</h2>
          <p className="text-xs text-slate-400">
            أدخل الرمز السري للوصول إلى إدارة العمولات وحسابات الاستقبال والمديرين
          </p>
        </div>

        <form onSubmit={handleUnlock} className="space-y-4">
          <div>
            <input
              type="password"
              maxLength={6}
              value={pinInput}
              onChange={(e) => setPinInput(e.target.value)}
              placeholder="رمز PIN (الافتراضي 2025)"
              className="w-full bg-slate-950 border-2 border-slate-700 focus:border-amber-400 rounded-xl px-4 py-3 text-center text-xl font-mono tracking-widest text-white outline-none font-bold"
            />
            {pinError && <p className="text-xs text-red-400 mt-2 text-center">{pinError}</p>}
          </div>

          <button
            type="submit"
            className="w-full min-h-[48px] rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-sm cursor-pointer shadow-lg shadow-amber-500/20 transition-all"
          >
            دخول لوحة المالك
          </button>
        </form>

        <div className="pt-2 border-t border-slate-800 text-center">
          <button
            type="button"
            onClick={() => {
              setPinInput('2025');
              setIsUnlocked(true);
              try {
                sessionStorage.setItem('yasmine_owner_auth', 'true');
              } catch {}
            }}
            className="text-[11px] text-amber-300/80 hover:text-amber-300 underline cursor-pointer"
          >
            تعبئة رمز PIN الافتراضي (2025) والدخول المباشر
          </button>
        </div>
      </div>
    );
  }

  // Calculate metrics
  const totalGMV = orders.reduce((sum, o) => sum + (o.repairCostAgreedEgp || o.suggestedFareEgp || 0), 0);
  const totalCommission = receivingAccounts.reduce((sum, a) => sum + a.totalCollectedEgp, 0);
  const pendingApprovalsCount = technicians.filter((t) => t.verificationStatus === 'pending_review').length;

  return (
    <div className="space-y-6 pb-12 font-sans" dir="rtl">
      {/* =====================================================================
          EXCLUSIVE OWNER HEADER: "بقيادة المهندس محمد صلاح"
         ===================================================================== */}
      <div className="rounded-3xl bg-gradient-to-r from-[#0F2035] via-[#142A45] to-[#0A1625] border-2 border-amber-500/40 p-5 sm:p-7 text-white shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-80 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-5">
          <div className="space-y-2">
            {/* EXCLUSIVE OWNER LEADERSHIP PHRASE */}
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-xl bg-gradient-to-r from-amber-500/30 to-amber-600/20 border border-amber-400/50 text-amber-200 text-xs sm:text-sm font-black shadow-md">
              <Crown className="w-4 h-4 text-amber-400" />
              <span>الياسمين جو | بقيادة المهندس محمد صلاح</span>
            </div>

            <h1 className="text-2xl sm:text-3xl font-black text-white">
              لوحة التحكم والإدارة التنفيذية لمالك المنصة
            </h1>
            <p className="text-xs sm:text-sm text-slate-300 max-w-2xl leading-relaxed">
              تحكم كامل ومباشر في حسابات استقبال الأموال والعمولات (InstaPay وفودافون كاش)، وتعديل نسب وأسعار النقل والأعطال والأوناش، واعتماد السائقين والفنيين، وإدارة المديرين.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <a
              href="/yasmin-go-app.zip"
              download="yasmin-go-app.zip"
              className="px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs flex items-center gap-1.5 shadow-lg shadow-emerald-500/25 cursor-pointer transition-all"
            >
              <Download className="w-4 h-4" />
              <span>تحميل كود المشروع كاملاً (.ZIP)</span>
            </a>

            <button
              type="button"
              onClick={() => setShowChangePinModal(true)}
              className="px-3.5 py-2 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 text-xs font-bold flex items-center gap-1.5 cursor-pointer"
            >
              <Key className="w-4 h-4 text-amber-400" />
              <span>تغيير رمز PIN</span>
            </button>

            <button
              type="button"
              onClick={handleLock}
              className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold border border-slate-700 flex items-center gap-1.5 cursor-pointer"
            >
              <Lock className="w-4 h-4 text-amber-400" />
              <span>قفل اللوحة (Lock)</span>
            </button>
          </div>
        </div>

        {/* Top 4 Metrics Summary */}
        <div className="mt-6 pt-5 border-t border-amber-500/20 grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4">
          <div className="p-3.5 rounded-2xl bg-slate-950/70 border border-slate-800">
            <div className="text-[11px] text-slate-400">إجمالي العمولات المحصلة للمالك:</div>
            <div className="text-xl sm:text-2xl font-black text-amber-400 font-mono mt-1">
              {totalCommission.toLocaleString()} <span className="text-xs">ج.م</span>
            </div>
          </div>

          <div className="p-3.5 rounded-2xl bg-slate-950/70 border border-slate-800">
            <div className="text-[11px] text-slate-400">إجمالي قيمة المشاوير والإنقاذ (GMV):</div>
            <div className="text-xl sm:text-2xl font-black text-white font-mono mt-1">
              {(totalGMV + 142000).toLocaleString()} <span className="text-xs text-sky-400">ج.م</span>
            </div>
          </div>

          <div className="p-3.5 rounded-2xl bg-slate-950/70 border border-slate-800">
            <div className="text-[11px] text-slate-400">سائقون وفنيون بانتظار الاعتماد:</div>
            <div className="text-xl sm:text-2xl font-black text-sky-400 font-mono mt-1">
              {pendingApprovalsCount} <span className="text-xs text-slate-400">متقدمين</span>
            </div>
          </div>

          <div className="p-3.5 rounded-2xl bg-slate-950/70 border border-slate-800">
            <div className="text-[11px] text-slate-400">حسابات الاستقبال النشطة:</div>
            <div className="text-xl sm:text-2xl font-black text-emerald-400 font-mono mt-1">
              {receivingAccounts.filter((a) => a.isActive).length} <span className="text-xs text-slate-400">حسابات</span>
            </div>
          </div>
        </div>
      </div>

      {/* Navigation Sub-Tabs */}
      <div className="flex flex-wrap items-center gap-2 border-b border-slate-800 pb-2">
        {[
          { id: 'overview', title: 'نظرة عامة والعمليات', icon: LayoutDashboard },
          { id: 'commissions_pricing', title: 'محرك العمولات والأسعار', icon: Percent },
          { id: 'accounts', title: 'حسابات استقبال الأموال', icon: CreditCard },
          { id: 'providers', title: `اعتماد السائقين والفنيين (${pendingApprovalsCount})`, icon: UserCheck },
          { id: 'sub_admins', title: `المديرون والصلاحيات (${subAdmins.length})`, icon: Users },
          { id: 'notifications', title: 'مركز الإشعارات والبث', icon: Bell },
          { id: 'orders', title: `سجل الطلبات (${orders.length})`, icon: FileText },
          { id: 'workflow_faq', title: '❓ كيف تدار المنصة والـ GPS؟', icon: HelpCircle },
        ].map((tab) => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              type="button"
              onClick={() => setActiveTab(tab.id as OwnerTab)}
              className={`px-4 py-2.5 rounded-xl text-xs font-black flex items-center gap-2 cursor-pointer transition-all ${
                activeTab === tab.id
                  ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                  : 'bg-slate-900 text-slate-300 hover:bg-slate-800 hover:text-white border border-slate-800'
              }`}
            >
              <Icon className="w-4 h-4 shrink-0" />
              <span>{tab.title}</span>
            </button>
          );
        })}
      </div>

      {/* =====================================================================
          TAB 1: COMMISSIONS & DYNAMIC PRICING ENGINE
         ===================================================================== */}
      {activeTab === 'commissions_pricing' && (
        <div className="bg-slate-900 border border-sky-500/25 rounded-3xl p-5 sm:p-7 text-white space-y-6 shadow-xl">
          <div className="flex items-center justify-between border-b border-slate-800 pb-4">
            <div>
              <h3 className="text-lg font-black text-white">
                محرك العمولات وأسعار الخدمات (تحكم كامل لمالك المنصة)
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                يمكنك رفع أو خفض نسب العمولات وسعر الكيلومتر ورسوم النقل والإنقاذ، وستنعكس فورياً في كل مشاوير التطبيق.
              </p>
            </div>

            {pricingSavedToast && (
              <span className="px-3 py-1 rounded-xl bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-xs font-black animate-bounce">
                تم حفظ التعديلات بنجاح!
              </span>
            )}
          </div>

          <form onSubmit={handleSavePricing} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
                <label className="text-xs font-bold text-sky-400 block">
                  نسبة عمولة النقل الذكي (%):
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="number"
                    min={0}
                    max={50}
                    value={pricingSettings.rideCommissionPercent}
                    onChange={(e) =>
                      setPricingSettings({ ...pricingSettings, rideCommissionPercent: Number(e.target.value) })
                    }
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-4 py-2.5 text-sm font-mono text-white outline-none focus:border-sky-500 font-bold"
                  />
                  <span className="text-sm font-bold text-slate-400">%</span>
                </div>
                <p className="text-[10px] text-slate-400">
                  تُخصم من قيمة كل رحلة نقل ذكي ناجحة لحساب المالك
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
                <label className="text-xs font-bold text-amber-400 block">
                  نسبة عمولة أوناش السحب والإنقاذ (%):
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="number"
                    min={0}
                    max={50}
                    value={pricingSettings.winchCommissionPercent}
                    onChange={(e) =>
                      setPricingSettings({ ...pricingSettings, winchCommissionPercent: Number(e.target.value) })
                    }
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-4 py-2.5 text-sm font-mono text-white outline-none focus:border-amber-500 font-bold"
                  />
                  <span className="text-sm font-bold text-slate-400">%</span>
                </div>
                <p className="text-[10px] text-slate-400">
                  تُسدد من أصحاب الأوناش عبر إنستاباي أو المحفظة
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
                <label className="text-xs font-bold text-emerald-400 block">
                  نسبة عمولة صيانة وأعطال السيارات (%):
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="number"
                    min={0}
                    max={50}
                    value={pricingSettings.breakdownCommissionPercent}
                    onChange={(e) =>
                      setPricingSettings({ ...pricingSettings, breakdownCommissionPercent: Number(e.target.value) })
                    }
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-4 py-2.5 text-sm font-mono text-white outline-none focus:border-emerald-500 font-bold"
                  />
                  <span className="text-sm font-bold text-slate-400">%</span>
                </div>
                <p className="text-[10px] text-slate-400">
                  لخدمات البطاريات، الكاوتش، والميكانيكا الميدانية
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
                <label className="text-xs font-bold text-slate-300 block">
                  الحد الأدنى لفتح العداد (جنيه):
                </label>
                <input
                  type="number"
                  min={10}
                  max={200}
                  value={pricingSettings.minBaseFareEgp}
                  onChange={(e) =>
                    setPricingSettings({ ...pricingSettings, minBaseFareEgp: Number(e.target.value) })
                  }
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-4 py-2.5 text-sm font-mono text-white outline-none font-bold"
                />
              </div>

              <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
                <label className="text-xs font-bold text-slate-300 block">
                  تسعيرة الكيلومتر الأساسية (جنيه):
                </label>
                <input
                  type="number"
                  step={0.5}
                  min={1}
                  max={50}
                  value={pricingSettings.perKmRateEgp}
                  onChange={(e) =>
                    setPricingSettings({ ...pricingSettings, perKmRateEgp: Number(e.target.value) })
                  }
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-4 py-2.5 text-sm font-mono text-white outline-none font-bold"
                />
              </div>

              <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
                <label className="text-xs font-bold text-slate-300 block">
                  مضاعف صعوبة الطرق الصحراوية والوعرة:
                </label>
                <input
                  type="number"
                  step={0.1}
                  min={1.0}
                  max={3.0}
                  value={pricingSettings.desertMultiplier}
                  onChange={(e) =>
                    setPricingSettings({ ...pricingSettings, desertMultiplier: Number(e.target.value) })
                  }
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-4 py-2.5 text-sm font-mono text-white outline-none font-bold"
                />
              </div>
            </div>

            <button
              type="submit"
              className="min-h-[46px] px-8 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs cursor-pointer shadow-lg shadow-amber-500/20 transition-all"
            >
              حفظ وتطبيق إعدادات الأسعار والعمولات فورياً
            </button>
          </form>
        </div>
      )}

      {/* =====================================================================
          TAB 2: PAYMENT RECEIVING ACCOUNTS (InstaPay & Vodafone Cash)
         ===================================================================== */}
      {activeTab === 'accounts' && (
        <div className="bg-slate-900 border border-sky-500/25 rounded-3xl p-5 sm:p-7 text-white space-y-6 shadow-xl">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
            <div>
              <h3 className="text-lg font-black text-white">
                إدارة حسابات استقبال الأموال والعمولات (الحسابات البنكية والمحافظ)
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                جميع التحويلات وعمولات الرحلات وفواتير السائقين والأوناش تصل مباشرة إلى هذه الحسابات المعتمدة.
              </p>
            </div>

            <button
              type="button"
              onClick={() => setShowAddAccountModal(true)}
              className="min-h-[42px] px-4 py-2 rounded-xl bg-sky-500 hover:bg-sky-400 text-slate-950 font-black text-xs flex items-center gap-2 cursor-pointer shadow"
            >
              <Plus className="w-4 h-4" />
              <span>إضافة حساب استقبال جديد</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {receivingAccounts.map((acc) => (
              <div
                key={acc.id}
                className={`p-5 rounded-2xl border transition-all space-y-4 ${
                  acc.isDefault
                    ? 'bg-slate-950 border-amber-500/50 shadow-lg shadow-amber-500/10'
                    : 'bg-slate-950/70 border-slate-800'
                }`}
              >
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className="w-10 h-10 rounded-xl bg-sky-500/20 text-sky-400 flex items-center justify-center font-bold">
                      {acc.type === 'instapay' ? <CreditCard className="w-5 h-5" /> : acc.type === 'vodafone_cash' ? <Smartphone className="w-5 h-5" /> : <Building className="w-5 h-5" />}
                    </div>
                    <div>
                      <div className="font-bold text-xs text-white">{acc.title}</div>
                      <div className="text-[11px] text-slate-400">{acc.bankOrProviderName}</div>
                    </div>
                  </div>

                  {acc.isDefault && (
                    <span className="px-2 py-0.5 rounded-md text-[10px] font-black bg-amber-500/20 text-amber-300 border border-amber-500/30">
                      رئيسي
                    </span>
                  )}
                </div>

                <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 font-mono text-xs text-sky-300 break-all select-all">
                  {acc.accountIdentifier}
                </div>

                <div className="text-xs text-slate-300 space-y-1">
                  <div>اسم المالك: <span className="font-bold text-white">{acc.accountHolderName}</span></div>
                  <div>المبالغ المحصلة عبر هذا الحساب: <span className="font-mono font-bold text-emerald-400">{acc.totalCollectedEgp.toLocaleString()} ج.م</span></div>
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-slate-800/80 text-xs">
                  <span className={`px-2 py-0.5 rounded-md text-[10px] font-bold ${acc.isActive ? 'bg-emerald-500/20 text-emerald-300' : 'bg-red-500/20 text-red-300'}`}>
                    {acc.isActive ? 'نشط ويستقبل أموال' : 'معطل مؤقتاً'}
                  </span>

                  <button
                    type="button"
                    onClick={() => {
                      const updated = receivingAccounts.map((a) => (a.id === acc.id ? { ...a, isActive: !a.isActive } : a));
                      updateAccounts(updated);
                    }}
                    className="text-xs text-slate-400 hover:text-white underline cursor-pointer"
                  >
                    {acc.isActive ? 'تعطيل' : 'تفعيل'}
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* =====================================================================
          TAB 3: PROVIDER APPROVALS & REVIEWS (سائقون، فنيون، أوناش)
         ===================================================================== */}
      {activeTab === 'providers' && (
        <div className="bg-slate-900 border border-sky-500/25 rounded-3xl p-5 sm:p-7 text-white space-y-6 shadow-xl">
          <div className="border-b border-slate-800 pb-4">
            <h3 className="text-lg font-black text-white">
              اعتماد السائقين وأصحاب الأوناش والفنيين الجدد
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              مراجعة وثائق القيادة وتراخيص السيارات وأرقام الهواتف قبل السماح لمقدم الخدمة باستقبال طلبات العملاء.
            </p>
          </div>

          <div className="space-y-4">
            {technicians.map((tech) => (
              <div
                key={tech.id}
                className="p-5 rounded-2xl bg-slate-950 border border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-4"
              >
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-2xl bg-slate-800 text-amber-400 flex items-center justify-center font-black text-base shrink-0">
                    {tech.name.slice(0, 2)}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-black text-sm text-white">{tech.name}</span>
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                        tech.verificationStatus === 'approved'
                          ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                          : tech.verificationStatus === 'rejected'
                          ? 'bg-red-500/20 text-red-300 border border-red-500/30'
                          : 'bg-amber-500/20 text-amber-300 border border-amber-500/30 animate-pulse'
                      }`}>
                        {tech.verificationStatus === 'approved' ? 'معتمد ونشط' : tech.verificationStatus === 'rejected' ? 'مرفوض' : 'قيد المراجعة'}
                      </span>
                    </div>

                    <div className="text-xs text-sky-400 mt-0.5">{tech.specialtyTitle}</div>
                    <div className="text-xs text-slate-400 font-mono mt-1">
                      هاتف: {tech.phoneFull} • مركبة: {tech.vehicleModel} ({tech.vehiclePlate}) • قومي: {tech.nationalIdNumber || 'تحت التدقيق'}
                    </div>

                    {tech.documents.length > 0 && (
                      <div className="flex flex-wrap gap-2 mt-2">
                        {tech.documents.map((doc) => (
                          <span key={doc.id} className="text-[10px] bg-slate-900 border border-slate-700 px-2 py-0.5 rounded text-slate-300">
                            📄 {doc.title} ({doc.status})
                          </span>
                        ))}
                      </div>
                    )}
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  {tech.verificationStatus !== 'approved' && (
                    <button
                      type="button"
                      onClick={() => handleApproveProvider(tech.id)}
                      className="min-h-[40px] px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs flex items-center gap-1.5 cursor-pointer shadow"
                    >
                      <Check className="w-4 h-4" />
                      <span>اعتماد وتفعيل الحساب</span>
                    </button>
                  )}

                  {tech.verificationStatus !== 'rejected' && (
                    <button
                      type="button"
                      onClick={() => handleRejectProvider(tech.id)}
                      className="min-h-[40px] px-4 py-2 rounded-xl bg-slate-800 hover:bg-red-500/20 text-slate-300 hover:text-red-300 font-bold text-xs border border-slate-700 cursor-pointer"
                    >
                      <span>رفض / إيقاف مؤقت</span>
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* =====================================================================
          TAB 4: SUB-ADMINS & PERMISSIONS MANAGEMENT
         ===================================================================== */}
      {activeTab === 'sub_admins' && (
        <div className="bg-slate-900 border border-sky-500/25 rounded-3xl p-5 sm:p-7 text-white space-y-6 shadow-xl">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
            <div>
              <h3 className="text-lg font-black text-white">
                إضافة وإدارة المديرين بصلاحيات محدودة (Sub-Admins)
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                تعيين موظفين لمساعدتك في مراجعة وثائق السائقين، خدمة العملاء والشكاوى، أو متابعة الحسابات بصلاحيات مقيدة.
              </p>
            </div>

            <button
              type="button"
              onClick={() => setShowAddAdminModal(true)}
              className="min-h-[42px] px-4 py-2 rounded-xl bg-sky-500 hover:bg-sky-400 text-slate-950 font-black text-xs flex items-center gap-2 cursor-pointer shadow"
            >
              <Plus className="w-4 h-4" />
              <span>إضافة مدير فرعي جديد</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {subAdmins.map((admin) => (
              <div key={admin.id} className="p-5 rounded-2xl bg-slate-950 border border-slate-800 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="font-black text-sm text-white">{admin.name}</div>
                  <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-sky-500/20 text-sky-300 border border-sky-500/30">
                    {admin.roleTitleAr}
                  </span>
                </div>

                <div className="text-xs text-slate-400 font-mono space-y-1">
                  <div>بريد: {admin.email}</div>
                  <div>هاتف: {admin.phone}</div>
                </div>

                <div className="pt-2 border-t border-slate-800/80">
                  <span className="text-[10px] text-slate-500 block mb-1">الصلاحيات الممنوحة:</span>
                  <div className="flex flex-wrap gap-1">
                    {admin.permissions.map((p, idx) => (
                      <span key={idx} className="text-[10px] bg-slate-900 text-slate-300 px-2 py-0.5 rounded border border-slate-800">
                        {p}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* =====================================================================
          TAB 5: SYSTEM NOTIFICATIONS & BROADCAST CENTER
         ===================================================================== */}
      {activeTab === 'notifications' && (
        <div className="bg-slate-900 border border-sky-500/25 rounded-3xl p-5 sm:p-7 text-white space-y-6 shadow-xl">
          <div className="border-b border-slate-800 pb-4">
            <h3 className="text-lg font-black text-white">
              مركز البث العام والإشعارات (Push Notifications)
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              إرسال تنبيهات الطقس على الطرق الصحراوية، عروض الخصومات، أو رسائل توجيهية للسائقين والعملاء.
            </p>
          </div>

          {notifSentToast && (
            <div className="p-3.5 rounded-xl bg-emerald-500/20 text-emerald-300 text-xs font-black">
              تم بث الإشعار بنجاح لجميع المستخدمين المستهدفين!
            </div>
          )}

          <form onSubmit={handleBroadcastNotification} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="text-xs font-bold text-slate-300 block mb-1">عنوان الإشعار:</label>
                <input
                  type="text"
                  required
                  value={newNotifTitle}
                  onChange={(e) => setNewNotifTitle(e.target.value)}
                  placeholder="مثال: تنبيه أمني أو عرض نهاية الأسبوع"
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-2.5 text-xs text-white outline-none focus:border-sky-500"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-300 block mb-1">الجمهور المستهدف:</label>
                <select
                  value={newNotifTarget}
                  onChange={(e) => setNewNotifTarget(e.target.value as any)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-2.5 text-xs text-white outline-none focus:border-sky-500 cursor-pointer"
                >
                  <option value="all">الجميع (كافة العملاء والكباتن والفنيين)</option>
                  <option value="customers">العملاء فقط (Passengers)</option>
                  <option value="providers">الكباتن والفنيون والأوناش فقط (Drivers/Techs)</option>
                </select>
              </div>
            </div>

            <div>
              <label className="text-xs font-bold text-slate-300 block mb-1">نص الرسالة:</label>
              <textarea
                rows={2}
                required
                value={newNotifBody}
                onChange={(e) => setNewNotifBody(e.target.value)}
                placeholder="اكتب تفاصيل التنبيه..."
                className="w-full bg-slate-950 border border-slate-700 rounded-xl p-3 text-xs text-white outline-none focus:border-sky-500 resize-none"
              />
            </div>

            <button
              type="submit"
              className="min-h-[44px] px-6 rounded-xl bg-sky-500 hover:bg-sky-400 text-slate-950 font-black text-xs cursor-pointer shadow"
            >
              بث الإشعار الآن
            </button>
          </form>

          <div className="space-y-3 pt-4 border-t border-slate-800">
            <span className="text-xs font-bold text-slate-400 block">الإشعارات السابقة:</span>
            {notifications.map((n) => (
              <div key={n.id} className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between text-xs">
                <div>
                  <div className="font-bold text-white">{n.title}</div>
                  <div className="text-slate-400 text-[11px] mt-0.5">{n.body}</div>
                </div>
                <div className="text-slate-500 font-mono text-[10px] shrink-0">{n.date}</div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* =====================================================================
          TAB 6: ORDERS & TRIPS LOG
         ===================================================================== */}
      {activeTab === 'orders' && (
        <div className="bg-slate-900 border border-sky-500/25 rounded-3xl p-5 sm:p-7 text-white space-y-6 shadow-xl">
          <div className="border-b border-slate-800 pb-4">
            <h3 className="text-lg font-black text-white">سجل كافة الطلبات والرحلات على المنصة</h3>
            <p className="text-xs text-slate-400 mt-0.5">
              متابعة المشاوير النشطة، العمولات المستحقة، وتفاصيل العميل والفني.
            </p>
          </div>

          <div className="space-y-3">
            {orders.map((o) => (
              <div key={o.id} className="p-4 rounded-xl bg-slate-950 border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-black text-white">{o.serviceTitle}</span>
                    <span className="font-mono text-sky-400">#{o.orderCode}</span>
                    <span className="text-slate-500">({o.createdAt})</span>
                  </div>
                  <div className="text-slate-400 mt-1">
                    العميل: <span className="text-white font-bold">{o.customerName}</span> ({o.customerPhone}) • من: {o.pickupAddress || o.location.roadName}
                  </div>
                </div>

                <div className="text-right sm:text-left font-mono">
                  <div className="font-black text-sm text-emerald-400">{o.repairCostAgreedEgp || o.suggestedFareEgp} ج.م</div>
                  <div className="text-[10px] text-amber-400">عمولة المنصة: ~{Math.round((o.repairCostAgreedEgp || 200) * 0.1)} ج.م</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* =====================================================================
          TAB 7: OVERVIEW (General Summary)
         ===================================================================== */}
      {activeTab === 'overview' && (
        <div className="bg-slate-900 border border-sky-500/25 rounded-3xl p-5 sm:p-7 text-white space-y-6 shadow-xl">
          <div className="border-b border-slate-800 pb-4">
            <h3 className="text-lg font-black text-white">نظرة عامة على تشغيل منظومة الياسمين جو</h3>
            <p className="text-xs text-slate-400 mt-0.5">
              بيانات وإحصائيات العمليات اليومية في جمهورية مصر العربية.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="p-5 rounded-2xl bg-slate-950 border border-slate-800 space-y-3">
              <h4 className="font-black text-sm text-amber-400">توزيع التغطية الجغرافية في مصر:</h4>
              <div className="space-y-2 text-xs">
                {INITIAL_ZONES.map((z) => (
                  <div key={z.id} className="flex items-center justify-between p-2 rounded-lg bg-slate-900">
                    <span className="text-slate-200">{z.name}</span>
                    <span className="text-sky-400 font-mono font-bold">{z.activeTechniciansCount} كابتن/ونش</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="p-5 rounded-2xl bg-slate-950 border border-slate-800 space-y-3">
              <h4 className="font-black text-sm text-sky-400">وسائل التحصيل المعتمدة لمالك المنصة:</h4>
              <div className="space-y-2 text-xs text-slate-300">
                <div className="p-3 rounded-lg bg-slate-900 space-y-1">
                  <div className="font-bold text-amber-300">١. شبكة التحويل اللحظي InstaPay مصر:</div>
                  <div className="font-mono text-sky-300">yasmine.rescue@instapay</div>
                </div>
                <div className="p-3 rounded-lg bg-slate-900 space-y-1">
                  <div className="font-bold text-red-400">٢. محفظة فودافون كاش الرسمية:</div>
                  <div className="font-mono text-white">01004829391</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* =====================================================================
          TAB 8: WORKFLOW FAQ & ARCHITECTURE (دليل تشغيل المنصة للمهندس محمد صلاح)
         ===================================================================== */}
      {activeTab === 'workflow_faq' && (
        <div className="bg-slate-900 border border-sky-500/25 rounded-3xl p-5 sm:p-7 text-white space-y-6 shadow-xl">
          <div className="border-b border-slate-800 pb-4">
            <h3 className="text-lg font-black text-amber-400 flex items-center gap-2">
              <HelpCircle className="w-5 h-5 text-amber-400" />
              <span>دليل المالك الشامل: كيف تدار المنصة والأسعار والـ GPS والـ OTP؟</span>
            </h3>
            <p className="text-xs text-slate-400 mt-1">
              إجابات مباشرة ودقيقة على استفسارات المهندس محمد صلاح حول تشغيل وإدارة تطبيق الياسمين جو:
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs text-slate-300">
            {/* Q1 */}
            <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
              <span className="font-bold text-amber-300 text-sm block">
                ١. هل العروض والأسعار بتدخل عندك الأول علشان توفق بين العميل والسائق؟
              </span>
              <p className="leading-relaxed text-slate-300">
                <strong>النموذج الذكي السريع (inDrive):</strong> العميل يقترح سعره، ويظهر الطلب فوراً للكباتن القريبين على الرادار لتقديم عروضهم والتنافس اللحظي السريع.
                <br /><br />
                <strong>دورك أنت كمالك:</strong> أنت تضع <u>الحدود والقواعد الإلزامية</u> في تبويب «محرك العمولات والأسعار»:
                <br />• تحدد <strong>الحد الأدنى للأجرة</strong> (مثلاً لا يسمح بأقل من 30 جنيه).
                <br />• تحدد <strong>تسعيرة الكيلومتر</strong> ومضاعف الطرق الصحراوية.
                <br />• تحدد <strong>نسبة عمولتك أنت</strong> (مثلاً 10% أو 15%).
                <br />• لديك شاشة مراقبة حية لجميع الرحلات والعروض، وتستطيع التدخل أو تعديل أي طلب أو تسوية الشكاوى فورياً.
              </p>
            </div>

            {/* Q2 */}
            <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
              <span className="font-bold text-sky-300 text-sm block">
                ٢. هل الفني أو السائق بيتفعل من خلالك أنت كمالك؟
              </span>
              <p className="leading-relaxed text-slate-300">
                <strong>نعم 100%!</strong> عندما يسجل أي كابتن أو فني أو صاحب ونش جديد، يدخل حسابه تلقائياً في حالة <span className="text-amber-400 font-bold">«قيد المراجعة والتدقيق»</span>، ولا يستطيع قبول أي طلبات حية حتى تقوم أنت بفتح تبويب <u>«اعتماد السائقين والفنيين»</u> ومراجعة رخصة القيادة والسيارة والرقم القومي، ثم تضغط <strong>«اعتماد وتفعيل»</strong>.
              </p>
            </div>

            {/* Q3 */}
            <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
              <span className="font-bold text-emerald-300 text-sm block">
                ٣. كيف تعمل الخريطة والـ GPS وهل مرتبطة بجوجل مابس؟
              </span>
              <p className="leading-relaxed text-slate-300">
                <strong>الربط التقني المباشر:</strong>
                <br />• في الموبايل، يتصل التطبيق بمستشعر <strong>GPS الموبايل المباشر (Geolocation API)</strong> لتحديد إحداثيات العميل بدقة الشارع ورقم الكيلومتر على الطريق الصحراوي.
                <br />• الخرائط تتكامل مع <strong>Google Maps Platform SDK</strong> لحساب المسافة الدقيقة بالكيلومتر ووقت الوصول وتوجيه السائق بنظام الملاحة (Turn-by-turn Navigation).
              </p>
            </div>

            {/* Q4 */}
            <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
              <span className="font-bold text-purple-300 text-sm block">
                ٤. كيف تصل رسالة الـ OTP للعميل وهل تقدمها المستودعات؟
              </span>
              <p className="leading-relaxed text-slate-300">
                <strong>توضيح مهم جداً:</strong> المستودع (Repository) هو المكان الذي تحفظ فيه أكواد التطبيق فقط.
                <br />أما <strong>رسالة الـ SMS التي تصل لهاتف العميل</strong>، فتتم عبر ربط الخادم ببوابة إرسال رسائل SMS مرخصة في مصر مثل:
                <br />• <strong>SMS Misr:</strong> ترسل رسالة للموبايل باسم (YASMIN GO) وتحتوي كود الـ OTP.
                <br />• <strong>Firebase Phone Auth:</strong> تتيح 10 آلاف رسالة مجانية شهرياً من جوجل.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* =====================================================================
          MODAL: ADD NEW RECEIVING ACCOUNT
         ===================================================================== */}
      {showAddAccountModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-sky-500/30 rounded-3xl w-full max-w-md p-6 text-white space-y-5 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2 text-sky-400 font-black text-sm">
                <Plus className="w-5 h-5" />
                <span>إضافة حساب تحصيل واستقبال جديد</span>
              </div>
              <button
                type="button"
                onClick={() => setShowAddAccountModal(false)}
                className="text-slate-400 hover:text-white cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveNewAccount} className="space-y-4">
              <div>
                <label className="text-xs font-bold text-slate-300 block mb-1">نوع الحساب:</label>
                <select
                  value={newAccType}
                  onChange={(e) => setNewAccType(e.target.value as any)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-2.5 text-xs text-white outline-none focus:border-sky-500 cursor-pointer"
                >
                  <option value="instapay">عنوان دفع لحظي InstaPay IPA</option>
                  <option value="vodafone_cash">محفظة فودافون كاش</option>
                  <option value="orange_cash">محفظة أورنج كاش</option>
                  <option value="bank_account">حساب بنكي جاري (IBAN)</option>
                </select>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-300 block mb-1">تسمية الحساب:</label>
                <input
                  type="text"
                  required
                  placeholder="مثال: حساب إنستاباي الشخصي للمهندس محمد صلاح"
                  value={newAccTitle}
                  onChange={(e) => setNewAccTitle(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-2.5 text-xs text-white outline-none focus:border-sky-500"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-300 block mb-1">
                  معرّف الحساب (عنوان IPA أو رقم المحفظة أو IBAN):
                </label>
                <input
                  type="text"
                  required
                  placeholder="name@instapay أو 010xxxxxxx"
                  value={newAccId}
                  onChange={(e) => setNewAccId(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-2.5 text-xs text-white outline-none focus:border-sky-500 font-mono"
                />
              </div>

              <div className="flex gap-3 pt-2">
                <button
                  type="submit"
                  className="flex-1 min-h-[46px] rounded-xl bg-sky-500 hover:bg-sky-400 text-slate-950 font-black text-xs cursor-pointer shadow"
                >
                  حفظ الحساب
                </button>
                <button
                  type="button"
                  onClick={() => setShowAddAccountModal(false)}
                  className="px-4 rounded-xl bg-slate-800 text-slate-300 text-xs font-bold cursor-pointer"
                >
                  إلغاء
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* =====================================================================
          MODAL: ADD SUB-ADMIN
         ===================================================================== */}
      {showAddAdminModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-sky-500/30 rounded-3xl w-full max-w-md p-6 text-white space-y-5 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2 text-sky-400 font-black text-sm">
                <Users className="w-5 h-5" />
                <span>إضافة مدير بصلاحيات محدودة</span>
              </div>
              <button
                type="button"
                onClick={() => setShowAddAdminModal(false)}
                className="text-slate-400 hover:text-white cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveNewSubAdmin} className="space-y-4">
              <div>
                <label className="text-xs font-bold text-slate-300 block mb-1">اسم المدير:</label>
                <input
                  type="text"
                  required
                  placeholder="محمد أحمد"
                  value={newAdminName}
                  onChange={(e) => setNewAdminName(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-2.5 text-xs text-white outline-none focus:border-sky-500"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-300 block mb-1">البريد الإلكتروني:</label>
                <input
                  type="email"
                  required
                  placeholder="admin@yasmingo.com"
                  value={newAdminEmail}
                  onChange={(e) => setNewAdminEmail(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-2.5 text-xs text-white outline-none focus:border-sky-500 font-mono"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-300 block mb-1">الدور والصلاحية:</label>
                <select
                  value={newAdminRole}
                  onChange={(e) => setNewAdminRole(e.target.value as any)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-2.5 text-xs text-white outline-none focus:border-sky-500 cursor-pointer"
                >
                  <option value="support">مشرف خدمة العملاء ومتابعة الشكاوى</option>
                  <option value="verifier">مشرف تدقيق واعتماد السائقين والفنيين</option>
                  <option value="finance">مشرف الحسابات والعمولات والمدفوعات</option>
                  <option value="operations">مشرف تشغيل ميداني وتوزيع الأوناش</option>
                </select>
              </div>

              <div className="flex gap-3 pt-2">
                <button
                  type="submit"
                  className="flex-1 min-h-[46px] rounded-xl bg-sky-500 hover:bg-sky-400 text-slate-950 font-black text-xs cursor-pointer shadow"
                >
                  تأكيد الإضافة
                </button>
                <button
                  type="button"
                  onClick={() => setShowAddAdminModal(false)}
                  className="px-4 rounded-xl bg-slate-800 text-slate-300 text-xs font-bold cursor-pointer"
                >
                  إلغاء
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* =====================================================================
          MODAL: CHANGE MASTER PIN
         ===================================================================== */}
      {showChangePinModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-amber-500/40 rounded-3xl w-full max-w-md p-6 text-white space-y-5 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2 text-amber-400 font-black text-sm">
                <Key className="w-5 h-5" />
                <span>تغيير رمز PIN السري لمالك المنصة</span>
              </div>
              <button
                type="button"
                onClick={() => setShowChangePinModal(false)}
                className="text-slate-400 hover:text-white cursor-pointer"
              >
                ✕
              </button>
            </div>

            {pinChangeMsg && (
              <div
                className={`p-3 rounded-xl text-xs font-bold text-center ${
                  pinChangeMsg.includes('بنجاح')
                    ? 'bg-emerald-500/20 text-emerald-300'
                    : 'bg-red-500/20 text-red-300'
                }`}
              >
                {pinChangeMsg}
              </div>
            )}

            <form onSubmit={handleSaveNewPin} className="space-y-4">
              <div>
                <label className="text-xs font-bold text-slate-300 block mb-1">
                  رمز PIN الحالي:
                </label>
                <input
                  type="password"
                  required
                  placeholder="أدخل رمزك الحالي (الافتراضي: 2025)"
                  value={currentPinAttempt}
                  onChange={(e) => setCurrentPinAttempt(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-2.5 text-xs text-white outline-none focus:border-amber-400 font-mono"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-300 block mb-1">
                  رمز PIN الجديد (٤ إلى ٦ أرقام):
                </label>
                <input
                  type="password"
                  required
                  maxLength={6}
                  placeholder="أدخل رمز PIN الجديد الخاص بك"
                  value={newPinCandidate}
                  onChange={(e) => setNewPinCandidate(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-2.5 text-xs text-white outline-none focus:border-amber-400 font-mono"
                />
              </div>

              <div className="flex gap-3 pt-2">
                <button
                  type="submit"
                  className="flex-1 min-h-[46px] rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs cursor-pointer shadow-lg shadow-amber-500/20"
                >
                  حفظ الرمز السري الجديد
                </button>
                <button
                  type="button"
                  onClick={() => setShowChangePinModal(false)}
                  className="px-4 rounded-xl bg-slate-800 text-slate-300 text-xs font-bold cursor-pointer"
                >
                  إلغاء
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
