import React, { useState } from 'react';
import {
  Technician,
  BreakdownOrder,
  TechnicianDocument,
  ServiceCategoryId,
  PaymentReceivingAccount,
  AppLanguage,
  ProviderRole,
} from '../../types/yasmine';
import {
  INITIAL_TECHNICIANS,
  INITIAL_SERVICE_CATEGORIES,
  INITIAL_RECEIVING_ACCOUNTS,
} from '../../data/mockData';
import { TRANSLATIONS } from '../../data/translations';
import {
  YasmineLogo,
  SimulationNotice,
  SafetyEmergencyBanner,
  CategoryIcon,
} from '../common/BrandComponents';
import {
  Wrench,
  Clock,
  Star,
  MapPin,
  CheckCircle2,
  FileCheck2,
  Upload,
  Send,
  CreditCard,
  Truck,
  MessageSquare,
  Navigation,
  Compass,
  AlertOctagon,
  Check,
  ChevronLeft,
  Lock,
  Unlock,
  Phone,
  ShieldCheck,
  DollarSign,
  X,
  Car,
  Disc,
  BatteryCharging,
  Smartphone,
  Banknote,
  FileText,
  AlertTriangle,
  Sparkles,
} from 'lucide-react';

interface TechnicianPortalProps {
  orders: BreakdownOrder[];
  receivingAccounts?: PaymentReceivingAccount[];
  language?: AppLanguage;
  onSubmitQuote: (
    orderId: string,
    quotePriceEgp: number,
    etaMinutes: number,
    note: string
  ) => void;
  onUpdateOrderStatus: (
    orderId: string,
    newStatus: BreakdownOrder['status'],
    step: number
  ) => void;
  onTechnicianPayPlatformFee?: (
    orderId: string,
    accountId: string,
    amount: number
  ) => void;
}

type TechnicianView = 'radar' | 'active_job' | 'registration' | 'wallet' | 'profile';

export const TechnicianPortal: React.FC<TechnicianPortalProps> = ({
  orders,
  receivingAccounts,
  language = 'ar',
  onSubmitQuote,
  onUpdateOrderStatus,
  onTechnicianPayPlatformFee,
}) => {
  const t = TRANSLATIONS[language];
  const [currentTech, setCurrentTech] = useState<Technician>(INITIAL_TECHNICIANS[0]);
  const [view, setView] = useState<TechnicianView>('radar');
  const [radarFilter, setRadarFilter] = useState<'all' | 'ride' | 'winch' | 'breakdown'>('all');

  // Availability & Patrol Point
  const [isAvailable, setIsAvailable] = useState(currentTech.isAvailable);
  const [currentPatrolPoint, setCurrentPatrolPoint] = useState(
    'طريق القاهرة - الإسكندرية الصحراوي (نقطة الكيلو ١٠٤ - وادي النطرون)'
  );

  // Quote Submission Form
  const [selectedOrderIdForQuote, setSelectedOrderIdForQuote] = useState<string>('');
  const [quotePriceInput, setQuotePriceInput] = useState<number>(180);
  const [quoteEtaInput, setQuoteEtaInput] = useState<number>(12);
  const [quoteNoteInput, setQuoteNoteInput] = useState(
    'سيارة مكيفة ونظيفة، جاهز للتحرك إليك فوراً.'
  );
  const [quoteSuccessMsg, setQuoteSuccessMsg] = useState(false);

  // Platform Commission Payment Modal
  const [showPayModal, setShowPayModal] = useState(false);
  const [feeAmountToPay, setFeeAmountToPay] = useState<number>(currentTech.commissionDueEgp || 50);
  const [payMethod, setPayMethod] = useState<'instapay' | 'vodafone_cash'>('instapay');
  const [transferRefCode, setTransferRefCode] = useState('');
  const [paymentDoneMsg, setPaymentDoneMsg] = useState(false);

  // Provider Registration Wizard States
  const [regName, setRegName] = useState('');
  const [regPhone, setRegPhone] = useState('');
  const [regNationalId, setRegNationalId] = useState('');
  const [regRole, setRegRole] = useState<ProviderRole>('driver');
  const [regVehicleModel, setRegVehicleModel] = useState('');
  const [regVehiclePlate, setRegVehiclePlate] = useState('');
  const [regZone, setRegZone] = useState('القاهرة الكبرى والجيزة');
  const [regSubmitted, setRegSubmitted] = useState(false);

  // Active Job assigned to this provider
  const activeJob = orders.find(
    (o) =>
      (o.selectedOffer?.technician.id === currentTech.id ||
        (o.technicianPaidPlatformFee && o.status !== 'completed' && o.status !== 'cancelled')) &&
      o.status !== 'completed' &&
      o.status !== 'cancelled'
  ) || orders.find((o) => o.status === 'technician_en_route' || o.status === 'in_progress');

  const selectedOrderForModal = orders.find((o) => o.id === selectedOrderIdForQuote);

  const handleOpenQuoteModal = (order: BreakdownOrder) => {
    setSelectedOrderIdForQuote(order.id);
    setQuotePriceInput(order.suggestedFareEgp || 200);
    setQuoteEtaInput(10);
    setQuoteNoteInput(
      order.orderType === 'ride'
        ? 'تويوتا كورولا حديثة مكيفة، قائد محترف، جاهز للتحرك فوراً.'
        : order.orderType === 'winch'
        ? 'ونش هيدروليك مجهز بكابلات 10 طن جاهز للتحرك فوراً.'
        : 'معي أجهزة فحص وقطع غيار، جاهز لمعالجة العطل ميدانياً.'
    );
  };

  const handleConfirmQuoteSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedOrderIdForQuote) return;
    onSubmitQuote(selectedOrderIdForQuote, quotePriceInput, quoteEtaInput, quoteNoteInput);
    setQuoteSuccessMsg(true);
    setTimeout(() => {
      setQuoteSuccessMsg(false);
      setSelectedOrderIdForQuote('');
    }, 1500);
  };

  const handleProviderRegistration = (e: React.FormEvent) => {
    e.preventDefault();
    if (!regName || !regPhone || !regVehiclePlate) {
      alert(language === 'ar' ? 'يرجى استكمال جميع البيانات الأساسية' : 'Please fill all fields');
      return;
    }

    const newProvider: Technician = {
      id: `tech-${Date.now()}`,
      name: regName.trim(),
      phoneMasked: `${regPhone.slice(0, 3)} **** ${regPhone.slice(-4)}`,
      phoneFull: regPhone.trim(),
      role: regRole,
      verificationStatus: 'pending_review',
      specialtyTitle:
        regRole === 'driver'
          ? 'كابتن نقل وتوصيل ذكي (متقدم جديد)'
          : regRole === 'winch_operator'
          ? 'سائق ونش وإنقاذ سريع (متقدم جديد)'
          : 'فني صيانة وميكانيكا (متقدم جديد)',
      categories:
        regRole === 'driver'
          ? ['smart_ride']
          : regRole === 'winch_operator'
          ? ['winch_desert_rescue']
          : ['mechanics_engine', 'batteries_electric'],
      supportedVehicles: ['جميع الملاكي', 'الدفع الرباعي'],
      coveredZones: [regZone],
      vehicleModel: regVehicleModel || 'مركبة حديثة',
      vehiclePlate: regVehiclePlate,
      rating: 0,
      reviewsCount: 0,
      completedRescues: 0,
      isVerified: false,
      isAvailable: true,
      isDesertEquipped: false,
      walletBalanceEgp: 0,
      totalEarningsEgp: 0,
      commissionDueEgp: 0,
      joinedDate: 'اليوم',
      nationalIdNumber: regNationalId,
      documents: [
        {
          id: `doc-${Date.now()}-1`,
          title: 'رخصة القيادة المهنية / الخاصة',
          refNumber: 'EG-DL-PENDING',
          expiryDate: '٢٠٢٨/٠١',
          status: 'قيد المراجعة',
        },
        {
          id: `doc-${Date.now()}-2`,
          title: 'رخصة تسيير المركبة والفحص الفني',
          refNumber: 'EG-VH-PENDING',
          expiryDate: '٢٠٢٧/٠٦',
          status: 'قيد المراجعة',
        },
      ],
      reviews: [],
    };

    setCurrentTech(newProvider);
    setRegSubmitted(true);
  };

  const handleConfirmPayCommission = (e: React.FormEvent) => {
    e.preventDefault();
    if (!transferRefCode) {
      alert(language === 'ar' ? 'يرجى كتابة رقم العملية أو كود التحويل للتأكيد' : 'Please enter reference code');
      return;
    }

    if (onTechnicianPayPlatformFee && activeJob) {
      onTechnicianPayPlatformFee(activeJob.id, 'acc-instapay-1', feeAmountToPay);
    }

    setCurrentTech((prev) => ({
      ...prev,
      commissionDueEgp: Math.max(0, prev.commissionDueEgp - feeAmountToPay),
      walletBalanceEgp: prev.walletBalanceEgp + feeAmountToPay,
    }));

    setPaymentDoneMsg(true);
    setTimeout(() => {
      setPaymentDoneMsg(false);
      setShowPayModal(false);
      setTransferRefCode('');
    }, 2000);
  };

  // Filter incoming orders for radar
  const filteredOrders = orders.filter((o) => {
    if (radarFilter === 'all') return true;
    return o.orderType === radarFilter;
  });

  return (
    <div className="space-y-6 pb-12 font-sans" dir={language === 'ar' ? 'rtl' : 'ltr'}>
      {/* Top Provider Bar with Verification Badge & Switcher */}
      <div className="bg-slate-900 border border-sky-500/25 rounded-3xl p-5 sm:p-7 text-white shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-5">
        <div className="flex items-start sm:items-center gap-4">
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-amber-500 to-amber-700 text-slate-950 font-black text-xl flex items-center justify-center shrink-0 shadow-lg shadow-amber-500/20">
            {currentTech.name.slice(0, 2)}
          </div>
          <div>
            <div className="flex flex-wrap items-center gap-2">
              <h2 className="text-lg sm:text-xl font-black text-white">{currentTech.name}</h2>
              {currentTech.verificationStatus === 'approved' ? (
                <span className="px-2.5 py-0.5 rounded-full text-[11px] font-black bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 flex items-center gap-1">
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span>{t.approved}</span>
                </span>
              ) : (
                <span className="px-2.5 py-0.5 rounded-full text-[11px] font-black bg-amber-500/20 text-amber-300 border border-amber-500/30 flex items-center gap-1 animate-pulse">
                  <Clock className="w-3.5 h-3.5 text-amber-400" />
                  <span>{t.pendingReview}</span>
                </span>
              )}
            </div>

            <p className="text-xs text-sky-400 font-bold mt-0.5">{currentTech.specialtyTitle}</p>
            <div className="flex flex-wrap items-center gap-3 text-xs text-slate-400 mt-1">
              <span className="flex items-center gap-1 text-amber-400 font-bold">
                <Star className="w-3.5 h-3.5 fill-amber-400" />
                <span>{currentTech.rating || 'جديد'}</span>
              </span>
              <span>•</span>
              <span>{currentTech.completedRescues} {language === 'ar' ? 'عملية منجزة' : 'completed'}</span>
              <span>•</span>
              <span className="text-slate-300 font-mono font-bold">
                {currentTech.vehicleModel} ({currentTech.vehiclePlate})
              </span>
            </div>
          </div>
        </div>

        {/* Quick Tech Switcher & Actions */}
        <div className="flex flex-wrap items-center gap-2 sm:gap-3">
          {/* Switch Demo Provider Role */}
          <select
            value={currentTech.id}
            onChange={(e) => {
              const found = INITIAL_TECHNICIANS.find((t) => t.id === e.target.value);
              if (found) setCurrentTech(found);
            }}
            className="bg-slate-950 border border-slate-700 text-slate-200 text-xs rounded-xl px-3 py-2 font-bold cursor-pointer outline-none focus:border-sky-500"
          >
            {INITIAL_TECHNICIANS.map((t) => (
              <option key={t.id} value={t.id}>
                {t.name} — ({t.role === 'driver' ? 'كابتن نقل' : t.role === 'winch_operator' ? 'ونش إنقاذ' : 'فني ميكانيكا'})
              </option>
            ))}
          </select>

          <button
            type="button"
            onClick={() => setIsAvailable(!isAvailable)}
            className={`min-h-[40px] px-3.5 py-2 rounded-xl text-xs font-black flex items-center gap-1.5 cursor-pointer transition-all ${
              isAvailable
                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                : 'bg-red-500/20 text-red-300 border border-red-500/40'
            }`}
          >
            <span className={`w-2 h-2 rounded-full ${isAvailable ? 'bg-emerald-400 animate-ping' : 'bg-red-400'}`} />
            <span>{isAvailable ? (language === 'ar' ? 'متاح لاستقبال الطلبات' : 'Available') : (language === 'ar' ? 'غير متاح (أوفلاين)' : 'Offline')}</span>
          </button>

          <button
            type="button"
            onClick={() => setView('wallet')}
            className="min-h-[40px] px-3.5 py-2 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 text-xs font-bold flex items-center gap-1.5 cursor-pointer"
          >
            <DollarSign className="w-4 h-4 text-amber-400" />
            <span>{language === 'ar' ? 'المحفظة والعمولات' : 'Wallet'}</span>
          </button>
        </div>
      </div>

      {/* Navigation Sub-Tabs */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
        <button
          type="button"
          onClick={() => setView('radar')}
          className={`p-3 rounded-2xl border text-center transition-all cursor-pointer font-black text-xs flex items-center justify-center gap-2 ${
            view === 'radar'
              ? 'bg-sky-500 text-slate-950 border-sky-400 shadow-md shadow-sky-500/20'
              : 'bg-slate-900 border-slate-800 text-slate-300 hover:bg-slate-800'
          }`}
        >
          <Compass className="w-4 h-4" />
          <span>{language === 'ar' ? 'رادار الطلبات القريبة' : 'Live Radar'}</span>
        </button>

        <button
          type="button"
          onClick={() => setView('active_job')}
          className={`p-3 rounded-2xl border text-center transition-all cursor-pointer font-black text-xs flex items-center justify-center gap-2 ${
            view === 'active_job'
              ? 'bg-sky-500 text-slate-950 border-sky-400 shadow-md shadow-sky-500/20'
              : 'bg-slate-900 border-slate-800 text-slate-300 hover:bg-slate-800'
          }`}
        >
          <Navigation className="w-4 h-4" />
          <span>{language === 'ar' ? 'الرحلة / المهمة النشطة' : 'Active Mission'}</span>
          {activeJob && <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />}
        </button>

        <button
          type="button"
          onClick={() => setView('wallet')}
          className={`p-3 rounded-2xl border text-center transition-all cursor-pointer font-black text-xs flex items-center justify-center gap-2 ${
            view === 'wallet'
              ? 'bg-sky-500 text-slate-950 border-sky-400 shadow-md shadow-sky-500/20'
              : 'bg-slate-900 border-slate-800 text-slate-300 hover:bg-slate-800'
          }`}
        >
          <DollarSign className="w-4 h-4" />
          <span>{language === 'ar' ? 'سداد عمولة المنصة' : 'Pay Commission'}</span>
        </button>

        <button
          type="button"
          onClick={() => setView('registration')}
          className={`p-3 rounded-2xl border text-center transition-all cursor-pointer font-black text-xs flex items-center justify-center gap-2 ${
            view === 'registration'
              ? 'bg-sky-500 text-slate-950 border-sky-400 shadow-md shadow-sky-500/20'
              : 'bg-slate-900 border-slate-800 text-slate-300 hover:bg-slate-800'
          }`}
        >
          <FileText className="w-4 h-4" />
          <span>{language === 'ar' ? 'تسجيل كابتن / فني جديد' : 'Provider Registration'}</span>
        </button>
      </div>

      {/* =====================================================================
          VIEW: RADAR (Incoming Live Orders with inDrive Bidding)
         ===================================================================== */}
      {view === 'radar' && (
        <div className="bg-slate-900 border border-sky-500/25 rounded-3xl p-5 sm:p-7 text-white space-y-6 shadow-xl">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
            <div>
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping" />
                <h3 className="text-lg font-black text-white">
                  {language === 'ar' ? 'بث الطلبات والرحلات اللحظي (Radar Live Feed)' : 'Incoming Requests'}
                </h3>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                {language === 'ar'
                  ? 'اختر الطلب المناسب لمسارك واقترح سعرك للمنافسة مثل inDrive'
                  : 'Select nearby request and submit your bid'}
              </p>
            </div>

            {/* Filter buttons */}
            <div className="flex items-center gap-1.5 bg-slate-950 p-1 rounded-xl border border-slate-800">
              <button
                type="button"
                onClick={() => setRadarFilter('all')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold cursor-pointer ${
                  radarFilter === 'all' ? 'bg-sky-500 text-slate-950' : 'text-slate-400 hover:text-white'
                }`}
              >
                الكل ({orders.length})
              </button>
              <button
                type="button"
                onClick={() => setRadarFilter('ride')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold cursor-pointer ${
                  radarFilter === 'ride' ? 'bg-sky-500 text-slate-950' : 'text-slate-400 hover:text-white'
                }`}
              >
                رحلات ذكية
              </button>
              <button
                type="button"
                onClick={() => setRadarFilter('winch')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold cursor-pointer ${
                  radarFilter === 'winch' ? 'bg-sky-500 text-slate-950' : 'text-slate-400 hover:text-white'
                }`}
              >
                أوناش وإنقاذ
              </button>
              <button
                type="button"
                onClick={() => setRadarFilter('breakdown')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold cursor-pointer ${
                  radarFilter === 'breakdown' ? 'bg-sky-500 text-slate-950' : 'text-slate-400 hover:text-white'
                }`}
              >
                صيانة وأعطال
              </button>
            </div>
          </div>

          {/* Verification check alert */}
          {currentTech.verificationStatus !== 'approved' && (
            <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-amber-200 text-xs flex items-center gap-3">
              <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0" />
              <div>
                <span className="font-bold block text-amber-300">حسابك قيد المراجعة والتدقيق من إدارة المنصة:</span>
                يمكنك معاينة الطلبات، وسيتم تفعيل تقديم العروض فور اعتماد وثائقك من لوحة تحكم المالك.
              </div>
            </div>
          )}

          {/* List of orders on radar */}
          <div className="space-y-4">
            {filteredOrders.map((order) => (
              <div
                key={order.id}
                className="p-5 rounded-2xl bg-slate-950 border border-slate-800 hover:border-sky-500/40 transition-all space-y-4 shadow-md"
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div className="flex items-start gap-3">
                    <div className="w-12 h-12 rounded-2xl bg-sky-500/20 text-sky-400 flex items-center justify-center shrink-0">
                      {order.orderType === 'ride' ? <Car className="w-6 h-6" /> : order.orderType === 'winch' ? <Truck className="w-6 h-6" /> : <Wrench className="w-6 h-6" />}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-black text-sm text-white">{order.serviceTitle}</span>
                        <span className="text-[11px] font-mono px-2 py-0.5 rounded-md bg-slate-800 text-sky-300">
                          #{order.orderCode}
                        </span>
                        <span className="text-[10px] text-slate-400 font-mono">{order.createdAt}</span>
                      </div>

                      <div className="text-xs text-slate-300 mt-1 flex items-center gap-1.5">
                        <MapPin className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                        <span>من: {order.pickupAddress || order.location.roadName}</span>
                      </div>

                      {order.destinationAddress && (
                        <div className="text-xs text-slate-400 mt-0.5 flex items-center gap-1.5">
                          <Navigation className="w-3.5 h-3.5 text-sky-400 shrink-0" />
                          <span>إلى: {order.destinationAddress}</span>
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="text-right sm:text-left font-mono">
                    <div className="text-xs text-slate-400">سعر العميل المقترح:</div>
                    <div className="text-xl font-black text-amber-400">
                      {order.suggestedFareEgp || 180} {t.currency}
                    </div>
                  </div>
                </div>

                <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-slate-800/80">
                  <div className="text-xs text-slate-400">
                    طريقة الدفع المتوقعة: <span className="font-bold text-slate-200">{order.paymentMethod === 'cash' ? 'نقدي (كاش)' : 'إلكتروني / إنستاباي'}</span>
                  </div>

                  <button
                    type="button"
                    onClick={() => handleOpenQuoteModal(order)}
                    className="min-h-[42px] px-5 py-2 rounded-xl bg-sky-500 hover:bg-sky-400 text-slate-950 font-black text-xs flex items-center gap-1.5 cursor-pointer shadow-md shadow-sky-500/20"
                  >
                    <Send className="w-4 h-4" />
                    <span>تقديم عرض سعر وتفاوض</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* =====================================================================
          MODAL: SUBMIT BID / QUOTE TO CUSTOMER
         ===================================================================== */}
      {selectedOrderIdForQuote && selectedOrderForModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-sky-500/30 rounded-3xl w-full max-w-lg p-6 text-white space-y-5 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2 text-sky-400 font-black text-sm">
                <Send className="w-5 h-5" />
                <span>تقديم عرض الكابتن / الفني للعميل</span>
              </div>
              <button
                type="button"
                onClick={() => setSelectedOrderIdForQuote('')}
                className="text-slate-400 hover:text-white cursor-pointer"
              >
                ✕
              </button>
            </div>

            {quoteSuccessMsg ? (
              <div className="p-4 rounded-2xl bg-emerald-500/20 text-emerald-300 text-center font-bold text-xs">
                تم إرسال عرضك بنجاح للعميل، سيتم إشعارك فور القبول!
              </div>
            ) : (
              <form onSubmit={handleConfirmQuoteSubmit} className="space-y-4">
                <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-xs space-y-1">
                  <div className="text-slate-400">الطلب: {selectedOrderForModal.serviceTitle}</div>
                  <div className="text-amber-400 font-bold">
                    سعر العميل المقترح: {selectedOrderForModal.suggestedFareEgp || 180} {t.currency}
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs font-bold text-slate-300 block mb-1">
                      سعرك المعروض (جنيه):
                    </label>
                    <input
                      type="number"
                      required
                      min={30}
                      max={3000}
                      value={quotePriceInput}
                      onChange={(e) => setQuotePriceInput(Number(e.target.value))}
                      className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-2.5 text-xs text-white focus:border-sky-500 outline-none font-mono font-bold"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-bold text-slate-300 block mb-1">
                      وقت الوصول المتوقع (دقيقة):
                    </label>
                    <input
                      type="number"
                      required
                      min={2}
                      max={120}
                      value={quoteEtaInput}
                      onChange={(e) => setQuoteEtaInput(Number(e.target.value))}
                      className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-2.5 text-xs text-white focus:border-sky-500 outline-none font-mono font-bold"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-300 block mb-1">
                    رسالتك وملاحظتك للعميل:
                  </label>
                  <textarea
                    rows={2}
                    value={quoteNoteInput}
                    onChange={(e) => setQuoteNoteInput(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-3 text-xs text-white focus:border-sky-500 outline-none resize-none"
                  />
                </div>

                <div className="flex gap-3 pt-2">
                  <button
                    type="submit"
                    className="flex-1 min-h-[46px] rounded-xl bg-sky-500 hover:bg-sky-400 text-slate-950 font-black text-xs cursor-pointer shadow-lg shadow-sky-500/20"
                  >
                    إرسال العرض للعميل
                  </button>
                  <button
                    type="button"
                    onClick={() => setSelectedOrderIdForQuote('')}
                    className="px-4 rounded-xl bg-slate-800 text-slate-300 text-xs font-bold cursor-pointer"
                  >
                    إلغاء
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}

      {/* =====================================================================
          VIEW: ACTIVE JOB & MISSION WORKFLOW
         ===================================================================== */}
      {view === 'active_job' && (
        <div className="bg-slate-900 border border-sky-500/25 rounded-3xl p-5 sm:p-7 text-white space-y-6 shadow-xl">
          {activeJob ? (
            <div className="space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
                    <h3 className="text-lg font-black text-white">
                      {language === 'ar' ? 'المهمة الجارية حالياً' : 'Current Active Mission'}
                    </h3>
                    <span className="text-xs text-sky-400 font-mono">#{activeJob.orderCode}</span>
                  </div>
                  <p className="text-xs text-slate-400 mt-0.5">{activeJob.serviceTitle}</p>
                </div>

                <div className="text-left font-mono">
                  <span className="text-xs text-slate-400 block">المبلغ المتفق عليه:</span>
                  <span className="text-xl font-black text-emerald-400">
                    {activeJob.repairCostAgreedEgp || activeJob.suggestedFareEgp || 200} {t.currency}
                  </span>
                </div>
              </div>

              {/* Customer Details & Contact */}
              <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div className="space-y-1">
                  <div className="font-bold text-sm text-white">العميل: {activeJob.customerName}</div>
                  <div className="text-xs text-slate-300 flex items-center gap-2">
                    <MapPin className="w-3.5 h-3.5 text-emerald-400" />
                    <span>{activeJob.pickupAddress || activeJob.location.roadName}</span>
                  </div>
                  <div className="text-xs text-sky-400 font-mono">{activeJob.customerPhone}</div>
                </div>

                <div className="flex items-center gap-2">
                  <a
                    href={`tel:${activeJob.customerPhone}`}
                    className="min-h-[42px] px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow"
                  >
                    <Phone className="w-4 h-4" />
                    <span>اتصال بالعميل</span>
                  </a>

                  <button
                    type="button"
                    onClick={() => {
                      alert(`فتح الملاحة وتوجيه GPS إلى: ${activeJob.pickupAddress || activeJob.location.roadName}`);
                    }}
                    className="min-h-[42px] px-4 py-2 rounded-xl bg-sky-500 hover:bg-sky-400 text-slate-950 text-xs font-black flex items-center gap-1.5 cursor-pointer"
                  >
                    <Navigation className="w-4 h-4" />
                    <span>بدء الملاحة</span>
                  </button>
                </div>
              </div>

              {/* Status progression buttons */}
              <div className="space-y-3">
                <label className="text-xs font-bold text-slate-300 block">
                  تحديث حالة الرحلة / المهمة للعميل والمنصة:
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                  <button
                    type="button"
                    onClick={() => onUpdateOrderStatus(activeJob.id, 'technician_en_route', 1)}
                    className={`p-3 rounded-xl border text-center transition-all cursor-pointer font-bold text-xs ${
                      activeJob.trackingStep === 1
                        ? 'bg-sky-500 text-slate-950 border-sky-400'
                        : 'bg-slate-950 border-slate-800 text-slate-300'
                    }`}
                  >
                    ١. في الطريق للعميل
                  </button>

                  <button
                    type="button"
                    onClick={() => onUpdateOrderStatus(activeJob.id, 'technician_arrived', 2)}
                    className={`p-3 rounded-xl border text-center transition-all cursor-pointer font-bold text-xs ${
                      activeJob.trackingStep === 2
                        ? 'bg-sky-500 text-slate-950 border-sky-400'
                        : 'bg-slate-950 border-slate-800 text-slate-300'
                    }`}
                  >
                    ٢. وصلت لموقع العميل
                  </button>

                  <button
                    type="button"
                    onClick={() => onUpdateOrderStatus(activeJob.id, 'in_progress', 3)}
                    className={`p-3 rounded-xl border text-center transition-all cursor-pointer font-bold text-xs ${
                      activeJob.trackingStep === 3
                        ? 'bg-amber-500 text-slate-950 border-amber-400'
                        : 'bg-slate-950 border-slate-800 text-slate-300'
                    }`}
                  >
                    ٣. بدء التحرك / الإصلاح
                  </button>

                  <button
                    type="button"
                    onClick={() => onUpdateOrderStatus(activeJob.id, 'completed', 4)}
                    className={`p-3 rounded-xl border text-center transition-all cursor-pointer font-bold text-xs ${
                      activeJob.trackingStep === 4
                        ? 'bg-emerald-500 text-slate-950 border-emerald-400'
                        : 'bg-slate-950 border-slate-800 text-slate-300'
                    }`}
                  >
                    ٤. إتمام وتحصيل الأجرة
                  </button>
                </div>
              </div>
            </div>
          ) : (
            <div className="text-center py-12 space-y-3">
              <CheckCircle2 className="w-12 h-12 text-slate-600 mx-auto" />
              <p className="text-sm font-bold text-slate-300">لا توجد مهمة نشطة حالياً</p>
              <p className="text-xs text-slate-500">
                توجه إلى رادار الطلبات لتقديم عروض الأسعار وقبول مشاوير جديدة
              </p>
              <button
                type="button"
                onClick={() => setView('radar')}
                className="px-5 py-2 rounded-xl bg-sky-500 text-slate-950 font-black text-xs cursor-pointer shadow"
              >
                فتح رادار الطلبات
              </button>
            </div>
          )}
        </div>
      )}

      {/* =====================================================================
          VIEW: WALLET & PLATFORM COMMISSION MANAGEMENT
         ===================================================================== */}
      {view === 'wallet' && (
        <div className="bg-slate-900 border border-sky-500/25 rounded-3xl p-5 sm:p-7 text-white space-y-6 shadow-xl">
          <div className="flex items-center justify-between border-b border-slate-800 pb-4">
            <div>
              <h3 className="text-lg font-black text-white">
                {language === 'ar' ? 'محفظة الكابتن / الفني وعمولات المنصة' : 'Provider Wallet'}
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                {language === 'ar'
                  ? 'متابعة الأرباح الإجمالية وسداد مستحقات وعمولات المنصة مباشرة لحساب المالك'
                  : 'Track earnings and settle platform commission'}
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800">
              <div className="text-xs text-slate-400">إجمالي الأرباح المستلمة:</div>
              <div className="text-2xl font-black text-white mt-1 font-mono">
                {currentTech.totalEarningsEgp} <span className="text-xs text-sky-400">{t.currency}</span>
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800">
              <div className="text-xs text-slate-400">رصيد المحفظة المتاح:</div>
              <div className="text-2xl font-black text-emerald-400 mt-1 font-mono">
                {currentTech.walletBalanceEgp} <span className="text-xs text-emerald-400">{t.currency}</span>
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-slate-950 border border-amber-500/30">
              <div className="text-xs text-amber-300 font-bold">العمولة المستحقة للمنصة:</div>
              <div className="text-2xl font-black text-amber-400 mt-1 font-mono">
                {currentTech.commissionDueEgp} <span className="text-xs text-amber-400">{t.currency}</span>
              </div>
            </div>
          </div>

          {/* Settle Commission Button */}
          <div className="p-5 rounded-2xl bg-gradient-to-r from-sky-950/60 to-slate-950 border border-sky-500/30 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <div className="font-black text-sm text-white">
                  سداد عمولة المنصة مباشرة عبر إنستاباي أو فودافون كاش
                </div>
                <div className="text-xs text-slate-300 mt-0.5">
                  تُحول العمولات لحساب المالك المعتمد للحفاظ على الحساب نشطاً وتجنب الإيقاف المؤقت.
                </div>
              </div>

              <button
                type="button"
                onClick={() => setShowPayModal(true)}
                className="px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs cursor-pointer shadow-lg shadow-amber-500/20"
              >
                سداد العمولة الآن ({currentTech.commissionDueEgp} ج.م)
              </button>
            </div>
          </div>
        </div>
      )}

      {/* =====================================================================
          MODAL: PAY PLATFORM COMMISSION TO OWNER DIRECTLY
         ===================================================================== */}
      {showPayModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-amber-500/30 rounded-3xl w-full max-w-md p-6 text-white space-y-5 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2 text-amber-400 font-black text-sm">
                <DollarSign className="w-5 h-5" />
                <span>سداد عمولة المنصة لمالك التطبيق</span>
              </div>
              <button
                type="button"
                onClick={() => setShowPayModal(false)}
                className="text-slate-400 hover:text-white cursor-pointer"
              >
                ✕
              </button>
            </div>

            {paymentDoneMsg ? (
              <div className="p-4 rounded-2xl bg-emerald-500/20 text-emerald-300 text-center font-bold text-xs">
                تم تسجيل عملية التحويل وسداد العمولة وتحديث رصيد محفظتك فورياً!
              </div>
            ) : (
              <form onSubmit={handleConfirmPayCommission} className="space-y-4">
                <div>
                  <label className="text-xs font-bold text-slate-300 block mb-1">
                    اختر وسيلة التحويل لحساب المالك:
                  </label>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => setPayMethod('instapay')}
                      className={`p-3 rounded-xl border text-center text-xs font-bold cursor-pointer ${
                        payMethod === 'instapay'
                          ? 'bg-sky-500/20 border-sky-400 text-white'
                          : 'bg-slate-950 border-slate-800 text-slate-400'
                      }`}
                    >
                      إنستاباي (InstaPay)
                    </button>
                    <button
                      type="button"
                      onClick={() => setPayMethod('vodafone_cash')}
                      className={`p-3 rounded-xl border text-center text-xs font-bold cursor-pointer ${
                        payMethod === 'vodafone_cash'
                          ? 'bg-red-500/20 border-red-400 text-white'
                          : 'bg-slate-950 border-slate-800 text-slate-400'
                      }`}
                    >
                      فودافون كاش
                    </button>
                  </div>
                </div>

                {/* Display Owner Destination Account */}
                <div className="p-3.5 rounded-2xl bg-slate-950 border border-sky-500/30 text-xs space-y-1.5">
                  <span className="text-slate-400 block text-[11px]">بيانات حساب المالك المعتمدة للاستقبال:</span>
                  {payMethod === 'instapay' ? (
                    <div className="space-y-1">
                      <div className="text-sky-300 font-mono font-bold text-sm">
                        yasmine.rescue@instapay
                      </div>
                      <div className="text-slate-300">الاسم: م. محمد صلاح (مؤسس المنصة)</div>
                      <div className="text-slate-400 text-[10px]">البنك التجاري الدولي (CIB)</div>
                    </div>
                  ) : (
                    <div className="space-y-1">
                      <div className="text-red-400 font-mono font-bold text-sm">
                        01004829391
                      </div>
                      <div className="text-slate-300">محفظة فودافون كاش الرسمية للمنصة</div>
                    </div>
                  )}
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-300 block mb-1">
                    المبلغ المراد سداده (جنيه):
                  </label>
                  <input
                    type="number"
                    value={feeAmountToPay}
                    onChange={(e) => setFeeAmountToPay(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-2.5 text-xs text-white outline-none font-mono font-bold"
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-300 block mb-1">
                    رقم العملية المرجعي / كود التحويل:
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="مثال: REF-984102 أو كود إشعار البنك"
                    value={transferRefCode}
                    onChange={(e) => setTransferRefCode(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-2.5 text-xs text-white outline-none font-mono"
                  />
                </div>

                <div className="flex gap-3 pt-2">
                  <button
                    type="submit"
                    className="flex-1 min-h-[46px] rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs cursor-pointer shadow"
                  >
                    تأكيد السداد وتحديث المحفظة
                  </button>
                  <button
                    type="button"
                    onClick={() => setShowPayModal(false)}
                    className="px-4 rounded-xl bg-slate-800 text-slate-300 text-xs font-bold cursor-pointer"
                  >
                    إلغاء
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}

      {/* =====================================================================
          VIEW: PROVIDER REGISTRATION WIZARD (Driver / Tech Onboarding)
         ===================================================================== */}
      {view === 'registration' && (
        <div className="bg-slate-900 border border-sky-500/25 rounded-3xl p-5 sm:p-7 text-white space-y-6 shadow-xl">
          <div className="border-b border-slate-800 pb-4">
            <h3 className="text-lg font-black text-white">
              {language === 'ar' ? 'انضم إلى أسطول الياسمين جو (سائقين • فنيين • أوناش)' : 'Join YASMIN GO Providers'}
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              {language === 'ar'
                ? 'سجل بياناتك ومستنداتك الرسمية، وسيتم فحصها واعتمادها من الإدارة قبل تفعيل حسابك'
                : 'Register your vehicle, documents and profile for admin review'}
            </p>
          </div>

          {regSubmitted ? (
            <div className="text-center py-10 space-y-4">
              <div className="w-14 h-14 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto">
                <CheckCircle2 className="w-8 h-8" />
              </div>
              <h4 className="text-lg font-black text-white">
                تم تسجيل طلبك بنجاح وهو الآن «قيد المراجعة والتدقيق»!
              </h4>
              <p className="text-xs text-slate-300 max-w-md mx-auto leading-relaxed">
                سيقوم فريق الإدارة بمراجعة رخصة القيادة والسيارة والرقم القومي، وستصلك رسالة SMS فور التفعيل لتبدأ في جني الأرباح فورياً.
              </p>
              <button
                type="button"
                onClick={() => setView('radar')}
                className="px-5 py-2.5 rounded-xl bg-sky-500 text-slate-950 font-black text-xs cursor-pointer shadow"
              >
                معاينة لوحة الكابتن
              </button>
            </div>
          ) : (
            <form onSubmit={handleProviderRegistration} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-bold text-slate-300 block mb-1">الاسم الكامل:</label>
                  <input
                    type="text"
                    required
                    value={regName}
                    onChange={(e) => setRegName(e.target.value)}
                    placeholder="محمد مصطفى الشناوي"
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-2.5 text-xs text-white outline-none focus:border-sky-500"
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-300 block mb-1">رقم المحمول (مصر):</label>
                  <input
                    type="tel"
                    required
                    value={regPhone}
                    onChange={(e) => setRegPhone(e.target.value)}
                    placeholder="01019284102"
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-2.5 text-xs text-white outline-none focus:border-sky-500 font-mono"
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-300 block mb-1">الرقم القومي (١٤ رقم):</label>
                  <input
                    type="text"
                    required
                    maxLength={14}
                    value={regNationalId}
                    onChange={(e) => setRegNationalId(e.target.value)}
                    placeholder="29010151203491"
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-2.5 text-xs text-white outline-none focus:border-sky-500 font-mono"
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-300 block mb-1">تخصص الخدمة:</label>
                  <select
                    value={regRole}
                    onChange={(e) => setRegRole(e.target.value as ProviderRole)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-2.5 text-xs text-white outline-none focus:border-sky-500 cursor-pointer"
                  >
                    <option value="driver">كابتن نقل وتوصيل ذكي (ملاكي / فان)</option>
                    <option value="winch_operator">سائق ونش إنقاذ وسحب هيدروليك</option>
                    <option value="mechanic">فني ميكانيكا محركات وصيانة ميدانية</option>
                    <option value="tire_battery">فني بطاريات وكاوتش متنقل</option>
                  </select>
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-300 block mb-1">نوع وموديل المركبة:</label>
                  <input
                    type="text"
                    required
                    value={regVehicleModel}
                    onChange={(e) => setRegVehicleModel(e.target.value)}
                    placeholder="تويوتا كورولا 2022 / ونش إيسوزو"
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-2.5 text-xs text-white outline-none focus:border-sky-500"
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-300 block mb-1">رقم لوحة المركبة (أرقام وحروف):</label>
                  <input
                    type="text"
                    required
                    value={regVehiclePlate}
                    onChange={(e) => setRegVehiclePlate(e.target.value)}
                    placeholder="أ ب ج ١٢٣٤"
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-2.5 text-xs text-white outline-none focus:border-sky-500"
                  />
                </div>
              </div>

              {/* Upload simulation */}
              <div className="pt-2 space-y-2">
                <label className="text-xs font-bold text-slate-300 block">
                  المستندات المطلوبة (صورة البطاقة، رخصة القيادة، رخصة السيارة):
                </label>
                <div className="p-4 border-2 border-dashed border-slate-700 rounded-2xl text-center space-y-2 bg-slate-950/50">
                  <Upload className="w-8 h-8 text-sky-400 mx-auto" />
                  <div className="text-xs text-slate-300 font-bold">
                    انقر لرفع صور المستندات أو اسحبها هنا
                  </div>
                  <div className="text-[10px] text-slate-500">
                    يدعم JPG و PNG و PDF بحجم حتى 10 ميجابايت
                  </div>
                </div>
              </div>

              <button
                type="submit"
                className="w-full min-h-[48px] rounded-2xl bg-gradient-to-r from-sky-500 to-sky-600 hover:from-sky-400 hover:to-sky-500 text-slate-950 font-black text-sm cursor-pointer shadow-lg shadow-sky-500/20"
              >
                إرسال الطلب للمراجعة والاعتماد
              </button>
            </form>
          )}
        </div>
      )}
    </div>
  );
};
