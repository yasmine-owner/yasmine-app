import React, { useState, useEffect } from 'react';
import {
  PortalType,
  BreakdownOrder,
  PaymentReceivingAccount,
  AppLanguage,
} from './types/yasmine';
import { INITIAL_ORDERS, INITIAL_RECEIVING_ACCOUNTS } from './data/mockData';
import { TRANSLATIONS } from './data/translations';
import { YasmineLogo } from './components/common/BrandComponents';
import { CustomerPortal } from './components/customer/CustomerPortal';
import { TechnicianPortal } from './components/technician/TechnicianPortal';
import { OwnerPortal } from './components/owner/OwnerPortal';
import { RoadmapAndTechGuide } from './components/architecture/RoadmapAndTechGuide';
import { InstallGuideModal } from './components/common/InstallGuideModal';
import {
  Smartphone,
  Wrench,
  LayoutDashboard,
  Layers,
  AlertTriangle,
  Phone,
  X,
  Share2,
  Check,
  ShieldCheck,
  Zap,
  Lock,
  Unlock,
  Copy,
  ExternalLink,
  Globe,
  Sliders,
  Crown,
  Car,
  Truck,
  Sparkles,
  Info,
  Download,
  FolderArchive,
} from 'lucide-react';

export type AppDisplayMode = 'public_app' | 'owner_dashboard' | 'developer_guide';

export default function App() {
  const [language, setLanguage] = useState<AppLanguage>(() => {
    try {
      const stored = localStorage.getItem('yasmin_lang');
      if (stored === 'en' || stored === 'ar') return stored;
    } catch {}
    return 'ar';
  });

  const t = TRANSLATIONS[language];

  const toggleLanguage = () => {
    const next = language === 'ar' ? 'en' : 'ar';
    setLanguage(next);
    try {
      localStorage.setItem('yasmin_lang', next);
    } catch {}
  };

  const getModeFromUrl = (): { mode: AppDisplayMode; portal: PortalType } => {
    try {
      if (typeof window !== 'undefined') {
        const searchParams = new URLSearchParams(window.location.search);
        const hashRaw = window.location.hash.replace(/^#\/?/, '');
        const hashParams = new URLSearchParams(hashRaw.includes('=') ? hashRaw : '');

        const view =
          searchParams.get('view') ||
          searchParams.get('portal') ||
          searchParams.get('role') ||
          hashParams.get('view') ||
          hashRaw;

        // Owner Dashboard is completely isolated!
        if (view === 'owner' || view === 'admin' || view === 'boss') {
          return { mode: 'owner_dashboard', portal: 'owner' };
        }
        if (view === 'guide' || view === 'dev' || view === 'architecture') {
          return { mode: 'developer_guide', portal: 'architecture' };
        }
        if (view === 'technician' || view === 'driver') {
          return { mode: 'public_app', portal: 'technician' };
        }
      }
    } catch {}
    // Default mode: 100% public app (Customer & Driver only)
    return { mode: 'public_app', portal: 'customer' };
  };

  const initial = getModeFromUrl();
  const [displayMode, setDisplayMode] = useState<AppDisplayMode>(initial.mode);
  const [activePortal, setActivePortal] = useState<PortalType>(initial.portal);

  // Sync mode and portal with browser URL and listen for hash/popstate
  useEffect(() => {
    const handleUrlChange = () => {
      const current = getModeFromUrl();
      setDisplayMode(current.mode);
      setActivePortal(current.portal);
    };

    window.addEventListener('popstate', handleUrlChange);
    window.addEventListener('hashchange', handleUrlChange);
    return () => {
      window.removeEventListener('popstate', handleUrlChange);
      window.removeEventListener('hashchange', handleUrlChange);
    };
  }, []);

  const changeDisplayMode = (mode: AppDisplayMode, portal?: PortalType) => {
    setDisplayMode(mode);
    if (portal) setActivePortal(portal);
    if (typeof window !== 'undefined') {
      try {
        const url = new URL(window.location.href);
        if (mode === 'public_app') {
          if (portal === 'technician') {
            url.searchParams.set('view', 'technician');
          } else {
            url.searchParams.delete('view');
          }
        } else if (mode === 'owner_dashboard') {
          url.searchParams.set('view', 'owner');
        } else if (mode === 'developer_guide') {
          url.searchParams.set('view', 'guide');
        }
        window.history.replaceState({}, '', url.toString());
      } catch {}
    }
  };

  // Orders state with local storage persistence
  const [orders, setOrders] = useState<BreakdownOrder[]>(() => {
    try {
      const stored = localStorage.getItem('yasmine_orders');
      if (stored) return JSON.parse(stored);
    } catch {}
    return INITIAL_ORDERS;
  });

  const [showSOSModal, setShowSOSModal] = useState(false);
  const [showInstallGuideModal, setShowInstallGuideModal] = useState(false);
  const [copiedType, setCopiedType] = useState<string | null>(null);

  // Native PWA Install Prompt State
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [isStandaloneApp, setIsStandaloneApp] = useState(false);

  useEffect(() => {
    if (
      typeof window !== 'undefined' &&
      (window.matchMedia('(display-mode: standalone)').matches ||
        (window.navigator as any).standalone === true)
    ) {
      setIsStandaloneApp(true);
    }

    const handleBeforeInstall = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e);
    };

    const handleAppInstalled = () => {
      setIsStandaloneApp(true);
      setDeferredPrompt(null);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstall);
    window.addEventListener('appinstalled', handleAppInstalled);

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstall);
      window.removeEventListener('appinstalled', handleAppInstalled);
    };
  }, []);

  const handleTriggerNativeInstall = async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      try {
        const { outcome } = await deferredPrompt.userChoice;
        if (outcome === 'accepted') {
          setIsStandaloneApp(true);
        }
      } catch {}
      setDeferredPrompt(null);
    } else {
      setShowInstallGuideModal(true);
    }
  };

  // Receiving accounts managed by the Owner (persisted & synced)
  const [receivingAccounts, setReceivingAccounts] = useState<PaymentReceivingAccount[]>(() => {
    try {
      const stored = localStorage.getItem('yasmine_receiving_accounts');
      if (stored) return JSON.parse(stored);
    } catch {}
    return INITIAL_RECEIVING_ACCOUNTS;
  });

  // Cross-tab real-time sync listener
  useEffect(() => {
    const handleStorageChange = (e: StorageEvent) => {
      if (e.key === 'yasmine_receiving_accounts' && e.newValue) {
        try {
          setReceivingAccounts(JSON.parse(e.newValue));
        } catch {}
      }
      if (e.key === 'yasmine_orders' && e.newValue) {
        try {
          setOrders(JSON.parse(e.newValue));
        } catch {}
      }
    };
    window.addEventListener('storage', handleStorageChange);
    return () => window.removeEventListener('storage', handleStorageChange);
  }, []);

  const handleUpdateReceivingAccounts = (newAccounts: PaymentReceivingAccount[]) => {
    setReceivingAccounts(newAccounts);
    try {
      localStorage.setItem('yasmine_receiving_accounts', JSON.stringify(newAccounts));
    } catch {}
  };

  const updateOrdersAndPersist = (updater: (prev: BreakdownOrder[]) => BreakdownOrder[]) => {
    setOrders((prev) => {
      const next = updater(prev);
      try {
        localStorage.setItem('yasmine_orders', JSON.stringify(next));
      } catch {}
      return next;
    });
  };

  const handleCreateOrder = (newOrder: BreakdownOrder) => {
    updateOrdersAndPersist((prev) => [newOrder, ...prev]);
  };

  const handleUpdateOrder = (updatedOrder: BreakdownOrder) => {
    updateOrdersAndPersist((prev) =>
      prev.map((o) => (o.id === updatedOrder.id ? updatedOrder : o))
    );
  };

  const handleTechnicianSubmitQuote = (
    orderId: string,
    quotePriceEgp: number,
    etaMinutes: number,
    note: string
  ) => {
    updateOrdersAndPersist((prev) =>
      prev.map((o) => {
        if (o.id === orderId) {
          return {
            ...o,
            status: 'pending_offers',
          };
        }
        return o;
      })
    );
  };

  const handleTechnicianPayPlatformFee = (
    orderId: string,
    accountId: string,
    feeAmount: number = 35
  ) => {
    updateOrdersAndPersist((prev) =>
      prev.map((o) => {
        if (o.id === orderId) {
          return {
            ...o,
            technicianPaidPlatformFee: true,
            locationRevealed: true,
            status: 'technician_en_route',
            trackingStep: 2,
          };
        }
        return o;
      })
    );

    setReceivingAccounts((prev) => {
      const updated = prev.map((acc) => {
        if (acc.id === accountId || (!accountId && acc.isDefault)) {
          return {
            ...acc,
            totalCollectedEgp: (acc.totalCollectedEgp || 0) + feeAmount,
            updatedAt: 'الآن',
          };
        }
        return acc;
      });
      try {
        localStorage.setItem('yasmine_receiving_accounts', JSON.stringify(updated));
      } catch {}
      return updated;
    });
  };

  const handleTechnicianUpdateStatus = (
    orderId: string,
    newStatus: BreakdownOrder['status'],
    step: number
  ) => {
    updateOrdersAndPersist((prev) =>
      prev.map((o) =>
        o.id === orderId ? { ...o, status: newStatus, trackingStep: step } : o
      )
    );
  };

  const currentOrigin =
    typeof window !== 'undefined'
      ? window.location.origin
      : 'https://ais-dev-oh34kbidnyqsw3p72bxc6f-561396168334.europe-west3.run.app';
  const ownerDashboardUrl = `${currentOrigin}/?view=owner`;

  return (
    <div
      className="min-h-screen bg-[#07111E] text-slate-900 antialiased flex flex-col font-sans"
      dir={language === 'ar' ? 'rtl' : 'ltr'}
    >
      {/* =====================================================================
          NATIVE MOBILE APP INSTALL PROMPT BAR (Chrome / Android / iOS)
         ===================================================================== */}
      {!isStandaloneApp && (
        <div className="bg-gradient-to-r from-sky-950 via-slate-900 to-sky-950 border-b border-sky-500/40 px-3 sm:px-6 py-2.5 text-white">
          <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2.5 text-xs">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-sky-400 animate-pulse shrink-0" />
              <span className="font-black text-sky-300">
                تثبيت «الياسمين جو» كتطبيق رسمي على هاتفك:
              </span>
              <span className="text-slate-300 text-[11px] sm:text-xs">
                يعمل كتطبيق كامل ومستقل بملء الشاشة بدون متصفح وبدون شريط روابط.
              </span>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              <button
                type="button"
                onClick={handleTriggerNativeInstall}
                className="px-4 py-1.5 rounded-xl bg-gradient-to-r from-sky-400 to-sky-500 hover:from-sky-300 hover:to-sky-400 text-slate-950 font-black text-xs flex items-center gap-1.5 shadow-md shadow-sky-500/30 cursor-pointer transition-all active:scale-95"
              >
                <Smartphone className="w-3.5 h-3.5" />
                <span>{deferredPrompt ? 'تثبيت التطبيق الآن على الهاتف' : 'طريقة التثبيت على الهاتف'}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* =====================================================================
          ONE-CLICK ZIP DOWNLOAD BANNER (For Google Repositories Upload)
         ===================================================================== */}
      <div className="bg-gradient-to-r from-emerald-950 via-slate-950 to-emerald-950 border-b border-emerald-500/30 px-3 sm:px-6 py-2 text-white">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2.5 text-xs">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping shrink-0" />
            <span className="font-black text-emerald-300">
              ملفات المشروع جاهزة ومضغوطة للتحميل:
            </span>
            <span className="text-slate-300 hidden md:inline">
              تحميل الكود بالكامل كملف ZIP لرفعه على مستودعات جوجل (Google Cloud / GitHub)
            </span>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={() => setShowInstallGuideModal(true)}
              className="px-3.5 py-1.5 rounded-xl bg-sky-500/20 hover:bg-sky-500/30 text-sky-300 border border-sky-500/40 font-bold text-xs flex items-center gap-1.5 cursor-pointer"
            >
              <Smartphone className="w-3.5 h-3.5 text-sky-400" />
              <span>📲 روابط وطريقة التثبيت على الموبايل</span>
            </button>

            <a
              href="/yasmin-go-app.zip"
              download="yasmin-go-app.zip"
              className="px-4 py-1.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs flex items-center gap-1.5 shadow-md shadow-emerald-500/20 transition-all cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>تحميل كود المشروع (.ZIP)</span>
            </a>

            {displayMode === 'public_app' ? (
              <button
                type="button"
                onClick={() => changeDisplayMode('owner_dashboard', 'owner')}
                className="px-3 py-1.5 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 font-bold text-xs flex items-center gap-1 cursor-pointer"
                title="لوحة المالك الخاصة بالمهندس محمد صلاح"
              >
                <Crown className="w-3.5 h-3.5 text-amber-400" />
                <span>دخول المالك</span>
              </button>
            ) : (
              <button
                type="button"
                onClick={() => changeDisplayMode('public_app', 'customer')}
                className="px-3 py-1.5 rounded-xl bg-sky-500/20 hover:bg-sky-500/30 text-sky-300 border border-sky-500/40 font-bold text-xs flex items-center gap-1 cursor-pointer"
              >
                <Smartphone className="w-3.5 h-3.5" />
                <span>معاينة تطبيق الجمهور</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* =====================================================================
          TOP NAVIGATION BAR (Strictly separated based on displayMode)
         ===================================================================== */}
      <header className="sticky top-0 z-40 bg-[#0B192C]/95 backdrop-blur-md border-b border-sky-500/25 px-4 sm:px-8 py-3 flex items-center justify-between gap-4">
        {/* Zone 1: Wordmark & Logo */}
        <div className="flex items-center gap-3 whitespace-nowrap shrink-0">
          <YasmineLogo size="sm" variant="dark" showSubtitle language={language} />

          {displayMode === 'owner_dashboard' && (
            <span className="text-[11px] font-black text-amber-300 bg-amber-500/15 border border-amber-500/30 px-2.5 py-0.5 rounded-lg flex items-center gap-1 shadow-sm">
              <Crown className="w-3.5 h-3.5 text-amber-400" />
              <span>لوحة المالك المستقلة (بقيادة المهندس محمد صلاح)</span>
            </span>
          )}
        </div>

        {/* Zone 2: Navigation Links (IN PUBLIC MODE: ONLY Customer & Driver are visible!) */}
        <nav className="flex items-center gap-3 sm:gap-6 text-xs font-black text-slate-300">
          {displayMode === 'public_app' ? (
            // PUBLIC APP: Customer & Driver ONLY! No Owner Dashboard link!
            <div className="flex items-center gap-2 sm:gap-3 bg-slate-950/80 p-1 rounded-2xl border border-sky-500/20">
              <button
                type="button"
                onClick={() => setActivePortal('customer')}
                className={`px-3.5 py-1.5 rounded-xl transition-all cursor-pointer flex items-center gap-1.5 ${
                  activePortal === 'customer'
                    ? 'bg-sky-500 text-slate-950 shadow-md shadow-sky-500/20'
                    : 'text-slate-300 hover:text-white'
                }`}
              >
                <Smartphone className="w-3.5 h-3.5" />
                <span>١. واجهة العميل (طلب مشوار / ونش)</span>
              </button>

              <button
                type="button"
                onClick={() => setActivePortal('technician')}
                className={`px-3.5 py-1.5 rounded-xl transition-all cursor-pointer flex items-center gap-1.5 ${
                  activePortal === 'technician'
                    ? 'bg-sky-500 text-slate-950 shadow-md shadow-sky-500/20'
                    : 'text-slate-300 hover:text-white'
                }`}
              >
                <Wrench className="w-3.5 h-3.5" />
                <span>٢. واجهة الكابتن والونش والفني</span>
              </button>
            </div>
          ) : displayMode === 'owner_dashboard' ? (
            // OWNER DASHBOARD IS ISOLATED
            <div className="flex items-center gap-3 text-xs">
              <span className="font-black text-amber-300 flex items-center gap-1.5">
                <Crown className="w-4 h-4 text-amber-400" />
                <span>التحكم الحصري لمالك المنصة</span>
              </span>
              <span className="text-slate-600">|</span>
              <button
                type="button"
                onClick={() => changeDisplayMode('public_app', 'customer')}
                className="text-sky-400 hover:text-sky-300 font-bold underline flex items-center gap-1 cursor-pointer"
              >
                <ExternalLink className="w-3.5 h-3.5" />
                <span>معاينة تطبيق الجمهور (العميل والسائق)</span>
              </button>
            </div>
          ) : (
            // Developer Guide Mode
            <div className="flex items-center gap-2">
              <span className="font-bold text-sky-400">دليل النشر والـ OTP</span>
            </div>
          )}
        </nav>

        {/* Zone 3: Language Toggle & Emergency SOS */}
        <div className="flex items-center gap-2 shrink-0">
          {/* Language Switcher */}
          <button
            type="button"
            onClick={toggleLanguage}
            className="min-h-[38px] px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/15 text-white text-xs font-black flex items-center gap-1.5 cursor-pointer border border-white/10"
            title="تبديل اللغة / Toggle Language"
          >
            <Globe className="w-3.5 h-3.5 text-sky-400" />
            <span>{t.langToggle}</span>
          </button>

          {/* SOS Button */}
          <button
            type="button"
            onClick={() => setShowSOSModal(true)}
            className="min-h-[38px] px-3.5 py-1.5 text-xs font-black text-white bg-red-600 hover:bg-red-500 rounded-xl transition-all whitespace-nowrap shrink-0 cursor-pointer flex items-center gap-1.5 shadow-md shadow-red-600/30 active:scale-95"
          >
            <AlertTriangle className="w-4 h-4" />
            <span>SOS</span>
          </button>
        </div>
      </header>

      {/* =====================================================================
          OWNER SEPARATION NOTICE (Only shown when Owner view is opened)
         ===================================================================== */}
      {displayMode === 'owner_dashboard' && (
        <div className="bg-amber-950/60 border-b border-amber-500/30 px-4 py-2 text-xs text-amber-200 text-center flex items-center justify-center gap-2 font-bold">
          <Crown className="w-4 h-4 text-amber-400 shrink-0" />
          <span>
            هذه الشاشة خاصة بك وحدك كمالك للتطبيق. العملاء والسائقون لا يرون هذا القسم إطلاقاً عند تنزيل التطبيق.
          </span>
          <button
            type="button"
            onClick={() => {
              navigator.clipboard.writeText(ownerDashboardUrl);
              alert('تم نسخ الرابط السري الخاص بك كمالك: ' + ownerDashboardUrl);
            }}
            className="underline text-amber-300 hover:text-white cursor-pointer mr-2"
          >
            نسخ رابطك السري
          </button>
        </div>
      )}

      {/* Main Viewport */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-3 sm:px-6 lg:px-8 py-6">
        {displayMode === 'public_app' && activePortal === 'customer' && (
          <CustomerPortal
            orders={orders}
            receivingAccounts={receivingAccounts}
            language={language}
            onCreateOrder={handleCreateOrder}
            onUpdateOrder={handleUpdateOrder}
            onOpenSOS={() => setShowSOSModal(true)}
          />
        )}

        {displayMode === 'public_app' && activePortal === 'technician' && (
          <TechnicianPortal
            orders={orders}
            receivingAccounts={receivingAccounts}
            language={language}
            onSubmitQuote={handleTechnicianSubmitQuote}
            onUpdateOrderStatus={handleTechnicianUpdateStatus}
            onTechnicianPayPlatformFee={handleTechnicianPayPlatformFee}
          />
        )}

        {displayMode === 'owner_dashboard' && (
          <OwnerPortal
            orders={orders}
            receivingAccounts={receivingAccounts}
            language={language}
            onUpdateReceivingAccounts={handleUpdateReceivingAccounts}
            onUpdateOrder={handleUpdateOrder}
          />
        )}

        {displayMode === 'developer_guide' && <RoadmapAndTechGuide />}
      </main>

      {/* Emergency SOS Modal */}
      {showSOSModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-red-500/40 rounded-3xl p-6 sm:p-7 max-w-lg w-full text-white space-y-5 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2 text-red-500 font-black text-base">
                <AlertTriangle className="w-6 h-6" />
                <span>نداء الاستغاثة العاجل — طوارئ مصر</span>
              </div>
              <button
                type="button"
                onClick={() => setShowSOSModal(false)}
                className="text-slate-400 hover:text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
              إذا كانت سيارتك في خطر فوري على نهر الطريق السريع، أو عالقة تماماً في منطقة صحراوية مقطوعة:
            </p>

            <div className="p-4 rounded-2xl bg-red-950/40 border border-red-500/30 text-xs text-red-200 space-y-2.5 font-bold">
              <div className="text-red-300 font-black">أرقام طوارئ الطرق الرسمية في جمهورية مصر العربية:</div>
              <div className="flex items-center justify-between font-mono">
                <span>طوارئ المرور المركزي (الطرق السريعة):</span>
                <a href="tel:01221110000" className="text-amber-400 font-bold hover:underline">01221110000</a>
              </div>
              <div className="flex items-center justify-between font-mono">
                <span>الإسعاف المصري:</span>
                <a href="tel:123" className="text-amber-400 font-bold hover:underline">123</a>
              </div>
              <div className="flex items-center justify-between font-mono">
                <span>شرطة النجدة:</span>
                <a href="tel:122" className="text-amber-400 font-bold hover:underline">122</a>
              </div>
            </div>

            <button
              type="button"
              onClick={() => {
                setShowSOSModal(false);
                changeDisplayMode('public_app', 'customer');
              }}
              className="w-full min-h-[46px] rounded-2xl bg-sky-500 hover:bg-sky-400 text-slate-950 font-black text-xs flex items-center justify-center gap-2 cursor-pointer shadow"
            >
              <span>طلب ونش إنقاذ سريع ودفع رباعي عبر المنصة</span>
            </button>
          </div>
        </div>
      )}

      {/* Interactive Mobile & Installation Guide Modal */}
      <InstallGuideModal
        isOpen={showInstallGuideModal}
        onClose={() => setShowInstallGuideModal(false)}
        language={language}
        onTriggerNativeInstall={handleTriggerNativeInstall}
        hasNativePrompt={!!deferredPrompt}
      />

      {/* Footer (With discrete private Owner Access for testing) */}
      <footer className="border-t border-sky-500/15 bg-[#0B192C] px-6 py-4 mt-8">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-400">
          <span>
            الياسمين جو | YASMIN GO — النقل الذكي وإصلاح أعطال السيارات والونش والإنقاذ في مصر
          </span>
          <div className="flex items-center gap-4">
            <button
              type="button"
              onClick={() => changeDisplayMode('developer_guide', 'architecture')}
              className="text-slate-500 hover:text-sky-400 transition-colors flex items-center gap-1 cursor-pointer text-[11px]"
            >
              <FolderArchive className="w-3.5 h-3.5" />
              <span>دليل النشر والـ OTP والأكواد</span>
            </button>

            {displayMode === 'public_app' && (
              <button
                type="button"
                onClick={() => changeDisplayMode('owner_dashboard', 'owner')}
                className="text-slate-600 hover:text-amber-400 transition-colors flex items-center gap-1 cursor-pointer text-[11px]"
                title="تسجيل دخول مالك المنصة السري"
              >
                <Lock className="w-3 h-3" />
                <span>دخول المالك السري (PIN)</span>
              </button>
            )}

            <span className="font-mono text-slate-500">
              جميع الحقوق محفوظة للمالك © 2026
            </span>
          </div>
        </div>
      </footer>
    </div>
  );
}
