import { AppLanguage } from '../types/yasmine';

export interface Translations {
  appName: string;
  appSlogan: string;
  smartRide: string;
  carBreakdown: string;
  winchRescue: string;
  customerPortal: string;
  providerPortal: string;
  ownerDashboard: string;
  architectureGuide: string;
  emergencySOS: string;
  sosDescription: string;
  switchView: string;
  activeNow: string;
  langToggle: string;
  currency: string;
  otpCodeSent: string;
  verifyOtp: string;
  enterPhone: string;
  sendOtp: string;
  phoneLabel: string;
  nameLabel: string;
  pickupLocation: string;
  dropoffLocation: string;
  suggestFare: string;
  requestRideNow: string;
  requestRescueNow: string;
  bidsReceived: string;
  acceptOffer: string;
  trackingOrder: string;
  statusCompleted: string;
  paymentMethod: string;
  cashOnArrival: string;
  instapayTransfer: string;
  vodafoneCash: string;
  driverEnRoute: string;
  driverArrived: string;
  tripInProgress: string;
  ownerLeadership: string;
  platformCommission: string;
  subAdmins: string;
  providerVerification: string;
  approve: string;
  reject: string;
  pendingReview: string;
  approved: string;
}

export const TRANSLATIONS: Record<AppLanguage, Translations> = {
  ar: {
    appName: 'الياسمين جو | YASMIN GO',
    appSlogan: 'النقل الذكي وإصلاح أعطال السيارات والونش والإنقاذ في مصر',
    smartRide: 'نقل ذكي (inDrive)',
    carBreakdown: 'أعطال وصيانة سيارات',
    winchRescue: 'ونش وإنقاذ سريع',
    customerPortal: 'واجهة العميل (طلب خدمة)',
    providerPortal: 'واجهة الكابتن والفني',
    ownerDashboard: 'لوحة تحكم المالك',
    architectureGuide: 'خطة النشر والتقنيات',
    emergencySOS: 'نجدة SOS طوارئ',
    sosDescription: 'أرقام النجدة الرسمية وطوارئ الطرق السريعة والصحراوية في مصر',
    switchView: 'التبديل بين الواجهات:',
    activeNow: 'نشط الآن',
    langToggle: 'English',
    currency: 'ج.م',
    otpCodeSent: 'تم إرسال كود التحقق SMS إلى هاتفك',
    verifyOtp: 'تأكيد الرمز والدخول',
    enterPhone: 'أدخل رقم الهاتف المصري (01xxxxxxxxx)',
    sendOtp: 'إرسال كود التحقق OTP',
    phoneLabel: 'رقم المحمول',
    nameLabel: 'الاسم الكامل',
    pickupLocation: 'نقطة الانطلاق (موقعك الحالي)',
    dropoffLocation: 'الوجهة أو مكان التوصيل',
    suggestFare: 'اقترح سعرك للرحلة (جنيه)',
    requestRideNow: 'طلب الرحلة وبثها للكباتن القريبين',
    requestRescueNow: 'طلب ونش أو فني إنقاذ فوري',
    bidsReceived: 'عروض الأسعار المتاحة من الكباتن والفنيين',
    acceptOffer: 'قبول العرض وتأكيد الطلب',
    trackingOrder: 'تتبع المسار والموقع المباشر',
    statusCompleted: 'اكتملت الخدمة بنجاح',
    paymentMethod: 'طريقة الدفع',
    cashOnArrival: 'نقدي (كاش) عند الوصول',
    instapayTransfer: 'إنستاباي InstaPay مصر',
    vodafoneCash: 'فودافون كاش / المحافظ الإلكترونية',
    driverEnRoute: 'الكابتن / الفني في الطريق إليك',
    driverArrived: 'وصل إلى موقعك الآن',
    tripInProgress: 'جاري تنفيذ الخدمة / الرحلة',
    ownerLeadership: 'بقيادة المهندس محمد صلاح',
    platformCommission: 'إدارة العمولات والأسعار',
    subAdmins: 'المديرون والصلاحيات',
    providerVerification: 'اعتماد السائقين والفنيين والأوناش',
    approve: 'اعتماد وتفعيل',
    reject: 'رفض',
    pendingReview: 'قيد المراجعة والتدقيق',
    approved: 'معتمد ونشط',
  },
  en: {
    appName: 'YASMIN GO | Egypt',
    appSlogan: 'Smart Ride Bidding, Roadside Assistance & Tow Rescue in Egypt',
    smartRide: 'Smart Ride (inDrive style)',
    carBreakdown: 'Roadside Repair',
    winchRescue: 'Tow & Recovery',
    customerPortal: 'Customer Portal',
    providerPortal: 'Driver & Tech Portal',
    ownerDashboard: 'Owner Dashboard',
    architectureGuide: 'Publishing & Tech Guide',
    emergencySOS: 'Emergency SOS',
    sosDescription: 'Official Highway Police & Ambulance Emergency Hotlines in Egypt',
    switchView: 'Switch View:',
    activeNow: 'Active',
    langToggle: 'العربية',
    currency: 'EGP',
    otpCodeSent: 'SMS verification code sent to your mobile',
    verifyOtp: 'Verify Code & Enter',
    enterPhone: 'Enter Egyptian mobile (01xxxxxxxxx)',
    sendOtp: 'Send OTP SMS Code',
    phoneLabel: 'Mobile Number',
    nameLabel: 'Full Name',
    pickupLocation: 'Pickup Location',
    dropoffLocation: 'Destination / Dropoff',
    suggestFare: 'Your Suggested Fare (EGP)',
    requestRideNow: 'Request Ride & Broadcast to Drivers',
    requestRescueNow: 'Request Immediate Rescue / Tow',
    bidsReceived: 'Live Bids from Drivers & Technicians',
    acceptOffer: 'Accept Offer & Confirm',
    trackingOrder: 'Live GPS & Route Tracking',
    statusCompleted: 'Service Successfully Completed',
    paymentMethod: 'Payment Method',
    cashOnArrival: 'Cash on Arrival',
    instapayTransfer: 'InstaPay Egypt',
    vodafoneCash: 'Vodafone Cash / E-Wallets',
    driverEnRoute: 'Driver / Specialist is En Route',
    driverArrived: 'Arrived at your location',
    tripInProgress: 'Service / Trip in Progress',
    ownerLeadership: 'Led by Eng. Mohamed Salah',
    platformCommission: 'Commission & Pricing Engine',
    subAdmins: 'Sub-Admins & Roles',
    providerVerification: 'Provider Approvals & Onboarding',
    approve: 'Approve & Activate',
    reject: 'Reject',
    pendingReview: 'Under Review & Verification',
    approved: 'Verified & Active',
  },
};
