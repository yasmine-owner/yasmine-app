# الياسمين لإصلاح أعطال السيارات في الطرق والصحراء

تطبيق أندرويد (Flutter) + لوحة تحكم ويب منفصلة. النشر على جوجل بلاي بحساب المالك.

## بنية المشروع
- lib/main.dart              نقطة الانطلاق + Firebase + الثيم اللحظي من اللوحة
- lib/core/                  الثوابت وحالات الطلب والألوان الافتراضية
- lib/models/                نماذج البيانات (Firestore)
- lib/services/              المصادقة OTP + قاعدة البيانات
- lib/theme/                 محرك الثيم (يقرأ الألوان/النصوص من settings/app)
- lib/screens/               شاشات العميل والفني والدخول

## قاعدة البيانات (Firestore)
- settings/app               الاسم، الألوان، الشعار، الأسعار، حسابات الدفع، إعدادات الفورم (تتحكم من اللوحة)
- users/{uid}                العملاء (role=customer)
- technicians/{uid}          الفنيون (approved: لا طلبات قبل اعتماد المالك)
- requests/{id}              الطلبات + عروض الفنيين + سجل الأحداث
- payments/{id}              عمليات الدفع (pending/success/refunded) — منع الاسترداد المزدوج
- complaints/{id}            الشكاوى
- logs/{id}                  سجل أحداث المالك

## الحالة الحالية
- [x] المرحلة 1: الهيكل + المصادقة OTP + الثيم اللحظي + نماذج البيانات
- [x] المرحلة 2: شاشات العميل الكاملة (عروض/اختيار/تتبع/تقييم/شكوى) + إيداع الفني + الإيصالات + الإشعارات FCM
- [x] لوحة التحكم المنفصلة (yasmine_admin/index.html): الألوان + الفورمز + الرسوم + الحسابات + الفنيون + المدفوعات + الاسترداد
- [ ] المرحلة 3: إنشاء مشروع Firebase (API keys + firebase_options.dart + owner auth + قواعد الأمان)
- [ ] المرحلة 4: خرائط Google + استضافة اللوحة (Firebase Hosting)
- [ ] المرحلة 5: بناء APK على Codemagic + النشر على جوجل بلاي

## خطوات البناء من الموبايل (بدون كمبيوتر)
1. أنشئ حساب GitHub من الموبايل → اعمل Repository جديد → ارفع ملفات المشروع (Add file → Upload files).
2. أنشئ حساب codemagic.io (مجاني) → New workflow → اختر الريبو.
3. المستودع فيه ملف واحد بس: yasmine_project.zip — وده مقصود!
   في Pre-build script ضع بالظبط:
     unzip -o yasmine_project.zip
     cp -r yasmine_flutter/. .
     rm -rf yasmine_flutter yasmine_admin
     flutter create --org com.yasmine --project-name yasmine_app .
     sed -i 's/minSdk = flutter.minSdkVersion/minSdk = 23/' android/app/build.gradle.kts 2>/dev/null || sed -i 's/minSdkVersion flutter.minSdkVersion/minSdkVersion 23/' android/app/build.gradle
4. Build → هتحصل على APK جاهز للتجربة على موبايلك.
   (google-services.json غير مطلوب — الإعدادات جوه firebase_options.dart)

## النشر على جوجل بلاي
- حساب مطور Google Play باسم المالك (25$ مرة واحدة).
- رفع ملف AAB من Codemagic + الدليل المصور (المرحلة 5).
