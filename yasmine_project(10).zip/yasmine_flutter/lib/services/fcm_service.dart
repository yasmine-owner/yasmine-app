import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

/// إشعارات الهاتف: طلب جديد للفني / عرض جديد للعميل / قبول / دفع
class FcmService {
  static final _fcm = FirebaseMessaging.instance;
  static String? token;

  static Future<void> init() async {
    await _fcm.requestPermission();
    token = await _fcm.getToken();
    // تحديث التوكن على بيانات المستخدم — بنستخدمه في المرحلة اللاحقة لإرسال الإشعارات من اللوحة
    FirebaseMessaging.onMessage.listen((msg) {
      // إشعار أثناء فتح التطبيق — في النسخة الكاملة: حفظ في مركز إشعارات داخلي
    });
  }

  /// تسجيل توكن الفني أو العميل لاستقبال الإشعارات المستهدفة
  static Future<void> saveToken(String collection, String uid) async {
    final t = await _fcm.getToken();
    if (t != null) await FirebaseFirestore.instance.collection(collection).doc(uid).update({'fcmToken': t});
  }
}
