import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/models.dart';
import '../core/config.dart';

/// كل عمليات قاعدة البيانات — دورة الطلب الكاملة:
/// العميل يدفع أولاً ← الطلب ينشر ← عروض الفنيين ← اختيار ← إيداع الفني ← تأكيد المالك ← ربط
class DbService {
  static final _db = FirebaseFirestore.instance;

  static CollectionReference<Map<String, dynamic>> get requests => _db.collection('requests');
  static CollectionReference<Map<String, dynamic>> get payments => _db.collection('payments');
  static CollectionReference<Map<String, dynamic>> get technicians => _db.collection('technicians');
  static CollectionReference<Map<String, dynamic>> get complaints => _db.collection('complaints');

  // ---------- العميل ----------
  static Future<String> createRequest(Map<String, dynamic> data) async {
    final ref = requests.doc();
    await ref.set({...data, 'id': ref.id, 'status': RequestStatus.awaitingPayment,
      'offers': [], 'events': [RequestEvent(msg: 'إنشاء الطلب', t: DateTime.now()).toMap()],
      't': FieldValue.serverTimestamp()});
    return ref.id;
  }

  /// إنشاء عملية دفع — منع التكرار: لا ننشئ عملية جديدة لو فيه pending لنفس الطلب والطرف
  static Future<String?> createPayment({required String party, required String reqId, required int amount, String? receiptUrl}) async {
    final dup = await payments.where('reqId', isEqualTo: reqId).where('party', isEqualTo: party)
        .where('status', whereIn: [PaymentStatus.pending, PaymentStatus.success]).get();
    if (dup.docs.isNotEmpty) return null;
    final ref = payments.doc();
    await ref.set({'id': ref.id, 'party': party, 'reqId': reqId, 'amount': amount,
      'status': PaymentStatus.pending, 'tx': ref.id.toUpperCase(),
      if (receiptUrl != null) 'receiptUrl': receiptUrl,
      't': FieldValue.serverTimestamp()});
    return ref.id;
  }

  static Stream<List<RequestModel>> myRequests(String uid) =>
      requests.where('customerUid', isEqualTo: uid).orderBy('t', descending: true)
          .snapshots().map((s) => s.docs.map(RequestModel.fromDoc).toList());

  static Future<void> chooseOffer(String reqId, String techId) => requests.doc(reqId).update({
    'status': RequestStatus.chosen, 'chosenTechId': techId,
    'events': FieldValue.arrayUnion([RequestEvent(msg: 'العميل اختار الفني', t: DateTime.now()).toMap()]),
  });

  static Future<void> advanceRequest(String reqId, String status) => requests.doc(reqId).update({
    'status': status,
    'events': FieldValue.arrayUnion([RequestEvent(msg: RequestStatus.label(status), t: DateTime.now()).toMap()]),
  });

  static Future<void> addComplaint(Map<String, dynamic> data) => complaints.doc().set(data);

  // ---------- الفني ----------
  static Stream<List<RequestModel>> openRequestsFor(Technician me) => requests
      .where('status', isEqualTo: RequestStatus.open).snapshots()
      .map((s) => s.docs.map(RequestModel.fromDoc)
          .where((r) => me.specs.contains(r.serviceId) && !r.offers.any((o) => o.techId == me.uid)).toList());

  static Future<void> sendOffer(String reqId, Offer offer) => requests.doc(reqId).update({
    'offers': FieldValue.arrayUnion([offer.toMap()]),
  });

  static Stream<List<RequestModel>> techJobs(String uid) =>
      requests.where('chosenTechId', isEqualTo: uid).snapshots()
          .map((s) => s.docs.map(RequestModel.fromDoc).toList());

  static Future<void> setAvailability(String uid, bool v) => technicians.doc(uid).update({'available': v});

  // ---------- مشترك ----------
  static Future<void> rate(String reqId, String techId, int stars) async {
    await requests.doc(reqId).update({'rated': stars});
    final t = await technicians.doc(techId).get();
    final jobs = (t.data()?['jobs'] ?? 0) as int;
    final rating = ((t.data()?['rating'] ?? 0) as num).toDouble();
    await technicians.doc(techId).update({'rating': ((rating * jobs + stars) / (jobs + 1))});
  }
}
