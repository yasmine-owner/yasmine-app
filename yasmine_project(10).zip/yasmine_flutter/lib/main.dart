import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'firebase_options.dart';
import 'theme/theme_engine.dart';
import 'screens/splash_screen.dart';
import 'services/fcm_service.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  await FcmService.init();
  runApp(const YasmineApp());
}

class YasmineApp extends StatelessWidget {
  static final navKey = GlobalKey<NavigatorState>();
  const YasmineApp({super.key});

  @override
  Widget build(BuildContext context) {
    // الثيم بيتحدث لحظيًا من لوحة التحكم — أي تعديل ألوان/نصوص يظهر فورًا لكل المستخدمين
    return StreamBuilder(
      stream: ThemeEngine.settingsStream,
      builder: (context, snap) {
        final s = snap.data ?? ThemeEngine.fallback();
        return MaterialApp(
          navigatorKey: navKey,
          title: s.appName,
          debugShowCheckedModeBanner: false,
          theme: ThemeEngine.buildTheme(s),
          home: const SplashScreen(),
        );
      },
    );
  }
}
