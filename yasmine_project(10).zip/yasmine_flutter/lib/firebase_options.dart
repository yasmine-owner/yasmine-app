// ✅ مولّد يدويًا بمفاتيح مشروع yasmine-app-8818b — ملك المالك
import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;
import 'package:flutter/foundation.dart' show defaultTargetPlatform, TargetPlatform;

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    switch (defaultTargetPlatform) {
      case TargetPlatform.iOS:
      case TargetPlatform.macOS:
        return ios;
      case TargetPlatform.android:
      default:
        return android;
    }
  }

  static const FirebaseOptions android = FirebaseOptions(
    apiKey: 'AIzaSyCYDerO1zy74-T2guNnsJy2GF0wZkVBoPQ',
    appId: '1:122644518096:android:9724ee4272ab7152277ad5',
    messagingSenderId: '122644518096',
    projectId: 'yasmine-app-8818b',
    storageBucket: 'yasmine-app-8818b.firebasestorage.app',
  );

  // نفس القيم — جاهز لما نضيف آيفون لاحقًا
  static const FirebaseOptions ios = FirebaseOptions(
    apiKey: 'AIzaSyCYDerO1zy74-T2guNnsJy2GF0wZkVBoPQ',
    appId: '1:122644518096:android:9724ee4272ab7152277ad5',
    messagingSenderId: '122644518096',
    projectId: 'yasmine-app-8818b',
    storageBucket: 'yasmine-app-8818b.firebasestorage.app',
  );
}
