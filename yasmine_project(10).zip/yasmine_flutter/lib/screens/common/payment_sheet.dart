import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import '../../models/models.dart';
import '../../services/db_service.dart';
import '../../theme/theme_engine.dart';

/// ورقة الدفع: تعرض حسابات المالك (من اللوحة) وتستقبل صورة الإيصال
/// ولا يعلن نجاح الدفع — العملية تبقى pending لحد ما المالك يأكدها من اللوحة
class PaymentSheet extends StatefulWidget {
  final String party; // customer | tech
  final String reqId;
  final int amount;
  const PaymentSheet({super.key, required this.party, required this.reqId, required this.amount});

  static Future<void> show(BuildContext context,
      {required String party, required String reqId, required int amount}) {
    return showModalBottomSheet(context: context, isScrollControlled: true, builder: (_) =>
        PaymentSheet(party: party, reqId: reqId, amount: amount));
  }

  @override
  State<PaymentSheet> createState() => _PaymentSheetState();
}

class _PaymentSheetState extends State<PaymentSheet> {
  File? receipt;
  bool loading = false;

  Future<void> _pickReceipt() async {
    // ضغط الصورة + تصغيرها عشان تتخزن مجانًا جوه قاعدة البيانات
    final x = await ImagePicker().pickImage(source: ImageSource.gallery, maxWidth: 800, imageQuality: 45);
    if (x != null) setState(() => receipt = File(x.path));
  }

  Future<void> _confirm() async {
    setState(() => loading = true);
    String? receiptData;
    if (receipt != null) {
      final bytes = await receipt!.readAsBytes();
      receiptData = 'data:image/jpeg;base64,${base64Encode(bytes)}';
    }
    await DbService.createPayment(party: widget.party, reqId: widget.reqId, amount: widget.amount, receiptUrl: receiptData);
    if (!mounted) return;
    Navigator.pop(context);
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
      content: Text('✅ تم تسجيل عمليتك — هتتأكد من المالك وتتفتح الخطوة الجاية فورًا')));
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder(
      stream: ThemeEngine.settingsStream,
      builder: (_, snap) {
        final s = snap.data ?? ThemeEngine.fallback();
        return Padding(
          padding: EdgeInsets.only(left: 16, right: 16, top: 16, bottom: MediaQuery.of(context).viewInsets.bottom + 16),
          child: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            Text(widget.party == 'customer' ? 'دفع رسوم المنصة' : 'إيداع المنصة',
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold), textAlign: TextAlign.center),
            const SizedBox(height: 4),
            Text('${widget.amount} ج.م — ${widget.party == 'customer' ? 'يُنشر طلبك بعد تأكيد المالك' : 'يتفتح موقع العميل بعد تأكيد المالك'}',
              textAlign: TextAlign.center, style: const TextStyle(color: Colors.grey)),
            const SizedBox(height: 12),
            ...s.accounts.map((PaymentAccount a) => Card(child: ListTile(
              title: Text(a.type), trailing: Text(a.value, style: const TextStyle(fontWeight: FontWeight.bold)),
            ))),
            const SizedBox(height: 8),
            OutlinedButton.icon(
              onPressed: _pickReceipt,
              icon: Icon(receipt == null ? Icons.receipt_long : Icons.check_circle, color: receipt == null ? null : Colors.green),
              label: Text(receipt == null ? '🧾 ارفع صورة الإيصال بعد التحويل' : 'تم إرفاق الإيصال ✓')),
            const SizedBox(height: 12),
            ElevatedButton(
              onPressed: loading ? null : _confirm,
              child: loading ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                : Text('تأكيد التحويل — ${widget.amount} ج.م')),
          ])),
        );
      },
    );
  }
}
