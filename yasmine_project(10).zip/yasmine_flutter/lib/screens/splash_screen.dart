import 'package:flutter/material.dart';
import 'auth/login_screen.dart';
import 'customer/customer_home.dart';
import 'tech/tech_home.dart';
import '../services/auth_service.dart';

/// يحدد مين دخل آخر مرة ويوجهه لشاشته مباشرة (زي أوبر بالظبط)
class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});
  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    _route();
  }

  Future<void> _route() async {
    await Future.delayed(const Duration(seconds: 1));
    final u = AuthService.currentUser;
    if (!mounted) return;
    if (u == null) {
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const LoginScreen()));
      return;
    }
    final role = await AuthService.roleOf(u.uid);
    if (!mounted) return;
    if (role == 'tech') {
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => TechHome(uid: u.uid)));
    } else if (role == 'customer') {
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => CustomerHome(uid: u.uid)));
    } else {
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const LoginScreen()));
    }
  }

  @override
  Widget build(BuildContext context) => const Scaffold(body: Center(child: FlutterLogo(size: 90)));
}
