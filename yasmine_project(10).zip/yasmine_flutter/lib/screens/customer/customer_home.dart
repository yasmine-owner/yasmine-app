import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../../models/models.dart';
import '../../theme/theme_engine.dart';
import '../../services/db_service.dart';
import '../common/payment_sheet.dart';
import 'requests_screen.dart';

/// واجهة العميل — الفورم ديناميكي: حقوله من لوحة التحكم (formConfig)
class CustomerHome extends StatefulWidget {
  final String uid;
  const CustomerHome({super.key, required this.uid});
  @override
  State<CustomerHome> createState() => _CustomerHomeState();
}

class _CustomerHomeState extends State<CustomerHome> {
  int tab = 0;
  final carCtrl = TextEditingController(), descCtrl = TextEditingController(), locCtrl = TextEditingController();
  String? serviceId;

  Future<void> _createAndPay(AppSettings s) async {
    if (carCtrl.text.trim().isEmpty || locCtrl.text.trim().isEmpty || serviceId == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('أكمل بيانات السيارة والموقع ونوع العطل')));
      return;
    }
    final name = (await FirebaseFirestore.instance.collection('users').doc(widget.uid).get()).data()?['name'] ?? '';
    final phone = (await FirebaseFirestore.instance.collection('users').doc(widget.uid).get()).data()?['phone'] ?? '';
    final reqId = await DbService.createRequest({
      'customerUid': widget.uid, 'customerName': name, 'customerPhone': phone,
      'car': carCtrl.text.trim(), 'serviceId': serviceId, 'desc': descCtrl.text.trim(),
      'loc': locCtrl.text.trim(), 'fee': s.customerFee, 'techFee': s.techFee,
    });
    if (!mounted) return;
    await PaymentSheet.show(context, party: 'customer', reqId: reqId, amount: s.customerFee);
    setState(() => tab = 1);
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder(
      stream: ThemeEngine.settingsStream,
      builder: (_, sSnap) {
        final s = sSnap.data ?? ThemeEngine.fallback();
        final pages = [_newRequest(s), RequestsScreen(uid: widget.uid), const Center(child: Text('حسابي — قريباً'))];
        return Scaffold(
          appBar: AppBar(title: Text(s.appName)),
          body: pages[tab],
          bottomNavigationBar: NavigationBar(selectedIndex: tab, onDestinationSelected: (i) => setState(() => tab = i),
            destinations: const [
              NavigationDestination(icon: Icon(Icons.home), label: 'الرئيسية'),
              NavigationDestination(icon: Icon(Icons.list_alt), label: 'طلباتي'),
              NavigationDestination(icon: Icon(Icons.person), label: 'حسابي'),
            ]),
        );
      },
    );
  }

  Widget _newRequest(AppSettings s) {
    final fc = s.formConfig;
    bool enabled(String k) => fc[k] ?? true;
    return ListView(padding: const EdgeInsets.all(16), children: [
      SizedBox(width: double.infinity, child: ElevatedButton.icon(
        style: ElevatedButton.styleFrom(backgroundColor: Color(s.emergencyColor), padding: const EdgeInsets.all(18)),
        onPressed: () => setState(() { serviceId = 'البطاريات وكهرباء السيارات'; descCtrl.text = 'عطل طارئ — أحتاج مساعدة فورية'; }),
        icon: const Icon(Icons.sos), label: const Text('🚨 مساعدة عاجلة'))),
      const SizedBox(height: 14),
      Card(child: Padding(padding: const EdgeInsets.all(14), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        const Text('طلب إصلاح جديد', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
        const SizedBox(height: 10),
        TextField(controller: carCtrl, decoration: const InputDecoration(labelText: 'السيارة (مثال: هيونداي إلنترا 2020)')),
        if (enabled('photos')) ...[
          const SizedBox(height: 8),
          OutlinedButton.icon(onPressed: () {}, icon: const Icon(Icons.photo_camera), label: const Text('إرفاق صور (اختياري)')),
        ],
        const SizedBox(height: 8),
        DropdownButtonFormField<String>(
          value: serviceId, decoration: const InputDecoration(labelText: 'نوع العطل / الخدمة'),
          items: s.services.entries.where((e) => e.value).map((e) => DropdownMenuItem(value: e.key, child: Text(e.key))).toList(),
          onChanged: (v) => setState(() => serviceId = v),
        ),
        const SizedBox(height: 8),
        if (enabled('desc')) TextField(controller: descCtrl, maxLines: 3, decoration: const InputDecoration(labelText: 'وصف المشكلة')),
        const SizedBox(height: 8),
        TextField(controller: locCtrl, decoration: InputDecoration(labelText: 'موقع العطل', suffixIcon: IconButton(
          icon: const Icon(Icons.gps_fixed), onPressed: () => locCtrl.text = 'طريق السويس الصحراوي كم 45'))),
        const SizedBox(height: 14),
        // بطاقة الرسوم — بتحسب من إعدادات المالك لحظيًا
        Container(padding: const EdgeInsets.all(12), decoration: BoxDecoration(
          color: const Color(0xFFE8F2FF), borderRadius: BorderRadius.circular(12),
          border: Border.all(color: Color(s.accentColor), style: BorderStyle.solid)),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              const Text('رسوم المنصة', style: TextStyle(fontWeight: FontWeight.bold)),
              Text('${s.customerFee} ج.م', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
            ]),
            const Text('تُدفع أولاً على حسابات المالك — يُنشر طلبك بعد تأكيد الدفع فقط. لا تشمل تكلفة الإصلاح.',
              style: TextStyle(fontSize: 12, color: Colors.grey)),
            ...s.accounts.map((a) => Container(margin: const EdgeInsets.only(top: 6), padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(8), border: Border.all(color: Colors.grey.shade300)),
              child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text(a.type), Text(a.value, style: const TextStyle(fontWeight: FontWeight.bold))]))),
          ])),
        const SizedBox(height: 12),
        ElevatedButton(onPressed: () => _createAndPay(s), child: Text('ادفع ${s.customerFee} ج.م وانشر الطلب')),
      ]))),
    ]);
  }

}

