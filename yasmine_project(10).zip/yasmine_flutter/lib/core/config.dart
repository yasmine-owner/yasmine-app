import 'package:flutter/material.dart';

/// الهوية الافتراضية — تُستبدل تلقائيًا بإعدادات لوحة التحكم (settings/app)
class AppConfig {
  static const String appName = 'الياسمين لإصلاح أعطال السيارات';
  static const Color defaultPrimary = Color(0xFF0D1F3C);
  static const Color defaultAccent = Color(0xFF4DA3FF);
  static const Color defaultEmergency = Color(0xFFE23D3D);
}

/// حالات الطلب
class RequestStatus {
  static const String awaitingPayment = 'awaiting_payment';
  static const String awaitingTechPayment = 'awaiting_tech_payment';
  static const String open = 'open';
  static const String chosen = 'chosen';
  static const String accepted = 'accepted';
  static const String working = 'working';
  static const String completed = 'completed';
  static const String cancelled = 'cancelled';
  static const String refunded = 'refunded';

  static String label(String s) => const {
    awaitingPayment: 'بانتظار دفع رسوم العميل',
    awaitingTechPayment: 'الفني دفع — بانتظار تأكيد المالك',
    open: 'منشور — بانتظار العروض',
    chosen: 'تم اختيار فني — بانتظار إيداعه',
    accepted: 'مؤكد — الفني في الطريق',
    working: 'الفني في الموقع — جارٍ العمل',
    completed: 'مكتمل',
    cancelled: 'ملغى',
    refunded: 'ملغى وتم الاسترداد',
  }[s] ?? s;
}

/// حالات الدفع
class PaymentStatus {
  static const String pending = 'pending';
  static const String success = 'success';
  static const String failed = 'failed';
  static const String refundRequested = 'refund_requested';
  static const String refunded = 'refunded';
}
