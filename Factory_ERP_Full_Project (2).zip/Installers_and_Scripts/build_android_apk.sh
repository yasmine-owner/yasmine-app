#!/bin/bash
echo "========================================================"
echo "جاري تجهيز حزمة تطبيق أندرويد (Android APK)..."
echo "========================================================"
npm install
npm run build
npx @capacitor/cli add android
npx @capacitor/cli copy android
echo "افتح مجلد android في Android Studio لبناء ملف APK النهائي الموقع!"
