@echo off
echo ========================================================
echo جاري بناء ملف تثبيت الويندوز المستقل (Windows EXE / MSI)...
echo ========================================================
npm install
npm run build
npx @capacitor/cli add @capacitor-community/electron
echo تم تجهيز حزمة الويندوز بنجاح!
pause
