-- Enterprise Factory ERP Database Schema (PostgreSQL / MySQL)
CREATE TABLE users (
  id VARCHAR(64) PRIMARY KEY,
  username VARCHAR(64) UNIQUE NOT NULL,
  name VARCHAR(128) NOT NULL,
  role VARCHAR(32) NOT NULL,
  email VARCHAR(128),
  is_active BOOLEAN DEFAULT TRUE,
  permissions JSONB NOT NULL
);

CREATE TABLE accounts (
  id VARCHAR(64) PRIMARY KEY,
  code VARCHAR(32) UNIQUE NOT NULL,
  name VARCHAR(128) NOT NULL,
  type VARCHAR(32) NOT NULL,
  parent_code VARCHAR(32),
  balance NUMERIC(15, 2) DEFAULT 0.00
);

CREATE TABLE journal_entries (
  id VARCHAR(64) PRIMARY KEY,
  entry_number VARCHAR(64) UNIQUE NOT NULL,
  date DATE NOT NULL,
  description TEXT NOT NULL,
  reference_type VARCHAR(32),
  total_amount NUMERIC(15, 2) NOT NULL,
  is_posted BOOLEAN DEFAULT TRUE,
  is_reversed BOOLEAN DEFAULT FALSE,
  created_by VARCHAR(64),
  lines JSONB NOT NULL
);

CREATE TABLE machines (
  id VARCHAR(64) PRIMARY KEY,
  code VARCHAR(32) UNIQUE NOT NULL,
  name VARCHAR(128) NOT NULL,
  purchase_cost NUMERIC(15, 2) NOT NULL,
  current_book_value NUMERIC(15, 2) NOT NULL,
  useful_life_years INT NOT NULL,
  total_run_hours NUMERIC(10, 2) DEFAULT 0,
  total_breakdown_hours NUMERIC(10, 2) DEFAULT 0,
  hourly_operating_cost NUMERIC(10, 2) DEFAULT 0,
  power_consumption_kw NUMERIC(10, 2) DEFAULT 0
);
