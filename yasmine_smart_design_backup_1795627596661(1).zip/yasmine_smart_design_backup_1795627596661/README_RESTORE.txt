# Yasmine Smart Design Studio V5.2 - Backup & Source Archive
Generated: 2026-11-25T17:26:36.066Z

This archive contains your complete Yasmine Smart Design Studio project state:
- yasmine_project.json: Full scene units, 17 color channels, and lighting settings.
- yasmine_lighting.json: Dedicated lighting and render settings (compatible with Blender V5.2 Pro add-on).
- yasmine_studio_full.html: Fully standalone 3D interactive viewer and editor (works offline in any browser).

To restore your project:
1. Open yasmine_studio_full.html in any browser or upload yasmine_project.json into the manufacturing/export panel.
