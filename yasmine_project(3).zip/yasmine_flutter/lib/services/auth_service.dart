import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/models.dart';

/// مصادقة رقم الهاتف بكود OTP — زي أوبر بالظبط
class AuthService {
  static final _auth = FirebaseAuth.instance;
  static final _db = FirebaseFirestore.instance;

  static User? get currentUser => _auth.currentUser;

  /// يرسل الكود، وonCodeSent يفتح شاشة إدخال الكود
  static Future<void> sendOtp(String phone, {
    required void Function(String verificationId) onCodeSent,
    required void Function(String error) onError,
  }) async {
    await _auth.verifyPhoneNumber(
      phoneNumber: '+2$phone',
      timeout: const Duration(seconds: 60),
      verificationCompleted: (cred) async => await _auth.signInWithCredential(cred),
      verificationFailed: (e) => onError(e.message ?? 'فشل إرسال الكود'),
      codeSent: (id, _) => onCodeSent(id),
      codeAutoRetrievalTimeout: (_) {},
    );
  }

  static Future<UserCredential> verifyOtp(String verificationId, String code) =>
      _auth.signInWithCredential(PhoneAuthProvider.credential(
          verificationId: verificationId, smsCode: code));

  /// يجيب دور المستخدم: عميل أو فني (لو مش موجود يبقى تسجيل جديد)
  static Future<String?> roleOf(String uid) async {
    final d = await _db.collection('users').doc(uid).get();
    if (d.exists) return (d.data()?['role']) as String?;
    final t = await _db.collection('technicians').doc(uid).get();
    if (t.exists) return 'tech';
    return null;
  }

  static Future<void> registerCustomer(AppUser u) =>
      _db.collection('users').doc(u.uid).set({'name': u.name, 'phone': u.phone, 'role': 'customer', 't': FieldValue.serverTimestamp()});

  static Future<void> registerTechnician(Map<String, dynamic> data) =>
      _db.collection('technicians').doc(currentUser!.uid).set({...data, 'approved': false, 'pending': true, 'blocked': false, 'available': true, 'rating': 0, 'jobs': 0});

  static Future<void> logout() => _auth.signOut();
}
