import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../core/config.dart';
import '../models/models.dart';

/// محرك الثيم: يقرأ إعدادات المنصة من Firestore لحظيًا، وأي تعديل من لوحة التحكم
/// يظهر فورًا عند كل المستخدمين بدون تحديث التطبيق.
class ThemeEngine {
  static final _ref = FirebaseFirestore.instance.collection('settings').doc('app');

  static Stream<AppSettings> get settingsStream =>
      _ref.snapshots().map((d) => AppSettings.fromDoc(d));

  static Future<AppSettings> get current async => AppSettings.fromDoc(await _ref.get());

  static ThemeData buildTheme(AppSettings s) {
    final primary = Color(s.primaryColor);
    final accent = Color(s.accentColor);
    return ThemeData(
      useMaterial3: true,
      fontFamily: 'Tahoma',
      colorScheme: ColorScheme.fromSeed(seedColor: primary, primary: primary, secondary: accent),
      scaffoldBackgroundColor: const Color(0xFFF4F7FB),
      appBarTheme: AppBarTheme(backgroundColor: primary, foregroundColor: Colors.white, centerTitle: true),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: primary, foregroundColor: Colors.white,
          minimumSize: const Size.fromHeight(50),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          textStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
        ),
      ),
      cardTheme: CardTheme(shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))),
      inputDecorationTheme: InputDecorationTheme(
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
        filled: true, fillColor: Colors.white,
      ),
    );
  }

  /// لوحة التحكم مش علّمت على الحساب بعد، فالألوان الافتراضية هي اللي بتشتغل
  static AppSettings fallback() => AppSettings(
    appName: AppConfig.appName, primaryColor: 0xFF0D1F3C, accentColor: 0xFF4DA3FF,
    emergencyColor: 0xFFE23D3D, logoUrl: '', ownerPhone: '', customerFee: 30, techFee: 25,
    accounts: const [], formConfig: const {}, services: const {});
}
