import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../../models/models.dart';
import '../../services/db_service.dart';
import '../common/payment_sheet.dart';
import 'package:url_launcher/url_launcher.dart';

/// بوابة الفني — لا طلبات قبل الاعتماد، ولا موقع العميل قبل إيداعه وتأكيد المالك
class _Note extends StatelessWidget {
  final Color color; final String text;
  const _Note({required this.color, required this.text});
  @override
  Widget build(BuildContext context) => Container(
    width: double.infinity, padding: const EdgeInsets.all(10),
    decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(10)),
    child: Text(text, style: const TextStyle(fontSize: 12)));
}

class TechHome extends StatefulWidget {
  final String uid;
  const TechHome({super.key, required this.uid});
  @override
  State<TechHome> createState() => _TechHomeState();
}

class _TechHomeState extends State<TechHome> {
  int tab = 0;

  @override
  Widget build(BuildContext context) {
    return StreamBuilder(
      stream: FirebaseFirestore.instance.collection('technicians').doc(widget.uid).snapshots(),
      builder: (_, tSnap) {
        final me = Technician.fromDoc(tSnap.data!);
        if (me.pending && !me.approved) {
          return const Scaffold(body: Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
            Icon(Icons.hourglass_top, size: 60, color: Colors.orange),
            SizedBox(height: 12),
            Text('حسابك بانتظار اعتماد المالك', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
            Text('لن تستقبل طلبات إلا بعد الاعتماد'),
          ])));
        }
        final pages = [_radar(me), _jobs(me), _profile(me)];
        return Scaffold(
          appBar: AppBar(title: Text('بوابة الفني — ${me.name}'),
            actions: [Chip(label: Text(me.available ? 'متاح' : 'مغلق'))]),
          body: pages[tab],
          bottomNavigationBar: NavigationBar(selectedIndex: tab, onDestinationSelected: (i) => setState(() => tab = i),
            destinations: const [
              NavigationDestination(icon: Icon(Icons.radar), label: 'الرادار'),
              NavigationDestination(icon: Icon(Icons.build), label: 'شغلي'),
              NavigationDestination(icon: Icon(Icons.person), label: 'ملفي'),
            ]),
        );
      },
    );
  }

  Widget _radar(Technician me) {
    if (!me.available) return const Center(child: Text('شغّل التوافر من «ملفي» لاستقبال الطلبات'));
    return StreamBuilder(
      stream: DbService.openRequestsFor(me),
      builder: (_, snap) {
        if (!snap.hasData) return const Center(child: CircularProgressIndicator());
        final list = snap.data!;
        if (list.isEmpty) return const Center(child: Text('مفيش طلبات مناسبة حالياً'));
        return ListView(padding: const EdgeInsets.all(16), children: list.map((r) => Card(child: Padding(
          padding: const EdgeInsets.all(12), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(r.serviceId, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
            Text('${r.car} • ${r.loc}'),
            Text('"${r.desc}"', style: const TextStyle(color: Colors.grey)),
            const SizedBox(height: 8),
            ElevatedButton(onPressed: () => _offerSheet(r), child: const Text('قدّم عرضك')),
          ])))).toList());
      },
    );
  }

  void _offerSheet(RequestModel r) {
    final price = TextEditingController(), eta = TextEditingController();
    showModalBottomSheet(context: context, builder: (_) => Padding(padding: const EdgeInsets.all(16), child: Column(mainAxisSize: MainAxisSize.min, children: [
      TextField(controller: price, decoration: const InputDecoration(labelText: 'عرض سعرك (مثال: 200-300 ج)')),
      const SizedBox(height: 8),
      TextField(controller: eta, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'دقائق الوصول المتوقعة')),
      const SizedBox(height: 8),
      const Text('⚠️ الإصلاح وقطع الغيار يتفاوض عليها مباشرة مع العميل في الموقع', style: TextStyle(fontSize: 12, color: Colors.grey)),
      const SizedBox(height: 8),
      ElevatedButton(onPressed: () async {
        Navigator.pop(context);
        await DbService.sendOffer(r.id, Offer(techId: widget.uid, price: price.text, eta: eta.text, dist: '—', t: DateTime.now()));
      }, child: const Text('أرسل عرضك')),
    ])));
  }

  Widget _jobs(Technician me) {
    return StreamBuilder(
      stream: DbService.techJobs(widget.uid),
      builder: (_, snap) {
        if (!snap.hasData) return const Center(child: CircularProgressIndicator());
        final list = snap.data!;
        if (list.isEmpty) return const Center(child: Text('لسه مفيش شغل مؤكد'));
        return ListView(padding: const EdgeInsets.all(16), children: list.map((r) {
          Widget? action;
          if (r.status == 'chosen') action = _payDepositBtn(context, r);
          if (r.status == 'awaiting_tech_payment') action = const Padding(
            padding: EdgeInsets.only(top: 8),
            child: _Note(color: Color(0xFFFDF1DC), text: '💸 إيداعك قيد تأكيد المالك — الموقع يتفتح فور التأكيد.'));
          if (r.status == 'accepted') action = ElevatedButton(onPressed: () => DbService.advanceRequest(r.id, 'working'), child: const Text('وصلت الموقع وبدأت الشغل'));
          if (r.status == 'working') action = ElevatedButton(onPressed: () => DbService.advanceRequest(r.id, 'completed'), child: const Text('✅ أنهيت الخدمة'));
          return Card(child: Padding(padding: const EdgeInsets.all(12), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(r.serviceId, style: const TextStyle(fontWeight: FontWeight.bold)),
            if (['accepted', 'working'].contains(r.status)) Text('📍 ${r.customerName} — ${r.customerPhone}\n${r.loc}'),
            if (action != null) action,
          ])));
        }).toList());
      },
    );
  }

  Widget _payDepositBtn(BuildContext context, RequestModel r) => Padding(
    padding: const EdgeInsets.only(top: 8),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text('ادفع إيداع المنصة ${r.techFee} ج.م — موقع العميل يتفتح بعد تأكيد المالك فقط',
        style: const TextStyle(fontSize: 12.5)),
      const SizedBox(height: 6),
      SizedBox(width: double.infinity, child: FilledButton(
        onPressed: () async {
          await PaymentSheet.show(context, party: 'tech', reqId: r.id, amount: r.techFee);
          await DbService.advanceRequest(r.id, 'awaiting_tech_payment');
        },
        child: Text('ادفع ${r.techFee} ج.م وابدأ التحرك'))),
    ]),
  );

  Widget _profile(Technician me) {
    return ListView(padding: const EdgeInsets.all(16), children: [
      SwitchListTile(title: const Text('متاح لاستقبال الطلبات'), value: me.available,
        onChanged: (v) => DbService.setAvailability(widget.uid, v)),
      ListTile(title: Text(me.name), subtitle: Text('${me.area} • ★ ${me.rating} • ${me.jobs} خدمة')),
      const SizedBox(height: 10),
      OutlinedButton(onPressed: () {}, child: const Text('تسجيل الخروج')),
    ]);
  }
}
