import 'package:cloud_firestore/cloud_firestore.dart';

/// الخدمات الافتراضية — تُستخدم لحد ما المالك يظبطها من اللوحة
const defaultServices = {
  'الكاوتش والإطارات': true,
  'البطاريات وكهرباء السيارات': true,
  'الميكانيكا والمحرك': true,
  'التبريد والسخونة': true,
  'الفرامل والعفشة والتوجيه': true,
  'تشخيص الكمبيوتر والحساسات': true,
  'تكييف السيارات': true,
  'الونش والسحب والإنقاذ': true,
  'قطع الغيار والمستلزمات': true,
  'خدمات المفاتيح': true,
  'السيارات الهجينة والكهربائية': true,
};

const defaultFormConfig = {'photos': true, 'desc': true, 'carYear': false, 'plate': false, 'notes': false};

/// إعدادات المنصة — الوثيقة الوحيدة التي تتحكم في شكل التطبيق وسلوكه من اللوحة
class AppSettings {
  final String appName;
  final int primaryColor;
  final int accentColor;
  final int emergencyColor;
  final String logoUrl;
  final String ownerPhone;
  final int customerFee;
  final int techFee;
  final List<PaymentAccount> accounts;
  final Map<String, dynamic> formConfig; // حقول الفورم: تفعيل/إجبار
  final Map<String, bool> services;

  AppSettings({
    required this.appName, required this.primaryColor, required this.accentColor,
    required this.emergencyColor, required this.logoUrl, required this.ownerPhone,
    required this.customerFee, required this.techFee, required this.accounts,
    required this.formConfig, required this.services,
  });

  factory AppSettings.fromDoc(DocumentSnapshot d) {
    final m = d.data() as Map<String, dynamic>? ?? {};
    return AppSettings(
      appName: m['appName'] ?? 'الياسمين لإصلاح أعطال السيارات',
      primaryColor: m['primaryColor'] ?? 0xFF0D1F3C,
      accentColor: m['accentColor'] ?? 0xFF4DA3FF,
      emergencyColor: m['emergencyColor'] ?? 0xFFE23D3D,
      logoUrl: m['logoUrl'] ?? '',
      ownerPhone: m['ownerPhone'] ?? '',
      customerFee: m['customerFee'] ?? 30,
      techFee: m['techFee'] ?? 25,
      accounts: (m['paymentAccounts'] as List? ?? []).map((e) => PaymentAccount.fromMap(e)).toList(),
      formConfig: Map<String, dynamic>.from(m['formConfig'] ?? defaultFormConfig),
      services: Map<String, bool>.from(m['services'] ?? defaultServices),
    );
  }
}

class PaymentAccount {
  final String type; // انستاباي / فودافون كاش ...
  final String value;
  PaymentAccount({required this.type, required this.value});
  factory PaymentAccount.fromMap(Map m) => PaymentAccount(type: m['type'] ?? '', value: m['value'] ?? '');
  Map<String, dynamic> toMap() => {'type': type, 'value': value};
}

class AppUser {
  final String uid, name, phone, role;
  AppUser({required this.uid, required this.name, required this.phone, required this.role});
  factory AppUser.fromDoc(DocumentSnapshot d) {
    final m = d.data() as Map<String, dynamic>? ?? {};
    return AppUser(uid: d.id, name: m['name'] ?? '', phone: m['phone'] ?? '', role: m['role'] ?? 'customer');
  }
}

class Technician {
  final String uid, name, phone, area;
  final List<String> specs;
  final bool approved, blocked, available, pending;
  final double rating;
  final int jobs;
  Technician({required this.uid, required this.name, required this.phone, required this.area,
    required this.specs, required this.approved, required this.blocked, required this.available,
    required this.pending, required this.rating, required this.jobs});
  factory Technician.fromDoc(DocumentSnapshot d) {
    final m = d.data() as Map<String, dynamic>? ?? {};
    return Technician(
      uid: d.id, name: m['name'] ?? '', phone: m['phone'] ?? '', area: m['area'] ?? '',
      specs: List<String>.from(m['specs'] ?? []), approved: m['approved'] ?? false,
      blocked: m['blocked'] ?? false, available: m['available'] ?? true,
      pending: m['pending'] ?? false, rating: (m['rating'] ?? 0).toDouble(), jobs: m['jobs'] ?? 0,
    );
  }
}

class Offer {
  final String techId, price, eta, dist;
  final DateTime t;
  Offer({required this.techId, required this.price, required this.eta, required this.dist, required this.t});
  factory Offer.fromMap(Map m) => Offer(
    techId: m['techId'] ?? '', price: m['price'] ?? '', eta: m['eta'] ?? '', dist: m['dist'] ?? '',
    t: (m['t'] as Timestamp?)?.toDate() ?? DateTime.now(),
  );
  Map<String, dynamic> toMap() => {'techId': techId, 'price': price, 'eta': eta, 'dist': dist, 't': Timestamp.fromDate(t)};
}

class RequestEvent {
  final String msg;
  final DateTime t;
  RequestEvent({required this.msg, required this.t});
  factory RequestEvent.fromMap(Map m) => RequestEvent(
    msg: m['msg'] ?? '', t: (m['t'] as Timestamp?)?.toDate() ?? DateTime.now());
  Map<String, dynamic> toMap() => {'msg': msg, 't': Timestamp.fromDate(t)};
}

class RequestModel {
  final String id, customerUid, customerName, customerPhone, car, serviceId, desc, loc, status, chosenTechId;
  final List<Offer> offers;
  final List<RequestEvent> events;
  final int fee, techFee;
  final DateTime t;
  RequestModel({required this.id, required this.customerUid, required this.customerName,
    required this.customerPhone, required this.car, required this.serviceId, required this.desc,
    required this.loc, required this.status, required this.chosenTechId, required this.offers,
    required this.events, required this.fee, required this.techFee, required this.t});
  factory RequestModel.fromDoc(DocumentSnapshot d) {
    final m = d.data() as Map<String, dynamic>? ?? {};
    return RequestModel(
      id: d.id, customerUid: m['customerUid'] ?? '', customerName: m['customerName'] ?? '',
      customerPhone: m['customerPhone'] ?? '', car: m['car'] ?? '', serviceId: m['serviceId'] ?? '',
      desc: m['desc'] ?? '', loc: m['loc'] ?? '', status: m['status'] ?? '',
      chosenTechId: m['chosenTechId'] ?? '',
      offers: (m['offers'] as List? ?? []).map((e) => Offer.fromMap(e)).toList(),
      events: (m['events'] as List? ?? []).map((e) => RequestEvent.fromMap(e)).toList(),
      fee: m['fee'] ?? 0, techFee: m['techFee'] ?? 0,
      t: (m['t'] as Timestamp?)?.toDate() ?? DateTime.now(),
    );
  }
}

class Payment {
  final String id, party, reqId, status, tx;
  final int amount;
  final DateTime t;
  Payment({required this.id, required this.party, required this.reqId, required this.status,
    required this.tx, required this.amount, required this.t});
  factory Payment.fromDoc(DocumentSnapshot d) {
    final m = d.data() as Map<String, dynamic>? ?? {};
    return Payment(id: d.id, party: m['party'] ?? '', reqId: m['reqId'] ?? '', status: m['status'] ?? 'pending',
      tx: m['tx'] ?? '', amount: m['amount'] ?? 0,
      t: (m['t'] as Timestamp?)?.toDate() ?? DateTime.now());
  }
}
